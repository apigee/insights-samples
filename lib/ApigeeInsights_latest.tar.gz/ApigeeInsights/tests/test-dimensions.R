test.dimension <- function(){
  library(ApigeeInsights)
  dimensions <- new("Dimensions")
  
  #dimension name more than 1
  checkException(dimensions$addDimension(name=c("dimension1","dimension2"),value="sTopic"))
  #missing value
  checkException(dimensions$addDimension(name=c("dimension2")))
  #missing name
  checkException(dimensions$addDimension(value=c("sTopic")))
  
  checkEquals(typeof(dimensions$addDimension(name="dimension1",value=c("phrase"))),"character")
  b_dimensions <- dimensions$copy()
  #adding same dimension and same value again
  dimensions$addDimension(name="dimension1",value=c("phrase"))
  checkEquals(dimensions,b_dimensions)
  #add multiple values for same dimension name
  checkEquals(typeof(dimensions$addDimension(name="dimension1",value=c("phrase","sTopic"))),"character")
  checkEquals(typeof(dimensions$addDimension(name=c("dimension2"),value=c("phrase","topic"))),"character")
  checkEquals(typeof(dimensions$addDimension(name=c("dimension3"),value=c("phrase","topic","sTopic"))),"character")
  
  b_dimensions <- dimensions$copy()
  empty_dimensions <- new("Dimensions")
  dimensions$removeDimension()
  checkEquals(dimensions$.dimensionListString,empty_dimensions$.dimensionListString)
  
  dimensions <- b_dimensions$copy()
  #name only
  dimensions$removeDimension(name=c("dimension1"))
  checkEquals(dimensions$.dimensionListString,"dimension2:phrase,topic;dimension3:phrase,topic,sTopic")
  #multiple - name only 
  dimensions$removeDimension(name=c("dimension1","dimension2"))
  checkEquals(dimensions$.dimensionListString,"dimension3:phrase,topic,sTopic")
  #all - name only
  dimensions$removeDimension(name=c("dimension1","dimension2","dimension3"))
  checkEquals(dimensions$.dimensionListString,"")
  
  dimensions <- b_dimensions$copy()
  #name and single value
  dimensions$removeDimension(name=c("dimension1","dimension2"),value=c("phrase"))
  checkEquals(dimensions$.dimensionListString,"dimension1:sTopic;dimension2:topic;dimension3:phrase,topic,sTopic")
  #name and multiple value
  dimensions$removeDimension(name=c("dimension1","dimension2","dimension3"),value=c("phrase","topic"))
  checkEquals(dimensions$.dimensionListString,"dimension1:sTopic;dimension3:sTopic")
  #remove everything using value
  dimensions$removeDimension(value=c("phrase","topic","sTopic"))
  checkEquals(dimensions$.dimensionListString,"")
}