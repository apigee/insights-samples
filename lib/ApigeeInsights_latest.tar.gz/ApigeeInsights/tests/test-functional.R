test.all <- function(){
  library(ApigeeInsights)
  acc <- connect(configFile="~/mwb_qa.cnf")
  getProjectList()
  getProjectList(account)
  p <- getProject(name="RetailProject-akhilesh")
  p <- getProject(account, name="RetailProject-akhilesh")
  
  getModelList(account, project="RetailProject-akhilesh")
  getModelList(project="RetailProject-akhilesh")
  m <- getModel(project="RetailProject-akhilesh", name="PPModelNoUserSplit")
  m <- getModel(account,project="RetailProject-akhilesh", name="PPModelNoUserSplit")
  
  getScoreList(account, project="RetailProject-akhilesh", model="PPModelNoUserSplit")
  getScoreList(project="RetailProject-akhilesh", model="PPModelNoUserSplit")
  s <- getScore(project="RetailProject-akhilesh", model="PPModelNoUserSplit", name="PurchasePredictScore-v1")
  s <- getScore(account,project="RetailProject-akhilesh", model="PPModelNoUserSplit", name="PurchasePredictScore-v1")
  
  getReportList(account, project="RetailProject-akhilesh", model="PPModelNoUserSplit", score="PurchasePredictScore-v1")
  getReportList(project="RetailProject-akhilesh", model="PPModelNoUserSplit", score="PurchasePredictScore-v1")
  r <- getReport(project="RetailProject-akhilesh", model="PPModelNoUserSplit", score="PurchasePredictScore-v1", name="PurchasePredictReport-v1")
  r <- getReport(account,project="RetailProject-akhilesh", model="PPModelNoUserSplit", score="PurchasePredictScore-v1", name="PurchasePredictReport-v1")
  
  getCatalogList()
  getCatalogList(acc)
  getCatalogList(acc$getDataManager())
  
  c <- getCatalog(name="RetailDemoData_v2")
  c <- getCatalog(acc,name="RetailDemoData_v2")
  c <- getCatalog(acc$getDataManager(),name="RetailDemoData_v2")
  
  getDatasetList(acc$getDataManager(),catalog="RetailDemoData_v2")
  getDatasetList(acc,catalog="RetailDemoData_v2")
  getDatasetList(catalog="RetailDemoData_v2")
  getDatasetList(c)
  
  d <- getDataset(object=acc$getDataManager(),catalog="RetailDemoData_v2", name="Return")
  d <- getDataset(object=acc,catalog="RetailDemoData_v2", name="Return")
  d <- getDataset(catalog="RetailDemoData_v2", name="Return")
  d <- getDataset(object=c, name="Return")
  
  getPartitionList(object=acc$getDataManager(),catalog="RetailDemoData_v2", dataset="Return")
  getPartitionList(object=acc,catalog="RetailDemoData_v2", dataset="Return")
  getPartitionList(catalog="RetailDemoData_v2", dataset="Return")
  getPartitionList(c, dataset="Return")
  getPartitionList(d)
}
