test.model.new <- function(){
  library(ApigeeInsights)
  acc <- connect(configFile="~/mwb_qa.cnf")
  checkException(Model$new())
  checkException(Model$new(project=1))
  checkException(Model$new(project="testProject"))
  checkException(Model$new(project="testProject",name=1))
  checkException(Model$new(name=1))
  checkException(Model$new(name="a"))
  checkEquals(Model$new(project="testProject",name="testModel")$getName(), "testModel")
}
model.compare.ipOp <- function(jsonStr)
{
  library(ApigeeInsights)
  acc <- connect(configFile="~/mwb_qa.cnf")
  modelJson <- fromJSON(jsonStr,simplify=FALSE, simplifyWithNames=FALSE)
  testProj <- Project$new()
  testProj$setAccount(acc)
  testProj$setName("test-project")
  m <- ApigeeInsights:::Utils.buildModelFromJson(testProj, modelJson)
  modelToJson <- toJSON(m$toJsonStructure(),pretty=T)
  buildFromModelJson <- toJSON(modelJson,pretty=T)
  modelToJson <- paste(sort(unlist(strsplit(modelToJson, ""))), collapse = "")
  buildFromModelJson <- paste(sort(unlist(strsplit(buildFromModelJson, ""))), collapse = "")
  return(modelToJson==buildFromModelJson)
}
test.model.get <- function(){
  mstr <- '{"name":"PurchasePredictJyothi","description":"Model to compute propensity to purchase a product category","project":"test-project","clickStream":{"offer":{"config":{"joinWindow":"DAILY","joinMode":"IMPRESSION_RESPONDER_JOIN","offerKey":"Type"},"response":{"datastore":"GQMOutput","catalog":"RetailSalesDemo10K","dataset":"PurchaseWebsite","partitions":["2013"],"config":{"responseMetric":"metrics_count","joinKey":"Userid,sequence,Type"}}},"combineActivity":{"profile":[{"datastore":"GQMOutput","catalog":"RetailSalesDemo10K","dataset":"UserProfile","partitions":["2013"],"config":{"profileList":"Profile:Gender,Age,Income_Model,Length_of_Residence"}}],"activity":[{"datastore":"GQMOutput","catalog":"RetailSalesDemo10K","dataset":"VisitWebsite","partitions":["2013"],"config":{"intensityMetric":"metrics_count","nodeList":"VisitWebSite_Customer_Type:Type,Customer"}},{"datastore":"GQMOutput","catalog":"RetailSalesDemo10K","dataset":"Return","partitions":["2013"],"config":{"intensityMetric":"metrics_count","nodeList":"Return_Product_Type:Product,Type"}},{"datastore":"GQMOutput","catalog":"RetailSalesDemo10K","dataset":"VisitStore","partitions":["2013"],"config":{"intensityMetric":"metrics_count","nodeList":"Visit_Customer_Type:Type,Customer"}},{"datastore":"GQMOutput","catalog":"RetailSalesDemo10K","dataset":"PurchaseWebsite","partitions":["2013"],"config":{"intensityMetric":"metrics_count","nodeList":"Store_Type:Type"}}]}},"config":{"splitConfig":"100:0-79"}}'
  checkEquals(model.compare.ipOp(mstr),TRUE)
  
  mstr <- '{"clickStream":{"combineActivity":{"activity":[{"catalog":"RetailSalesDemo10K","dataset":"VisitWebsite"},{"catalog":"RetailSalesDemo10K","dataset":"Return"},{"catalog":"RetailSalesDemo10K","dataset":"VisitStore"},{"catalog":"RetailSalesDemo10K","dataset":"PurchaseWebsite"}],"profile":[{"catalog":"RetailSalesDemo10K","dataset":"UserProfile"}]},"offer":{"config":{"joinMode":"IMPRESSION_RESPONDER_JOIN","joinWindow":"DAILY","offerKey":"Type"},"response":{"catalog":"RetailSalesDemo10K","dataset":"PurchaseWebsite"}}},"description":"Model to compute propensity to purchase a product category","name":"PurchasePredictJyothi","project":"test-project"}'
  checkEquals(model.compare.ipOp(mstr),TRUE)
  
  mstr <- '{"clickStream":{"combineActivity":{"profile":[{"catalog":"RetailSalesDemo10K","dataset":"UserProfile"}]}},"description":"Model to compute propensity to purchase a product category","name":"PurchasePredictJyothi","project":"test-project","id":1}'
  checkEquals(model.compare.ipOp(mstr),TRUE)  
  
}
test.model.create <- function(){
  library(ApigeeInsights)
  account <- connect("~/mwb_qa.cnf")
  project_name <- "UnitTestR"
  model_name <- paste("Model-",as.numeric(Sys.time()),sep="")
  setCatalog("LeadOptimisation-new-V3")
  
  model <- Model$new(project=project_name,name=model_name,description="Lead optimization Model")
  model$setDateFilter(endTime=as.POSIXlt("2014-03-31 23:59:59"))
  #Setting partition, datastore, catalog, metric, endTime. All these are optional
  #The endTime and catalog at the "addActivityEvent" level will take precedence over global settings
  model$addActivityEvent(catalog="LeadOptimisation-new-V3",dataset="ClickEmail", dimensions="subject", endTime=as.POSIXlt("2014-03-31 23:59:59"), 
                         metric="metrics_count",partition=c("2014"), datastore="GQMOutput")
  
  #adding complex dimensions using Dimensions object
  dims <- Dimensions$new()
  dims$addDimension(name="LC",value="page")
  dims$addDimension(name="LC-page-link",value=c("page","link"))
  dims$addDimension(name="LC-page-msg",value=c("page","msg"))
  model$addActivityEvent(dataset="LinkClick", dimensions=dims)
  
  #adding complex dimensions inline.
  model$addActivityEvent(dataset="VisitPage", dimensions=list("webpageid",c("webpageid","msgid")))
  
  model$addActivityEvent(dataset="fillOutForm", dimensions=list("page","form",c("page","form"), "program","campaign"))
  model$addActivityEvent(dataset="interestingMoment", dimensions=list("momentType","moment"))
  model$setImpressionEvent(dataset="Impression", metric="imp",
                           responseMerge=ApigeeInsights::merge(by.response="SalesQualified", by.impression="SalesQualified"))
  model$setResponseEvent(dataset="Conversion", metric="resp", predictionDimensions="SalesQualified")
  model$setConfiguration("distanceIntervalStart","MONTH")
  model$setConfiguration("firstLevelThreshold","3")
  model$setConfiguration("setThreshold","3")
  model$setConfiguration("responseThreshold","3")
  #Example for doing user split
  #model$setTrainingPercent(60)
  model$store()
  #if the object is not saved, the execute will save and execute
  model$execute()
  model$getStatus()
  
  #For score everything is derived from model. endTime is set to target score time - 1 second.
  score <- Score$new(model=model, name="ScoreUT", description="List Optimisation Score", targetScoreTime="2014-04-02")
  #changing endTime for interesting moment
  score$addActivityEvent(dataset="interestingMoment", endTime="2014-04-01 23:59:27")
  score$setConfiguration("maxCorelationPerSplit","180000")
  score$store()
  score$execute()
  score$getStatus()
  
  report <- Report$new(score=score, name="ReportUT", description="Lead Optimization")
  report$setImpressionEvent(dataset="Impression", endTime="2014-04-30 23:59:59")
  report$setResponseEvent(dataset="Conversion", endTime="2014-05-30 23:59:59")
  report$store()
  report$execute()
  report$getStatus()
  
  cReport <- account$getProject("LeadOptimization")$getModel("LOModel")$getScore("LOScore")$getReport("LOReport")
  cReport$plot("SalesQualified", type="AUC")
  cReport$plot("SalesQualified", type="LIFT")
  cReport$plot("SalesQualified", type="GAIN")
}
test.model.detailed <- function(){
  project_name <- "RetailProject-akhilesh"
  setCatalog("RetailDemoData_v2")
  
  model_name <- paste("Model-",as.numeric(Sys.time()),sep="")
  model <- Model$new(project="SEProject-v3",name=model_name,description="Retail Model")
  model$setDateFilter(endTime="2013-07-19 23:59:59")
  model$addActivityEvent(dataset="VisitWebsite", dimensions=list(c("Category","Customer")))
  model$addActivityEvent(dataset="Return", dimensions=list(c("Product","Category")))
  model$addActivityEvent(dataset="VisitStore", dimensions=list("Product",c("Category","Customer")))
  model$addActivityEvent(dataset="PurchaseWebsite", dimensions="Category")
  
  model$setProfile(dataset="userProfile", dimensions=list(c("Gender","Age","Income_Model","Length_of_Residence")))
  model$setResponseEvent(dataset="Return", predictionDimensions="Reason")
  model$setImpressionEvent(dataset="VisitWebsite", responseMerge = ApigeeInsights::merge(by.response="Reason", by.impression="Category"))
  model$execute()
  model$getStatus()
}
