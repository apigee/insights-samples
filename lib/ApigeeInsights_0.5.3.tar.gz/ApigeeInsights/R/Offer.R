Offer$methods(
  setImpression = function(impression){
    signatures <- c("Impression")
    if(!Utils.validateSignature(impression,signatures))
    {
      stop("Invalid signature : impression should be of type ", paste(signatures,collapse=" or "))
    }
    .impression <<- impression
  },
  getImpression = function(){return(.impression)},
  setResponse = function(response){
    signatures <- c("Response")
    if(!Utils.validateSignature(response,signatures))
    {
      stop("Invalid signature : response should be of type ", paste(signatures,collapse=" or "))
    }
    .response <<- response
  },
  getResponse = function(){return(.response)},
  setConfig = function(config){
    signatures <- c("list")
    if(!Utils.validateSignature(config,signatures))
    {
      stop("Invalid signature : config should be of type ", paste(signatures,collapse=" or "))
    }
    .config <<- c(config)
  },
  getConfig = function(){return(.config)},
  toJsonStructure = function()
  {
    obj <- list()
    if(Utils.isSet(.config)){
      obj[["config"]] <- .config
    }
    if(!.impression$isEmpty()){
      obj[["impression"]] <- .impression$toJsonStructure()
    }
    if(!.response$isEmpty()){
      obj[["response"]] <- .response$toJsonStructure()
    }
    else
    {
      #stop("Response dataset cannot be empty")
    }
    return(obj)
  }
  
)
