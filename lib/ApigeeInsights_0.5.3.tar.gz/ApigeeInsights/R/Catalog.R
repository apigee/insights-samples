Catalog$methods(
  setName = function(name){
    signatures <- c("character")
    if(!Utils.validateSignature(name,signatures))
    {
      stop("Invalid signature : name should be of type ", paste(signatures,collapse=" or "))
    }
    .name <<- name
  },
  getName = function(){return(.name)},
  setDescription = function(description){
    signatures <- c("character")
    if(!Utils.validateSignature(description,signatures))
    {
      stop("Invalid signature : description should be of type ", paste(signatures,collapse=" or "))
    }
    .description <<- description
  },
  getDescription = function(){return(.description)},
  setDataManager = function(dm){
    signatures <- c("DataManager")
    if(!Utils.validateSignature(dm,signatures))
    {
      stop("Invalid signature : datamanager should be of type ", paste(signatures,collapse=" or "))
    }
    .dm <<- dm
  },
  getDataManager = function(){return(.dm)},
  generateEndPoint = function(id="") {
    id <- curlEscape(id)
    host <- Utils.trim(getDataManager()$generateEndPoint(getName()))
    if(id != "") 
    {   
      id <- paste("/",id,sep="")
    }   
    return(paste(host,"/datasets",id,sep=""))
  },
  getDatasetList = function(){
    url <- generateEndPoint()
    params = list(accountId=getDataManager()$getAccount()$getId(),token=getDataManager()$getAccount()$getToken(),entityIdType="name")
    tryCatch({
      Utils.info("Fetching dataset list...")
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })  
    #Utils.debug("listDatasets",data)
    Utils.info("Fetching successful...")
    ld <- data.frame(do.call("rbind",data$datasets))
    return(ld)
  },
  getDataset = function(name){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    Utils.signatureValidation(params, globalSignatures=globalSignatures)
    url <- generateEndPoint(name)
    params = list(accountId=getDataManager()$getAccount()$getId(),token=getDataManager()$getAccount()$getToken(),entityIdType="name")
    tryCatch({
      Utils.info(paste("Fetching dataset - ",name,"...",sep="",collapse=""))
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES$ENTITY$DATASET,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<DATASET>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })  
    dataset <- Utils.buildDatasetFromJson(.self,data$dataset)
    Utils.info("Fetching successful")
    return(dataset)
  }  
)
