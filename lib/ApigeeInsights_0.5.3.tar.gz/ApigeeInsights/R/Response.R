Response$methods(
  setDatastore = function(datastore){
    signatures <- c("character")
    if(!Utils.validateSignature(datastore,signatures))
    {
      stop("Invalid signature : datastore should be of type ", paste(signatures,collapse=" or "))
    }
    .datastore <<- datastore
  },
  getDatastore = function(){return(.datastore)},
  setDataset = function(dataset){
    signatures <- c("Dataset")
    if(!Utils.validateSignature(dataset,signatures))
    {
      stop("Invalid signature : dataset should be of type ", paste(signatures,collapse=" or "))
    }
    .dataset <<- dataset
  },
  getDataset = function(){return(.dataset)},
  setPartition = function(partition){
    signatures <- c("list-Partition","Partition")
    if(!Utils.validateSignature(partition,signatures))
    {
      stop("Invalid signature : partition should be of type ", paste(signatures,collapse=" or "))
    }
    .partition <<- c(partition)
  },
  addPartition = function(partition){
    signatures <- c("list-Partition","Partition")
    if(!Utils.validateSignature(partition,signatures))
    {
      stop("Invalid signature : partition should be of type ", paste(signatures,collapse=" or "))
    }
    .partition <<- c(.partition,partition)
  },
  getPartition = function(){return(.partition)},
  setConfig = function(config){
    signatures <- c("list")
    if(!Utils.validateSignature(config,signatures))
    {
      stop("Invalid signature : config should be of type ", paste(signatures,collapse=" or "))
    }
    .config <<- c(config)
  },
  getConfig = function(){return(.config)},
  isEmpty = function()
  {
    if(!Utils.isSet(.dataset$getName()) && !Utils.isSet(.partition))
    {
      return(TRUE)
    }
    else
    {
      return(FALSE)
    }
  },
  toJsonStructure = function()
  {
    obj <- list()
    if(Utils.isSet(.config)){
      obj[["config"]] <- c(.config)
    }
    datastore <- NULL
    if(Utils.isSet(.datastore) && nchar(.datastore) > 0)
    {
      datastore <- .datastore
    }
    catalog <- NULL
    dataset <- .dataset$getName()
    partitions <- NULL
    if(!Utils.isSet(dataset))
    {
      if(!Utils.isSet(.partition))
      {
        stop("Dataset and Partitions cannot be empty")
      }
      dataset <- .partition[[1]]$getDataset()$getName()
      catalog <- .partition[[1]]$getDataset()$getCatalog()$getName()
      datastore <- .partition[[1]]$getDatastore()
      partitions <- lapply(.partition,function(x){return(x$getName())})
    }
    else
    {
      catalog <- .dataset$getCatalog()$getName()
    }
    obj[["catalog"]] <- catalog
    obj[["dataset"]] <- dataset
    if(Utils.isSet(datastore)  && nchar(datastore) > 0)
    {
      obj[["datastore"]] <- datastore
    }
    if(!is.null(partitions))
    {
      obj[["partitions"]] <- partitions
    }
    return(obj)
  },
  isSet = function()
  {
    if(Utils.isSet(getDataset()$getName()) || Utils.isSet(getPartition()))
    {
      return(TRUE)
    }
    else
    {
      return(FALSE)
    }
  }
)
