#Copyright 2014 Apigee Corporation
Dimensions$methods(
  initialize = function(){
    .dimensionListString <<- ""
  },
  addDimension = function(name, value){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    Utils.signatureValidation(params, globalSignatures=globalSignatures)
    if(missing(name))
    {   
      if(length(.dimensionList) > 0 && !is.null(names(.dimensionList)))
      {   
        stop("The dimension should be either a combination of fields or just a list of fields. Cannot be both.\n")
      }   
      .dimensionList <<- unique(append(.dimensionList,value))
    }   
    else
    {   
      if(length(name) > 1)
      {   
        stop("Dimension Name can be a character vector of length 1")
      }   
      if(length(.dimensionList) > 0 && is.null(names(.dimensionList)))
      {   
        stop("The dimension should be either a combination of fields or just a list of fields. Cannot be both.\n")
      }   
      .dimensionList[[name]] <<- unique(c(.dimensionList[[name]],value))
    }   
    .dimensionListString <<- convertToString()
  },
  removeDimension = function(name, value){
    params <- c(as.list(environment()))
    globalSignatures <- c("character","missing")
    Utils.signatureValidation(params, globalSignatures=globalSignatures)
    if(!missing(value))
    {   
      value <- paste("\\b",paste(value,collapse="\\b|\\b"),"\\b",sep="")
    }   
    entities <- NULL
    if(is.null(names(.dimensionList)))
    {
      entities <- 1:length(.dimensionList)
    }
    else
    {
      entities <- names(.dimensionList)
    }
    for(i in entities)
    {
      if(missing(name) || length(grep(paste("\\b",i,"\\b",sep=""),name)) != 0)
      {
        if(missing(value))
        {
          .dimensionList[[i]] <<- NULL
        }
        else
        {
          indexes <- sort(grep(value,.dimensionList[[i]]),decreasing=T)
          for(index in indexes)
          {
            .dimensionList[[i]] <<- .dimensionList[[i]][-index]
            if(length(.dimensionList[[i]]) == 0)
            {
              .dimensionList[[i]] <<- NULL
            }
          }
        }
      }
    }
    .dimensionListString <<- convertToString()
  },
  convertToString = function(){
    .dimensionListString <<- ""
    first = TRUE
    for(i in names(.dimensionList))
    {
      if(!first)
      {
        .dimensionListString <<- paste(.dimensionListString,";",sep="")
      }
      else
      {
        first <- FALSE
      }
      .dimensionListString <<- paste(.dimensionListString,i,":",paste(.dimensionList[[i]],collapse=","),sep="")
    }
    if(length(.dimensionList) > 0 && nchar(.dimensionListString) == 0)
    {
      .dimensionListString <<- paste(.dimensionList,collapse=",")
    }
    return(.dimensionListString)
  },
  addDimensions = function(values)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    Utils.signatureValidation(params, globalSignatures=globalSignatures)
    values <- paste(values,sep=",",collapse=",")
    ret <- Utils.isDotSyntaxValid(values)
    if(ret == FALSE)
    {   
      stop("Syntax not valid : ",values)
    }   
    .unexpandedDimensions <<- values
  }
)
