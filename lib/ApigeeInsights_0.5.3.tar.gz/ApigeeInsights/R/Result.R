#'@export
Result.isSuccess <- function(res){
  if(length(res) == 0)
  {
    return(FALSE)
  }
  if(res$result$statusCode == 200)
  {
    return(TRUE)
  }
  else
  {
    return(FALSE)
  }
}