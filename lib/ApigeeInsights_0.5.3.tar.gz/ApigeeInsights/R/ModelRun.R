ModelRun$methods(
  initialize = function(project, name, targetScoreTime, description="", type="", .skipI=FALSE){
    params <- c(as.list(environment()))
    if(.skipI)
    {
      return()
    }
    globalSignatures <- "character"
    signatures <- list(project=c("character","Project"),
                       name=c("character"),
                       description=c("character"),
                       targetScoreTime=c("character","POSIXt","POSIXlt"),
                       .skipI=c("logical"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    m <- Model$new(project=project, name=name, description=description, type=type)
    sName <- paste(name,"_auto_score",sep="")
    suppressWarnings(s <- Score$new(model=m, name=sName, targetScoreTime=targetScoreTime, description=description))
    s$setVisibility("Internal")
    rName <- paste(name,"_auto_report",sep="")
    suppressWarnings(r <- Report$new(score=s, name=rName, description=description))
    r$setVisibility("Internal")
    et <- s$.global$endTime
    m$setDateFilter(endTime=et)
    setModel(m)
    setScore(s)
    setReport(r)
  },
  show = function()
  {
    getModel()$show()
    getScore()$show()
    getReport()$show()
  },
  setModel = function(model){
    signatures <- c("Model")
    if(!Utils.validateSignature(model,signatures))
    {
      stop("Invalid signature : model should be of type ", paste(signatures,collapse=" or "))
    }
    .model <<- c(model)
  },
  getModel = function(){return(.model[[1]])},
  setScore = function(score){
    signatures <- c("Score")
    if(!Utils.validateSignature(score,signatures))
    {
      stop("Invalid signature : score should be of type ", paste(signatures,collapse=" or "))
    }
    .score <<- c(score)
  },
  cloneObject = function(name, description="", targetScoreTime=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(name=c("character"),
                       targetScoreTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       description = "character")
    Utils.signatureValidation(params, signatures, globalSignatures)
    sName <- paste(name,"_auto_score",sep="")
    rName <- paste(name,"_auto_report",sep="")
    
    m <- getModel()$cloneObject(name, description)
    s <- getScore()$cloneObject(sName, description, targetScoreTime)
    s$setModel(m)
    r <- getReport()$cloneObject(rName, description)
    r$setScore(s)
    
    mr <- ModelRun$new(.skipI=T)
    et <- s$.global$endTime
    m$setDateFilter(endTime=et)
    mr$setModel(m)
    mr$setScore(s)
    mr$setReport(r)
    return(mr)
  },
  getScore = function(){return(.score[[1]])},
  setReport = function(report){
    signatures <- c("Report")
    if(!Utils.validateSignature(report,signatures))
    {
      stop("Invalid signature : report should be of type ", paste(signatures,collapse=" or "))
    }
    .report <<- c(report)
  },
  setImpRespConfig = function(joinWindow, joinMode)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(joinWindow=c("character"),
                       joinMode=c("character"))
    getModel()$setImpRespConfig(joinWindow, joinMode)
  },
  getReport = function(){return(.report[[1]])},
  addActivityEvent = function(dataset, dimensions, catalog=NULL, metric=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","missing","NULL"),
                       dataset=c("character"),
                       dimensions=c("character","Dimensions","list"),
                       metric=c("character","missing","NULL"),
                       startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       endTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       partitions=c("character","missing","NULL"),
                       datastore=c("character","missing","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    getModel()$addActivityEvent(dataset, dimensions, catalog, metric, startTime, endTime, partitions, datastore)
    setInfo(0)
    tryCatch({
      sName <- paste(getModel()$getName(),"_auto_score",sep="")
      description <- getModel()$getDescription()
      targetScoreTime <- getScore()$getConfig()$targetScoreTime
      suppressWarnings(s <- Score$new(model=getModel(), name=sName, targetScoreTime=targetScoreTime, description=description))
      s$setVisibility("Internal")
      setScore(s)
      rName <- paste(getModel()$getName(),"_auto_report",sep="")
      suppressWarnings(r <- Report$new(score=getScore(), name=rName, description=description))
      if(!is.null(.global$reportDateFilter$st))
      {
        r$setDateFilter(startTime=.global$reportDateFilter$st)
      }
      if(!is.null(.global$reportDateFilter$et))
      {
        r$setDateFilter(endTime=.global$reportDateFilter$et)
      }
      r$setVisibility("Internal")
      setReport(r)
    }, AIErr=function(err){
      setInfo(1)
      return(err)
    })
    setInfo(1)
  },
  setProfile = function(dataset, dimensions, catalog=NULL, partitions=NULL, datastore=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","missing","NULL"),
                       dataset=c("character"),
                       dimensions=c("character","Dimensions","list"),
                       partitions=c("character","missing","NULL"),
                       datastore=c("character","missing","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    getModel()$setProfile(dataset, dimensions, catalog, partitions, datastore)
    setInfo(0)
    tryCatch({
      sName <- paste(getModel()$getName(),"_auto_score",sep="")
      description <- getModel()$getDescription()
      targetScoreTime <- getScore()$getConfig()$targetScoreTime
      suppressWarnings(s <- Score$new(model=getModel(), name=sName, targetScoreTime=targetScoreTime, description=description))
      s$setVisibility("Internal")
      setScore(s)
      rName <- paste(getModel()$getName(),"_auto_report",sep="")
      suppressWarnings(r <- Report$new(score=getScore(), name=rName, description=description))
      if(!is.null(.global$reportDateFilter$st))
      {
        r$setDateFilter(startTime=.global$reportDateFilter$st)
      }
      if(!is.null(.global$reportDateFilter$et))
      {
        r$setDateFilter(endTime=.global$reportDateFilter$et)
      }
      r$setVisibility("Internal")
      setReport(r)
    }, AIErr=function(err){
      setInfo(1)
      return(err)
    })
    setInfo(1)
  },
  setResponseEvent = function(dataset, predictionDimensions=NULL, catalog=NULL, metric=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","missing","NULL"),
                       dataset=c("character"),
                       predictionDimensions=c("character","missing","NULL"),
                       metric=c("character","missing","NULL"),
                       startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       endTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       partitions=c("character","missing","NULL"),
                       datastore=c("character","missing","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    getModel()$setResponseEvent(dataset, predictionDimensions, catalog, metric, startTime, endTime, partitions, datastore)
    setInfo(0)
    tryCatch({
      description <- getModel()$getDescription()
      rName <- paste(getModel()$getName(),"_auto_report",sep="")
      suppressWarnings(r <- Report$new(score=getScore(), name=rName, description=description))
      if(!is.null(.global$reportDateFilter$st))
      {
        r$setDateFilter(startTime=.global$reportDateFilter$st)
      }
      if(!is.null(.global$reportDateFilter$et))
      {
        r$setDateFilter(endTime=.global$reportDateFilter$et)
      }
      r$setVisibility("Internal")
      setReport(r)
    }, AIErr=function(err){
      setInfo(1)
      return(err)
    })
    setInfo(1)
  },
  store = function()
  {
    getModel()$store()
    getScore()$store()
    getReport()$store()
  },
  execute = function()
  {
    getModel()$execute()
    getScore()$execute()
    getReport()$execute()
  },
  update = function()
  {
    getModel()$update()
    getScore()$update()
    getReport()$update()
  },
  buildAndValidate = function()
  {
    getModel()$execute()
    getScore()$execute()
    getReport()$execute()
  },
  getValidationReport = function(topN=-1,sep="\t")
  {
    return(getReport()$stream(topN,sep))
  },
  openJobManager = function()
  {
    getReport()$openJobManager()
  },
  plot = function(type="AUC",predictionDimensionValue=NULL, sep="\t")
  {
    getReport()$plot(type, predictionDimensionValue, sep)
  },
  getStatus = function()
  {
    ms <- getModel()$getStatus()
    ss <- getScore()$getStatus()
    rs <- getReport()$getStatus()
    if(ms != "Completed")
    {
      return(ms)
    }
    else if(ss != "Completed")
    {
      if(ss == "Submitted")
      {
        return("Running")
      }
      return(ss)
    }
    else if(rs != "Completed")
    {
      if(rs == "Submitted")
      {
        return("Running")
      }
      return(rs)
    }
    else
    {
      return(rs)
    }
  },
  setTargetValidationTime = function(startTime=NULL, endTime=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       endTime=c("character","POSIXt","POSIXlt","missing","NULL"))
    if(is.null(startTime) && is.null(endTime))
    {
      stop("start time and end time cannot be missing")
    }
    getReport()$setDateFilter(startTime,endTime)
    .global$reportDateFilter <<- list(st=startTime,et=endTime)
    
  },
  setModelTime = function(startTime=NULL, endTime=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       endTime=c("character","POSIXt","POSIXlt","missing","NULL"))
    if(is.null(startTime) && is.null(endTime))
    {
      stop("start time and end time cannot be missing")
    }
    getModel()$setDateFilter(startTime,endTime)
    setInfo(0)
    tryCatch({
      sName <- paste(getModel()$getName(),"_auto_score",sep="")
      description <- getModel()$getDescription()
      targetScoreTime <- getScore()$getConfig()$targetScoreTime
      suppressWarnings(s <- Score$new(model=getModel(), name=sName, targetScoreTime=targetScoreTime, description=description))
      s$setVisibility("Internal")
      setScore(s)
      rName <- paste(getModel()$getName(),"_auto_report",sep="")
      suppressWarnings(r <- Report$new(score=getScore(), name=rName, description=description))
      if(!is.null(.global$reportDateFilter$st))
      {
        r$setDateFilter(startTime=.global$reportDateFilter$st)
      }
      if(!is.null(.global$reportDateFilter$et))
      {
        r$setDateFilter(endTime=.global$reportDateFilter$et)
      }
      r$setVisibility("Internal")
      setReport(r)
    }, AIErr=function(err){
      setInfo(1)
      return(err)
    })
    setInfo(1)
  },
  setImpressionEvent = function(dataset, predictionDimensions=NULL, responseMerge, catalog=NULL, metric=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","missing","NULL"),
                       dataset=c("character"),
                       predictionDimensions=c("character","missing","NULL"),
                       responseMerge=c("list"),
                       metric=c("character","missing","NULL"),
                       startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       endTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       partitions=c("character","missing","NULL"),
                       datastore=c("character","missing","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    getModel()$setImpressionEvent(dataset, predictionDimensions, responseMerge, catalog, metric, startTime, endTime, partitions, datastore)
    setInfo(0)
    tryCatch({
      description <- getModel()$getDescription()
      rName <- paste(getModel()$getName(),"_auto_report",sep="")
      suppressWarnings(r <- Report$new(score=getScore(), name=rName, description=description))
      if(!is.null(.global$reportDateFilter$st))
      {
        r$setDateFilter(startTime=.global$reportDateFilter$st)
      }
      if(!is.null(.global$reportDateFilter$et))
      {
        r$setDateFilter(endTime=.global$reportDateFilter$et)
      }
      r$setVisibility("Internal")
      setReport(r)
    }, AIErr=function(err){
      setInfo(1)
      return(err)
    })
    setInfo(1)
  }
)