Project$methods(
  initialize = function(.account, .name, .description){
    if(!missing(.account))
    {
      setAccount(.account)
    }
    else
    {
      setAccount(.AIEnv[[".ApigeeInsights"]])
    }
    if(!missing(.name))
    {
      setName(.name)
    }
    if(!missing(.description))
    {
      setDescription(.description)
    }
    setSaved(FALSE)
  },
  setAccount = function(account){
    signatures <- c("ApigeeInsights")
    if(!Utils.validateSignature(account,signatures))
    {
      stop("Invalid signature : account should be of type ", paste(signatures,collapse=" or "))
    }
    .account <<- account
  },
  getAccount = function(){return(.account)},
  setId = function(id){
    signatures <- c("numeric")
    if(!Utils.validateSignature(id,signatures))
    {
      stop("Invalid signature : id should be of type ", paste(signatures,collapse=" or "))
    }
    .id <<- id
  },
  getId = function(){return(.id)},
  setName = function(name){
    signatures <- c("character")
    if(!Utils.validateSignature(name,signatures))
    {
      stop("Invalid signature : name should be of type ", paste(signatures,collapse=" or "))
    }
    .name <<- name
  },
  getName = function(){return(.name)},
  setDescription = function(description){
    signatures <- c("character")
    if(!Utils.validateSignature(description,signatures))
    {
      stop("Invalid signature : description should be of type ", paste(signatures,collapse=" or "))
    }
    .description <<- description
  },
  getDescription = function(){return(.description)},
  setSaved = function(saved){
    signatures <- c("logical")
    if(!Utils.validateSignature(saved,signatures))
    {
      stop("Invalid signature : saved should be of type ", paste(signatures,collapse=" or "))
    }
    .saved <<- saved
  },
  getSaved = function(){return(.saved)},
  generateEndPoint = function(id=""){
    id <- curlEscape(id)
    host <- Utils.trim(getAccount()$getHost())
    if(id != "") 
    {   
      id <- paste("/",id,sep="")
    }   
    return(paste(host,"/projects",id,sep=""))
  },
  generateCEndPoint = function(id=""){
    id <- curlEscape(id)
    host <- Utils.trim(getAccount()$getHost())
    if(id != "") 
    {   
      id <- paste("/",id,sep="")
    }   
    return(paste(host,"/modeling/models",id,sep=""))
  },
  store = function(){
    url <- generateEndPoint()
    name <- getName()
    params = list(accountId=getAccount()$getId(),token=getAccount()$getToken());
    #cat(params$accountId,params$token)
    if(!Utils.isSet(getDescription()))
    {
      setDescription("")
    }
    jsonObj = list(name=getName(),description=getDescription())
    JSON = toJSON(jsonObj, asIs=F)
    Utils.info(paste("Saving project - ",getName(),"...",sep=""))
    tryCatch({
      data <- sendRequest(url,"post",params,JSON)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES$ENTITY$PROJECT,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<PROJECT>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })  
    setId(data$projectId)
    setSaved(TRUE)
    Utils.info("Project saved")
  },
  getModel = function(name){
      params <- c(as.list(environment()))
      globalSignatures <- "character"
      Utils.signatureValidation(params, globalSignatures=globalSignatures)
      url <- generateCEndPoint(name)
      pn <- getName()
      params = list(accountId=getAccount()$getId(),token=getAccount()$getToken(),entityIdType="name",project=pn)
      Utils.info(paste("Fetching model - ",name,"...",sep="",collapse=""))
      tryCatch({
        data <- sendRequest(url,"get",params)
      },AIErr=function(x){
        if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
        {   
          stop(x)
        }   
        template <- paste(MESSAGES$ENTITY$MODEL,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
        tv <- .AIEnv[[".TEMPLATE_VALUES"]]
        tv[["<MODEL>"]] <- name
        msg <- replaceTemplate(template,tv)
        stop(createAIErr(x$code,msg))
      })  
      Utils.info(paste("Fetching successful - ",name,sep="",collapse=""))
      model <- Utils.buildModelFromJson(.self,data$model,.skipI=TRUE)
      model$setSaved(TRUE)
      return(model)
      
  },
  getModelList = function(){
    pn <- getName()
    url <- generateEndPoint(pn)
    url <- paste(url,"/models",sep="",collapse="")
    params = list(accountId=getAccount()$getId(),token=getAccount()$getToken(),entityIdType="name",project=pn)
    Utils.info("Fetching model list...")
    tryCatch({
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })  
    Utils.info("Fetching successful")
    ld <- data.frame(do.call("rbind",data$models))
    return(ld)
  }
  
  
)