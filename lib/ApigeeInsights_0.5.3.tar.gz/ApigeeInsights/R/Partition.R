#Copyright 2014 Apigee Corporation
Partition$methods(
  setDataset = function(dataset){
    signatures <- c("Dataset")
    if(!Utils.validateSignature(dataset,signatures))
    {
      stop("Invalid signature : dataset should be of type ", paste(signatures,collapse=" or "))
    }
    .dataset <<- dataset
  },
  getDataset = function(){return(.dataset)},
  setDatastore = function(datastore){
    signatures <- c("character")
    if(!Utils.validateSignature(datastore,signatures))
    {
      stop("Invalid signature : datastore should be of type ", paste(signatures,collapse=" or "))
    }
    .datastore <<- datastore
  },
  getDatastore = function(){return(.datastore)},
  setName = function(name){
    signatures <- c("character")
    if(!Utils.validateSignature(name,signatures))
    {
      stop("Invalid signature : name should be of type ", paste(signatures,collapse=" or "))
    }
    .name <<- name
  },
  getName = function(){return(.name)},
  setDescription = function(description){
    signatures <- c("character")
    if(!Utils.validateSignature(description,signatures))
    {
      stop("Invalid signature : description should be of type ", paste(signatures,collapse=" or "))
    }
    .description <<- description
  },
  getDescription = function(){return(.description)},
  setSchema = function(schema){
    signatures <- c("list")
    if(!Utils.validateSignature(schema,signatures))
    {
      stop("Invalid signature : schema should be of type ", paste(signatures,collapse=" or "))
    }
    .schema <<- c(schema)
  },
  getSchema = function(){return(.schema)},
  setDelimiter = function(delimiter){
    signatures <- c("character")
    if(!Utils.validateSignature(delimiter,signatures))
    {
      stop("Invalid signature : delimiter should be of type ", paste(signatures,collapse=" or "))
    }
    .delimiter <<- delimiter
  },
  getDelimiter = function(){return(.delimiter)},
  setStatistics = function(statistics){
    signatures <- c("list")
    if(!Utils.validateSignature(statistics,signatures))
    {
      stop("Invalid signature : statistics should be of type ", paste(signatures,collapse=" or "))
    }
    .statistics <<- c(statistics)
  },
  generateEndPoint = function(id="") {
    return(getDataset()$generateCEndPoint(id))
  },
  generateStatistics = function()
  {
    url <- generateEndPoint(getName())
    params = list(accountId=getDataset()$getCatalog()$getDataManager()$getAccount()$getId(),token=getDataset()$getCatalog()$getDataManager()$getAccount()$getToken(),entityIdType="name")
    url <- paste(url,"/generateStatistics_op",sep="")
    tryCatch({
      data <- sendRequest(url,"put",params,"{}")
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })  
  },
  show = function()
  {
    cat("Partition Object:\n\n")
    cat("name =",getName(),"\n\n")
    cat("description =",getDescription(),"\n\n")
    showSchema()
    getStatistics()$showStats()
    
  },
  stream = function(topN=20,sep="\t") {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(topN=c("numeric"),
                       sep=c("character"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    host <- generateEndPoint(getName())
    if(Utils.isSet(getDelimiter()))
    {
      sep <- getDelimiter()
    }
    else if(Utils.isSet(getDataset()$getDelimiter()))
    {
      sep <- getDataset()$getDelimiter()
    }
    sepList <- unlist(strsplit(sep,"\\|"))

    host <- paste(host,"/stream_op?",sep="")
    if(topN <= 0)
    {
      topN <- .statistics$rows
      cat("Since topN is not positive, all the",topN,"rows will be fetched\n")
    }
    params = list(topN=topN,accountId=getDataset()$getCatalog()$getDataManager()$getAccount()$getId(),token=getDataset()$getCatalog()$getDataManager()$getAccount()$getToken(),entityIdType="name");
    if(nchar(getDatastore()) > 0)
    {
      params$datastore=getDatastore()
    }
    for(i in names(params)){
      host <- paste(host,i,"=",params[[i]],"&",sep="")
    }
    Utils.info(host,"\n")
    Utils.info("Streaming the data and loading into data.frame...\n")
    pb <- txtProgressBar(min = 0, max = topN, style = 3)
    con  <- file(host, open = "r")
    
    i <- -1
    lines_t <- NULL
    df_actual <- NULL
    
    
    while (length(oneLine <- readLines(con, n = 1, warn = FALSE)) > 0) {
      if(!grepl("^Warning",oneLine)){
        setTxtProgressBar(pb, i)
        if(i < 0.99*topN){
          i <- i+1
        }
        if(length(sepList) > 1)
        {
          oneLine <- gsub(sep,sepList[1],oneLine)
        }
        lines_t <- append(lines_t,oneLine)
      }
    }
    sep <- sepList[1]
    setTxtProgressBar(pb, (0.99*topN))
    close(con)
    while(length(lines_t) > 0 && grepl("Warning",lines_t[1]))
    {
      lines_t <- lines_t[-1]
    }
    while(length(lines_t) > 0 && lines_t[1] == "")
    {
      lines_t <- lines_t[-1]
    }
    if(length(lines_t) == 0)
    {
      cat("No lines available\n")
      return()
    }
    df_actual <- read.table(text=lines_t,sep=sep,stringsAsFactors=TRUE,quote="",fill=TRUE)
    if(length(getSchema()) == 0)
    {
      s <- lapply(getDataset()$getSchema(),function(x){x$fieldName})
    }
    else
    {
      s <- lapply(getSchema(),function(x){x$fieldName})
    }
    if(length(s) > 0){
      colnames(df_actual) <- s
    }
    setTxtProgressBar(pb, topN)
    close(pb)
    return(df_actual)
  },
  showSchema = function()
  {
    if(!Utils.isSet(getSchema()))
    {   
      cat("Schema for this partition is empty. Getting the schema from the dataset\n")
      sdf <- data.frame(do.call("rbind",getDataset()$getSchema()))
    }   
    else
    {   
      cat("\nSchema for Dataset '",getDataset()$getName(),"' and Partition '",getName(),"'", sep="")
      sdf <- data.frame(do.call("rbind",getSchema()))
    }
    return(pandoc.table(sdf,split.cells=50, split.table=120,style="grid"))
  },
  getStatistics = function()
  {
    url <- generateEndPoint(getName())
    params = list(accountId=getDataset()$getCatalog()$getDataManager()$getAccount()$getId(),token=getDataset()$getCatalog()$getDataManager()$getAccount()$getToken(),entityIdType="name")
    url <- paste(url,"/getStatistics_op",sep="")
    tryCatch({
      data <- sendRequest(url,"get",params)
      cStats <- data$statistics$PartitionReport$columns
      data$statistics$PartitionReport$columns <- NULL
      oStats <- data$statistics$PartitionReport
      for(n in names(.statistics))
      {
        if(n!="rows")
          oStats[[n]] <- .statistics[[n]]
      }
      dStore <- getDatastore()
      p <- .self
      statsObj <- BaseStatistics$new()
      statsObj$setPartition(p)
      statsObj$setOverAllStats(oStats)
      statsObj$setColumnLevelStats(cStats)
      return(statsObj)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })
  },
  addStatistics = function(statistics){
    signatures <- c("list")
    if(!Utils.validateSignature(statistics,signatures))
    {
      stop("Invalid signature : statistics should be of type ", paste(signatures,collapse=" or "))
    }
    .statistics <<- c(.statistics,statistics)
  }
  
)
collapsePartitions <- function(x){
  x$partitions<-paste(x$partitions,collapse=",")
  return(x)
}
