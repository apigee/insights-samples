library(ApigeeInsights)
acc <- connect(org="qauser",user="qauser",password="Test12345",host="http://10.224.16.104:8080/api")
acc <- connect(org="amalavalli223",user="amalavalli223",password="Aaaa1234",host="https://insights.apigee.net/api")
acc <- connect(org="burberry_test",user="insights_admin@apigee.com",password="Apigee2010",host="https://burberry-insights.apigee.com/api/")
myID <- "v222"


################################ CARS ########################################
projectName <- paste("carsProject", myID, sep="-")
modelName <- paste("carsModel", myID, sep="-")
model <- Model$new(project=projectName, name=modelName, 
                   description="Cars model")
model$setProfile(catalog="profileOnly",dataset="cars",dimensions=c("maint","buying","doors","persons","lugboot","safety"), responseDimension="resp")
model$setTrainingPercent(80)
model$execute()
model$getStatus()


scoreName <- paste("carsScore", myID, sep="-")
score <- Score$new(model, name=scoreName, 
                   description="Output score from applying the model to the scoring dataset")
score$execute()
score$getStatus()

reportName <- paste("carsReport", myID, sep="-")
report <- Report$new(score=score, name=reportName)
report$execute()
report$getStatus()


################################ CENSUS ########################################
censusProjectName <- paste("censusProject", myID, sep="-")
censusModelName <- paste("censusModel", myID, sep="-")
censusScoreName <- paste("censusScore", myID, sep="-")
censusReportName <- paste("censusReport", myID, sep="-")

model <- Model$new(project=censusProjectName, name=censusModelName)
model$setProfile(catalog="profileOnly",dataset="census",dimensions=c("age","workclass","edunum","mstatus",
                                                                     "occupation","relationship","race","sex","capgain",
                                                                     "caploss","hoursweek","ncountry","continent"),dimCombn = 2, 
                 responseDimension="labelHighIncome", filterColumn = "sex",filterValues = "Female")
model$setTrainingPercent(80)
model$execute()
model$getStatus()



score <- Score$new(model, name=censusScoreName, 
                   description="Output score from applying the model to the scoring dataset")

score$execute()
score$getStatus()

report <- Report$new(score=score, name=censusReportName)
report$execute()



################################ RETAIL ########################################
retailProjectName <- paste("RecTutorial", myID, sep="-")

setCatalog("RetailDatasets")
retailModelName <- paste("RecoModel-1", myID, sep="-")
model <- Model$new(project=retailProjectName, name=retailModelName, 
                   description="A model to show propensity for buying a particular product.")

model$setDateFilter(startTime="2013-01-01 00:00:00", endTime="2013-08-19 23:59:59")
model$setProfile(dataset="Profile", 
                 dimensions=list(c("AgeGroup", "Gender",
                                   "DownloadedMobileApp",
                                   "EmailSubscriber")),dimCombn = -1,filterColumn = "Gender",filterValues = "Female")
model$addActivityEvent(dataset="WebsiteVisit", dimensions="ProductCategory")
model$addActivityEvent(dataset="Return", dimensions=list(c("ProductName","Reason")))
model$addActivityEvent(dataset="StoreVisit", dimensions="City")
model$addActivityEvent(dataset="CustomerServiceCall", dimensions="Reason")
model$addActivityEvent(dataset="Offer", dimensions=list(c("ProductName","OfferType")))

model$setResponseEvent(dataset="Purchase", predictionDimensions="ProductName")
model$execute()
model$getStatus()

retailScoreName <- paste("RecModelScore", myID, sep="-")
score <- Score$new(model, name=retailScoreName, 
                   description="Output score from applying the model to the scoring dataset", 
                   targetScoreTime="2013-08-20")

score$execute()
score$getStatus()

retailReportName <- paste("RecModelReport", myID, sep="-")
report <- Report$new(score=score, name=retailReportName)

report$execute()
report$getStatus()


plotType <- c("AUC","GAIN","LIFT")
predDimValues <- c("unacc","acc","good","vgood")
predDimValues <- c("1","0")
for(pt in plotType)
{
  for(pd in predDimValues)
  {
    fName <- paste("~/census_80_20_",pt,"_",pd,".png",sep="")
    png(fName, width=4, height=4, units="in", res=300)
    par(mar=c(4,4,1,1))
    report$plot(type = pt, predictionDimensionValue = pd)
    dev.off()
  }
}

model <- acc$getProject(retailProjectName)$getModel(retailModelName)
score <- model$getScore("akhiScoreCars-v1")
report <- score$getReport("akhiReportCar-v1")

nModel <-  model$cloneObject(name = "profileModel-v2",description = "Test")
nModel$setTrainingPercent(60,isRandom = T)
nModel$execute()
nScore <- Score$new(nModel, name="profileScore-v1")
nScore$execute()

nReport <- Report$new(score=nScore, name="profileReport-v1")
nReport$execute()

rModel <- acc$getProject("RecTutorial-v3")$getModel("RecoModel-v3")
rScore <- rModel$getScore("RecModelScore-v3")
rReport <- rScore$getReport("RecModelReport-v3")

cModel <- getProject(name = "RecommendationsTutorial")$getModel(name = "RecommendationsModel")
cScore <- cModel$getScore(name = "RecommendationsModelScore")
cReport <- cScore$getReport(name = "RecommendationsModelAccuracyReport")

model1 <- acc$getProject("RecommendationsTutorial")$getModel("RecCloneModel-v1")
score1 <- model1$getScore("RecCloneScore-v1")
report1 <- score1$getReport("RecCloneReport-v1")

modelbbry <- acc$getProject("censusProject-v3")$getModel("censusModel-v3")
scorebbry <- modelbbry$getScore("censusScore-v3")
reportbbry <- scorebbry$getReport("censusReport-v3")
model2$cloneObject("jdm")$execute()
score2$cloneObject("jds")$execute()
report2$cloneObject("jdr")$execute()


nrModel <- rModel$cloneObject(name = "RecCloneModel-v1",description = "Test")
nrModel$execute()

nrScore <- Score$new(nrModel, name="RecCloneScore-v1",targetScoreTime="2013-08-20")
nrScore$execute()

nrReport <- Report$new(nrScore, name="RecCloneReport-v1")
nrReport$execute()








model <- Model$new(project="joyDataProject", name="joyDataModel-v2")
model$setProfile(catalog="joy_catalog",dataset="d1",dimensions=c("age","workclass","edunum","mstatus",
                                                                 "occupation","relationship","race","sex","capgain",
                                                                 "caploss","hoursweek","ncountry","continent"), 
                 responseDimension="labelHighIncome")
model$setTrainingPercent(80)
model$execute()
model$getStatus()


score <- Score$new(model, name="joyDataScore-v1", 
                   description="Output score from applying the model to the scoring dataset")

score$execute()
score$getStatus()

report <- Report$new(score=score, name="joyDataReport-v1")
report$execute()



#=========================================================================

myID <- "vfold11"
censusProjectName <- paste("censusProject", myID, sep="-")
censusModelName <- paste("censusModel", myID, sep="-")
censusScoreName <- paste("censusScore", myID, sep="-")
censusReportName <- paste("censusReport", myID, sep="-")

#Profile only model
model <- Model$new(project=censusProjectName, name=censusModelName)
model$setProfile(catalog="profileOnly",dataset="census",dimensions=c("age","workclass","edunum","mstatus",
                                                                     "occupation","relationship","race","sex","capgain",
                                                                     "caploss","hoursweek","ncountry","continent"),dimCombn = 2, 
                 responseDimension="labelHighIncome")
model$setTrainingPercent(80,isRandom = T)
model$execute()
model$getStatus()



score <- Score$new(model, name=censusScoreName, 
                   description="Output score from applying the model to the scoring dataset")

score$execute()

report <- Report$new(score=score, name=censusReportName)
report$execute()


#=========================================================================
myID <- "v12"
censusProjectName <- paste("censusProject", myID, sep="-")
censusModelName <- paste("censusModel", myID, sep="-")
censusScoreName <- paste("censusScore", myID, sep="-")
censusReportName <- paste("censusReport", myID, sep="-")

model1 <- Model$new(project=censusProjectName, name=censusModelName)
model1$setProfile(catalog="profileOnly",dataset="census",dimensions=c("age","workclass","edunum","mstatus",
                                                                     "occupation"),dimCombn = 2, 
                 responseDimension="labelHighIncome")
model1$setTrainingPercent(80)
model1$execute()
model1$getStatus()

modelfold1 <- acc$getProject("censusProject-vfold11")$getModel("censusModel-vfold11")
scorefold1 <- modelfold1$getScore("censusScore-vfold11")
reportfold1 <- scorefold1$getReport("censusReport-vfold11")

score1 <- Score$new(model1, name=censusScoreName, 
                   description="Output score from applying the model to the scoring dataset")

score1$execute()

cs <- CombinedScore$new(project="combinedScoreProject", name = "combinedScore-v11-12")
cs$setAlgo("dsds")
cs$addScore(score,0.6)
cs$addScore(score1,0.4)
cs
cs$execute()
