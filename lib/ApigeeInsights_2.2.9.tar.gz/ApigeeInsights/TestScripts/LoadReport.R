#Remove hash symbol from the first line of the report
library(ApigeeInsights)
acc <- connect(org="qauser",user="qauser",password="Test12345",host="http://10.224.16.104:8080/api")
mm <- acc$getProject("RecommendationsTutorial")$getModel("RecommendationsModel")
ss <- mm$getScore("RecommendationsModelScore")
rr <- ss$getReport("RecommendationsModelAccuracyReport")
ddf <- read.csv("~/newcreport-v2-o",header = T,sep="\t")
nn1 <- names(ddf[,1:4])
nn2 <- names(ddf[,c("active_users","responders")])
ddf1 <- ddf[,c(nn1,nn2)]
rr$.global$fullReport <- ddf1
rr$plot(type="AUC")


oldReport <- rScore$getReport("RecommendationsModelAccuracyReport")
oldReport$plot(type = "AUC",predictionDimensionValue = "10632300")
