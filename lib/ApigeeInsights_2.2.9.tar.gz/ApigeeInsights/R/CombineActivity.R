#Copyright 2014 Apigee Corporation
CombineActivity$methods(
  setActivity = function(activity){
    signatures <- c("list-Activity","Activity")
    if(!Utils.validateSignature(activity,signatures))
    {
      stop("Invalid signature : activity should be of type ", paste(signatures,collapse=" or "))
    }
    .activity <<- c(activity)
  },
  addActivity = function(activity){
    signatures <- c("list-Activity","Activity")
    if(!Utils.validateSignature(activity,signatures))
    {
      stop("Invalid signature : activity should be of type ", paste(signatures,collapse=" or "))
    }
    if(Utils.checkClass(activity,"Activity"))
    {
      activity <- list(activity)
    }
    for(act in activity)
    {
      cd <- Utils.getCatalogDatasetFromAIRP(act)
      aCatalog <- cd$catalog
      aDataset <- cd$dataset
      removeGivenDatasetCatalogActivity(aCatalog,aDataset)
      .activity <<- c(.activity,act)
    }
  },
  getActivity = function(){return(.activity)},
  setProfile = function(profile){
    signatures <- c("list-Profile","Profile")
    if(!Utils.validateSignature(profile,signatures))
    {
      stop("Invalid signature : profile should be of type ", paste(signatures,collapse=" or "))
    }
    .profile <<- c(profile)
  },
  addProfile = function(profile){
    signatures <- c("list-Profile","Profile")
    if(!Utils.validateSignature(profile,signatures))
    {
      stop("Invalid signature : profile should be of type ", paste(signatures,collapse=" or "))
    }
    if(Utils.checkClass(profile,"Profile"))
    {
      profile <- list(profile)
    }
    for(pr in profile)
    {
      cd <- Utils.getCatalogDatasetFromAIRP(pr)
      aCatalog <- cd$catalog
      aDataset <- cd$dataset
      removeGivenDatasetCatalogProfile(aCatalog,aDataset)
      .profile <<- c(.profile,pr)
    }
  },
  getProfile = function(){return(.profile)},
  toJsonStructure = function()
  {
    obj <- list()
    if(Utils.isSet(.activity)){
      obj["activity"] <- list(lapply(.activity,function(x) {return(x$toJsonStructure())}))
    }
    if(Utils.isSet(.profile)){
      obj["profile"] <- list(lapply(.profile,function(x) {return(x$toJsonStructure())}))
    }
    return(obj)
  },
  removeGivenDatasetCatalogActivity = function(catalog,dataset)
  {
    len <- length(.activity)
    if(len != 0)
    {
      for(i in sort(1:len,decreasing=T))
      {
        cd <- Utils.getCatalogDatasetFromAIRP(.activity[[i]])
        aCatalog <- cd$catalog
        aDataset <- cd$dataset
        if(!Utils.isSet(aDataset) || (catalog == aCatalog && dataset == aDataset))
        {
          .activity[[i]] <<- NULL
        }
      }
    }
  },
  findGivenDatasetCatalogActivity = function(catalog,dataset)
  {
    activities = NULL
    len <- length(.activity)
    if(len != 0)
    {
      for(i in sort(1:len,decreasing=T))
      {
        cd <- Utils.getCatalogDatasetFromAIRP(.activity[[i]])
        aCatalog <- cd$catalog
        aDataset <- cd$dataset
        if(!Utils.isSet(aDataset) || (catalog == aCatalog && dataset == aDataset))
        {
          activities <- c(activities, .activity[[i]])
        }
      }
    }
    return(activities)
  },
  removeGivenDatasetCatalogProfile = function(catalog,dataset)
  {
    len <- length(.profile)
    if(len != 0)
    {
      for(i in sort(1:len,decreasing=T))
      {
        cd <- Utils.getCatalogDatasetFromAIRP(.profile[[i]])
        aCatalog <- cd$catalog
        aDataset <- cd$dataset
        if(!Utils.isSet(aDataset) || (catalog == aCatalog && dataset == aDataset))
        {
          .profile[[i]] <<- NULL
        }
      }
    }
  }
)
