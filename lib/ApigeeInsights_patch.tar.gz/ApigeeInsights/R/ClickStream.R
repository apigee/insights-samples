#Copyright 2014 Apigee Corporation
ClickStream$methods(
  setCombineActivity = function(combineActivity){
    signatures <- c("CombineActivity")
    if(!Utils.validateSignature(combineActivity,signatures))
    {
      stop("Invalid signature : combineActivity should be of type ", paste(signatures,collapse=" or "))
    }
    .combineActivity <<- combineActivity
  },
  getCombineActivity = function(){return(.combineActivity)},
  setOffer = function(offer){
    signatures <- c("Offer")
    if(!Utils.validateSignature(offer,signatures))
    {
      stop("Invalid signature : offer should be of type ", paste(signatures,collapse=" or "))
    }
    .offer <<- offer
  },
  getOffer = function(){return(.offer)},
  toJsonStructure = function()
  {
    obj <- list()
    o <- .offer$toJsonStructure()
    if(Utils.isSet(o))
    obj[["offer"]] <- o
    ca <- .combineActivity$toJsonStructure()
    if(Utils.isSet(ca))
    obj[["combineActivity"]] <- ca
    return(obj)
  }
)
