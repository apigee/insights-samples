#Copyright 2014 Apigee Corporation
CombinedScore$methods(
  initialize = function(project, name, description="", algo="COMBINE_WEIGHTED_LINEAR", .skipI=FALSE){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(project=c("character","Project"),
                       name=c("character"),
                       description=c("character"),
                       algo=c("character"),
                       .skipI=c("logical"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    .global <<- list()
    setName(name)
    setDescription(description)
    account <- .AIEnv[[".ApigeeInsights"]]
    if(Utils.checkClass(project, "Project"))
    {
      if(!project$getSaved())
      {
        tryCatch({
          setProject(account$getProject(project$getName()))
          
        }, AIErr=function(err){
          if(err$code==21)
          {
            Utils.info(err$message)
            project$store()
            setProject(project)
          }
          else
          {
            stop(err)
          }
        })
      }
      else
      {
        setProject(project)
      }
    }
    else{
      tryCatch({
        setProject(account$getProject(project))
      },AIErr=function(x){
        Utils.info(x$message)
        setProject(Project$new(.account=account, .name=project))
        getProject()$store()
      }) 
    }
    if(.skipI)
    {
      Utils.info("CombinedScore created successfully")
      return()
    }
    tryCatch({
      combinedScoreNames <- getProject()$getCombinedScoreList()$name
      Utils.info("Checking for combinedScore duplicity...")
      if(name %in% combinedScoreNames)
      {
        stop("CombinedScore - ",name," already available. Use getCombinedScore method to fetch the combinedScore or change the combinedScore name")
      }
    }, AIErr=function(err){
    })
    setSaved(FALSE)
    Utils.info("CombinedScore created successfully")
  },
  getCombinedReportList = function(){
    pn <- getProject()$getName()
    url <- generateCEndPoint()
    params = list(accountId=getProject()$getAccount()$getId(),token=getProject()$getAccount()$getToken(),entityIdType="name",project=pn)
    Utils.info("Fetching score list...")
    tryCatch({
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })  
    Utils.info("Fetching successful")
    ld <- data.frame(do.call("rbind",data$combinedReports))
    return(ld)
  },
  getCombinedReport = function(name)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    Utils.signatureValidation(params, globalSignatures=globalSignatures)
    url <- generateCEndPoint(name)
    pn <- getProject()$getName()
    params = list(accountId=getProject()$getAccount()$getId(),token=getProject()$getAccount()$getToken(),entityIdType="name",project=pn)
    Utils.info(paste("Fetching combined report - ",name,"...",sep="",collapse=""))
    tryCatch({
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES$ENTITY$COMBINED_REPORT,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<COMBINED_REPORT>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })  
    Utils.info("Fetching successful")
    report <- Utils.buildCombinedReportFromJson(.self,data$combinedReport,.skipI=TRUE)
    report$setSaved(TRUE)
    return(report)
  },
  openJobManager = function()
  {
    url <- getProject()$getAccount()$getConfig()$jobManager
    if(!is.null(url))
    {   
      mn <- curlEscape(getName())
      url <- paste(url,"#resource=/management/jobBrowser&objectType=CombinedScore&objectName=",mn,"&objectId=",getId(),"&token=",getProject()$getAccount()$getToken(),"&userName=",getProject()$getAccount()$getUser(),sep="")
    }   
    else
    {   
      stop("jobManager base url not available in the configuration")
    }   
    browseURL(url)
  },
  addScore = function(score=NULL, weight = 1.0)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(score=c("Score","missing"),
                       weight=c("numeric"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    #score$.global$weight = weight
    
    sProj <- score$getModel()$getProject()$getName()
    sModel <- score$getModel()$getName()
    sName <- score$getName()
    sWeight <- weight
    len <- length(.scores)
    if(len != 0)
    {
      for(i in sort(1:len,decreasing=T))
      {
        lsProj <- .scores[[i]]$project
        lsModel <- .scores[[i]]$model
        lsName <- .scores[[i]]$score
        if((sProj == lsProj && sModel == lsModel && sName == lsName))
        {
          .scores[[i]] <<- NULL
        }
      }
    }
    newEntry <- list()
    newEntry$project <- sProj
    newEntry$model <- sModel
    newEntry$score <- sName
    newEntry$weight <- sWeight
    .scores <<- c(.scores,list(newEntry))
  },
  setProject = function(project){
    signatures <- c("Project")
    if(!Utils.validateSignature(project,signatures))
    {
      stop("Invalid signature : project should be of type ", paste(signatures,collapse=" or "))
    }
    .project <<- project
  },
  show = function()
  {
    cat("Account = ", getProject()$getAccount()$.account)
    cat("\nProject = ", getProject()$getName())
    cat("\nCombinedScore Object :\n\n")
    cat("CombinedScore Name =",getName(),"\n")
    cat("CombinedScore Algo =",getAlgo(),"\n")
    cat("CombinedScore Description =",getDescription(),"\n")
    if(length(getConfig()) > 0)
    {   
      cat("********* CombinedScore Configs *********")
      pandoc.table(as.data.frame(getConfig()), split.cells=50, split.table=1220,style="grid")
    }   
    if(length(.scores) > 0)
    {   
      cat("\n******************* Scores *******************")
      dfa <- Utils.convertToDataFrame(.scores)
      pandoc.table(dfa, split.cells=50, split.table=1220,style="grid")
    }   
  },
  getProject = function(){return(.project)},
  setScores = function(scores)
  {
    signatures <- c("list-Score")
    if(!Utils.validateSignature(scores,signatures))
    {
      stop("Invalid signature : scores should be of type ", paste(signatures,collapse=" or "))
    }
    .scores <<- scores
  },
  setRecoThresholds = function(key, value)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(key=c("character"),
                       value=c("character","numeric"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(class(value) == "numeric")
    {
      value <- sprintf("%.1f",value)
    }
    thresholds=list(list(nodes = paste(key, sep=",",collapse=","), threshold=value))
    
    key <- Utils.trim(key)
    config <- getConfig()
    config[["perNodeThresholds"]] <- c(config[["perNodeThresholds"]],thresholds)
    setConfig(config)
  },
  getScores = function()
  {
    return(.scores)
  },
  setConfig = function(config){
    signatures <- c("list")
    if(!Utils.validateSignature(config,signatures))
    {
      stop("Invalid signature : config should be of type ", paste(signatures,collapse=" or "))
    }
    .config <<- c(config)
  },
  getConfig = function(){return(.config)},
  setName = function(name){
    signatures <- c("character")
    if(!Utils.validateSignature(name,signatures))
    {
      stop("Invalid signature : name should be of type ", paste(signatures,collapse=" or "))
    }
    .name <<- name
  },
  getName = function(){return(.name)},
  setAlgo = function(algo){
    signatures <- c("character")
    if(!Utils.validateSignature(algo,signatures))
    {
      stop("Invalid signature : algo should be of type ", paste(signatures,collapse=" or "))
    }
    if(algo != "COMBINE_WEIGHTED_LINEAR" && algo != "MAX" && algo != "COMBINE_WEIGHTED_LINEAR_EQUAL" && algo != "RECO")
    {
      stop("Invalid algo. Algo can be COMBINE_WEIGHTED_LINEAR or MAX or COMBINE_WEIGHTED_LINEAR_EQUAL or RECO")
    }
    if(algo == "RECO")
    {
      
      cat("By default 0 is used as the threshold to filter out users using the first score. If you need a different threshold, please use setConfiguration method with key = \"respThreshold\"\n")
    }
    .algo <<- algo
  },
  getAlgo = function(){return(.algo)},
  setDescription = function(description){
    signatures <- c("character")
    if(!Utils.validateSignature(description,signatures))
    {
      stop("Invalid signature : description should be of type ", paste(signatures,collapse=" or "))
    }
    .description <<- description
  },
  getDescription = function(){return(.description)},
  setId = function(id){
    signatures <- c("numeric")
    if(!Utils.validateSignature(id,signatures))
    {
      stop("Invalid signature : id should be of type ", paste(signatures,collapse=" or "))
    }
    .id <<- id
  },
  getId = function(){return(.id)},
  setSaved = function(saved){
    signatures <- c("logical")
    if(!Utils.validateSignature(saved,signatures))
    {
      stop("Invalid signature : saved should be of type ", paste(signatures,collapse=" or "))
    }
    .saved <<- saved
  },
  getSaved = function(){return(.saved)},
  setConfiguration = function(key, value)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(key=c("character"),
                       value=c("character","numeric"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(!(key %in% c("numReducers","recoThreshold")))
    {
      stop(key," is not supported.")
    }
    if(class(value) == "numeric")
    {   
      value <- sprintf("%.1f",value)
    }   
    key <- Utils.trim(key)
    config <- getConfig()
    config[[key]] <- value
    setConfig(config)
  },
  cloneObject = function(name, description="")
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(name=c("character"),
                       description = "character")
    Utils.signatureValidation(params, signatures, globalSignatures)
    clonedCombinedScore <- CombinedScore$new(getProject(),name,description)
    clonedCombinedScore$setAlgo(getAlgo())
    if(Utils.isSet(getConfig()))
      clonedCombinedScore$setConfig(getConfig())
    clonedCombinedScore$.global <- .global
    clonedCombinedScore$.scores <- .scores
    clonedCombinedScore$setSaved(FALSE)
    return(clonedCombinedScore)
  },
  toJsonStructure = function()
  {
    obj <- list()
    if(Utils.isSet(.name))  
      obj[["name"]] <- .name
    if(Utils.isSet(.description))
      obj[["description"]] <- .description
    if(Utils.isSet(.algo))
      obj[["algo"]] <- .algo
    if(Utils.isSet(.project))
      obj[["project"]] <- .project$getName()
    if(Utils.isSet(.config))
      obj[["config"]] <- .config
#     scoreObj <- list()
#     scoreList <- lapply(.scores, function(x){
#         y <- list()
#         y$project <- x$getModel()$getProject()$getName()
#         y$model <- x$getModel()$getName()
#         y$score <- x$getName()
#         y$weight <- x$.global$weight
#         return(y)
#       }
#     )
    # obj[["scores"]] <- scoreList
    obj[["scores"]] <- .scores
    if(Utils.isSet(.id))
    {
      obj[["id"]] <- .id
    }
    if(!is.null(.global$visibility))
    {
      obj[["visibility"]] <- .global$visibility
    }
    return(obj)
  },
  setVisibility = function(flag="External")
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(
      flag=c("character")
    )
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(length(flag) == 1 && (flag == "External" || flag == "Internal"))
    {
      .global$visibility <<- flag
    }
  },
  generateCEndPoint = function(id="")
  {
    id <- curlEscape(id)
    host <- Utils.trim(generateEndPoint(getName()))
    if(id != "")
    {
      id <- paste("/",id,sep="")
    }
    return(paste(host,"/combinedReports",id,sep=""))
  },
  generateEndPoint = function(id="")
  {
    id <- curlEscape(id)
    host <- Utils.trim(getProject()$getAccount()$getHost())
    if(id != "") 
    {   
      id <- paste("/",id,sep="")
    }   
    return(paste(host,"/modeling/combinedScores",id,sep=""))
  },
  store = function()
  {
    if(getProject()$getSaved()== FALSE)
    {    
      stop("Save the project in order to continue")
    }   
    if(getAlgo() == "RECO" && length(getScores()) != 2)
    {
      stop("RECO Algorithm takes only two scores.")
    }
    if(getSaved() == TRUE){
      return(update())
    }
    name <- getName()
    url <- generateEndPoint()
    params = list(accountId=getProject()$getAccount()$getId(),token=getProject()$getAccount()$getToken(),entityIdType="name")
    #cat(params$accountId,params$token)
    jsonObj = toJsonStructure()
    JSON = toJSON(jsonObj)
    tryCatch({
      data <- sendRequest(url,"post",params,JSON)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {    
        stop(x)
      }    
      template <- paste(MESSAGES$ENTITY$COMBINED_SCORE,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<COMBINED_SCORE>"]] <- name 
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })   
    
    #Utils.debug("storeCombinedScore",data)
    setSaved(TRUE)
    setId(data$combinedScoreId)
  },
  update = function()
  {
    name <- getName()
    url <- generateEndPoint(name)
    params = list(accountId=getProject()$getAccount()$getId(),token=getProject()$getAccount()$getToken(),entityIdType="name",project=getProject()$getName())
    if(!getClickStream()$getOffer()$getImpression()$isSet())
    {    
      if(!is.null(getClickStream()$getOffer()$getConfig()$offerKey))
      {    
        jKey <- getClickStream()$getOffer()$getResponse()$getConfig()$joinKey
        oKey <- getClickStream()$getOffer()$getConfig()$offerKey
        if(!grepl(paste("\\b",oKey,"\\b",sep=""),jKey)  && oKey != "ANY_COLUMN_EVENT")
        {    
          rConfig <- getClickStream()$getOffer()$getResponse()$getConfig()
          rConfig$joinKey <- paste(jKey,oKey,sep=",")
          getClickStream()$getOffer()$getResponse()$setConfig(rConfig)
        }    
      } 
      else
      {
        stop("Prediction dimensions cannot be empty")
      }
    }
    jsonObj = toJsonStructure()
    JSON = toJSON(jsonObj)
    tryCatch({
      data <- sendRequest(url,"put",params,JSON)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {    
        stop(x)
      }    
      template <- paste(MESSAGES$ENTITY$COMBINED_SCORE,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<COMBINED_SCORE>"]] <- name 
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })   
    
    #Utils.debug("storeCombinedScore",data)
    setSaved(TRUE)
  },
  execute = function()
  {
    name <- getName()
    if(getStatus() == "Unsaved")
    {
      store()
    }
    url <- generateEndPoint(name)
    url <- paste(url,"/execute_op",sep="")
    params = list(accountId=getProject()$getAccount()$getId(),token=getProject()$getAccount()$getToken(),entityIdType="name",project=getProject()$getName())
    #cat(params$accountId,params$token)
    tryCatch({
      data <- sendRequest(url,"put",params,"{}")
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {
        stop(x)
      }
      template <- paste(MESSAGES$ENTITY$COMBINED_SCORE,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<COMBINED_SCORE>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })
    
  },
  getStatus = function()
  {
    name <- getName()
    if(getSaved() == FALSE)
    {   
      s <- "Unsaved"
      #Utils.verbose(paste("Status of combinedScore :",object@name,"-> ",s,sep=""))
      return(s)
    }   
    else
    {   
      url <- generateEndPoint(getName())
      url <- paste(url,"/getState_op",sep="")
      params = list(accountId=getProject()$getAccount()$getId(),token=getProject()$getAccount()$getToken(),entityIdType="name",project=getProject()$getName())
      tryCatch({
        data <- sendRequest(url,"get",params)
      },AIErr=function(x){
        if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
        {   
          stop(x)
        }   
        template <- paste(MESSAGES$ENTITY$COMBINED_SCORE,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
        tv <- .AIEnv[[".TEMPLATE_VALUES"]]
        tv[["<COMBINED_SCORE>"]] <- name
        msg <- replaceTemplate(template,tv)
        stop(createAIErr(x$code,msg))
      })  
      #Utils.verbose(paste("Status of combinedScore :",object@name,"->",data$state,sep=""))
      return(data$state)
    }
  },
  stream = function(topN=100,sep="\t")
  {
    acc<- .AIEnv$.ApigeeInsights
    dm <- acc$getDataManager()
    cn <- paste(getProject()$getName(),sep="")
    p <- dm$getPartition(catalog=cn, dataset="SCORE", partition=getName())
    pdf <- p$stream(topN=topN, sep=sep)
    pdf$liftScaled <- NULL
    return(pdf)
  }
)