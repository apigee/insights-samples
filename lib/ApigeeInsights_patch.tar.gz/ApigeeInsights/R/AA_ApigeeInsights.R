# Copyright 2014 Apigee Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#'@import methods
#'@export ApigeeInsights
#'@exportClass ApigeeInsights
ApigeeInsights <- setRefClass("ApigeeInsights", fields = list(.account = "character", .token = "character", .user="character", .host = "character", .id = "numeric", .config="list"))
#'Connect to the Insights system
#'
#'Connects to the Insights system. You can supply all of the connection parameters
#'in the function's parameters, or you can specify some of the parameters by 
#'including them in an optional config file. For parameters you give in a config
#'file, you need not specify values in function params.
#'
#'@param configFile - character : The path to a configuration file.
#'@param org - character : The name of your org. Optional
#'@param account - character : The name of your org. This parameter is deprecated. Please use org parameter instead. Optional
#'@param user - character : The user name.
#'@param password - character : The password.
#'@param host - character : The host path.
#'@param jobManagerBase - character : The base path to the job manager user interface.
#'Used to display the job manager when \code{\link{openJobManager}} is called.
#'@examples 
##' connect(configFile, org, user, password, host, jobManagerBase)
##' 
#'The config file specifies the connection params in JSON format. In the following
#'example function call and config file, params not specified in one are
#'specified in the other: 
#'
#'connect(configFile="retail_sales.cnf",
#'    user="me", org="salesdata", password="mypassword")
#'
#'
#' @seealso \code{\link{getProjectList}} 
#' @seealso \code{\link{getProject}} 
#' @seealso \code{\link{getDataManager}}
#' @return ApigeeInsights
#'@export
connect<- function(configFile=NULL, org=NULL, account = NULL, user=NULL, password=NULL, host=NULL, jobManagerBase=NULL){
  if(!is.null(account))
  {
    warning("'account' parameter is deprecated from 'connect' method. Please use the 'org' parameter instead.")
  }
  else
  {
    account <- org
  }
  config <- list()
  if(!is.null(configFile))
  {
    fp <- file.path(configFile)
    config <- fromJSON(fp, simplify=FALSE, simplifyWithNames=FALSE)
  }
  if(!is.null(user))
  {
    config$user <- user
  }
  if(!is.null(password))
  {
    config$password <- password
  }
  if(!is.null(account))
  {
    config$account <- account
  }
  if(!is.null(host))
  {
    config$host <- host
  }
  if(!is.null(jobManagerBase))
  {
    config$jobManager <- jobManagerBase
  }
  if(length(config$account) == 1)
  {
    account <- config$account
  }
  else if(length(config$org) == 1)
  {
    account <- config$org
  }
  #else
  #{
  #  stop("Org missing from the configuration file")
  #}
  if(length(config$user) == 1)
  {
    user <- config$user
  }
  else
  {
    stop("User missing from the configuration file")
  }
  if(length(config$host) == 1)
  {
    host <- config$host
  }
  else
  {
    stop("Host missing from the configuration file")
  }
  if(length(config$password) == 1)
  {
    password <- config$password
  }
  else
  {
    stop("Password missing from the configuration file")
  }
  #Utils.debug("HOST PATH",host)
  AI <- ApigeeInsights$new(.user=user,.host=host)
  createEnv()
  setInfo(1)
  assign(".isDebug",0, envir=.AIEnv)
  tv <- list()
  tv[["<ACCOUNT>"]] <- account
  tv[["<USER>"]] <- user
  assign(".TEMPLATE_VALUES",tv, envir=.AIEnv)
  jList <- list(user=AI$getUser(), password=password)
  JSON <- toJSON(jList)
  
  endPoint <- AI$generateEndPoint()
  params = list(token="",entityIdType="")
  Utils.info("Connecting to server...")
  tryCatch({
    response <- sendRequest(endPoint,"post",params,JSON,TRUE)
  },AIErr=function(x){
    if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
    {
      stop(x)
    }
    template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
    msg <- replaceTemplate(template)
    stop(createAIErr(x$code,msg))
  })
  AI$setToken(response$token)
  if(!is.null(response$accountId))
  {
    AI$setId(response$accountId)
  }
  config$password <- NULL
  AI$setConfig(config)
  assign(".ApigeeInsights",AI, envir=.AIEnv)
  .AIEnv$.datastore <- NULL
  .AIEnv$.partitions <- NULL
  if(!is.null(account))
  {
    AI$setOrg(account)
  }
  Utils.info("Authentication Successful")
  return(AI)
}
sendRequest <- function(endPoint,type,params,JSON,isAccountOptional = FALSE){
  if(length(endPoint) == 0)
  {
    stop("Internal Error: Send request is empty")
  }
  #url1 <- paste(endPoint,"token=",token,"&accountId=",account,"&entityIdType=",entityIdType,sep="")
  #cat(params$accountId,params$token)
  if(!isAccountOptional && (is.null(params$accountId) || length(params$accountId) == 0))
  {
    stop("OrgName is missing. Please use 'getOrgList' method to get a list of org names and use 'setOrg' method to set the org name.")
  }
  apiToken <- params$token
  p = paste(endPoint,"?accountId=",params$accountId,"&entityIdType=",params$entityIdType,sep="")
  params$token <- NULL
  if(length(params$project) > 0)
  {
    p = paste(p, "&project=",params$project,sep="")
  }
  if(length(params$datastore) > 0)
  {
    p = paste(p, "&datastore=",params$datastore,sep="")
  }
  pVersion <- as.character(packageVersion("ApigeeInsights"))
  caInfo <- system.file("resources","cacert.pem", package="ApigeeInsights")
  opts <- list(httpheader = c('User-Agent' = 'rclient','Authorization' = apiToken, 'Version' = pVersion), cainfo = caInfo)
  if(type == "get")
  {   
    Utils.debug("URL : ",endPoint)
    Utils.debug("Params :\n",toJSON(params,pretty = TRUE))
    Utils.debug("SubmitType : GET")
    resultJSON <- getForm(endPoint,.params = params,.opts = opts)[1]
    result <- fromJSON(resultJSON,simplify=FALSE, simplifyWithNames=FALSE)
  }
  else if(type == "post")
  {
    Utils.debug("URL : ",p)
    Utils.debug("Params :",toJSON(fromJSON(JSON,simplify=FALSE, simplifyWithNames=FALSE),pretty = TRUE))
    Utils.debug("SubmitType : POST")
    resultJSON <- postForm(p,.params = params,
                           .opts = list(postfields = JSON,
                                        httpheader = c('Content-Type' = 'application/json', 'User-Agent' = 'rclient', 'Authorization' = apiToken, 'Version' = pVersion),
                                        cainfo = caInfo))
    
    
    
    result <- fromJSON(resultJSON,simplify=FALSE, simplifyWithNames=FALSE)
  }
  else if(type == "put")
  {
    Utils.debug("URL : ",p)
    Utils.debug("Params :",toJSON(fromJSON(JSON,simplify=FALSE, simplifyWithNames=FALSE),pretty = TRUE))
    Utils.debug("SubmitType : PUT")
    resultJSON <- httpPUT(p,JSON,curl = getCurlHandle(.opts=list(httpheader = c('Content-Type' = 'application/json', 'Accept' = 'application/json', 'User-Agent' = 'rclient', 'Authorization' = apiToken, 'Version' = pVersion), cainfo = caInfo)))
    result <- fromJSON(resultJSON,simplify=FALSE, simplifyWithNames=FALSE)
  } 
  Utils.debug("\nResponse:\n")
  Utils.debug(toJSON(result,pretty = TRUE))
  Utils.debug("\n")
  
  if(Result.isSuccess(result) != TRUE)
  {
    errobj <- result$result$error[[1]]
    stop(AIError(errobj,type="AIErr"))
    #stop(paste("Error:",toJSON(result$result$error[[1]])))
  } 
  return(result$result$data)
}

#'@import methods
#'@export DataManager
#'@exportClass DataManager
DataManager <- setRefClass("DataManager", fields = list(.account = "ApigeeInsights"))

#'@import methods
#'@export Catalog
#'@exportClass Catalog
Catalog <- setRefClass("Catalog", fields = list(.dm = "DataManager", .name = "character", .description = "character"))

#'@import methods
#'@export Dataset
#'@exportClass Dataset
Dataset <- setRefClass("Dataset", fields = list(.catalog = "Catalog", .name = "character", .description = "character", .dataType="character", .delimiter="character", .statistics="list", .schema = "list"))

#'@import methods
#'@export Partition
#'@exportClass Partition
Partition <- setRefClass("Partition", fields = list(.dataset = "Dataset", .datastore = "character", .name = "character", .description = "character", .delimiter="character", .statistics="list", .schema = "list"))

#'@import methods
#'@export Project
#'@exportClass Project
Project <- setRefClass("Project", fields = list(.account = "ApigeeInsights", .id="numeric",.name="character",.description="character",.saved="logical"))

#'@import methods
#'@export Impression
#'@exportClass Impression
Impression <- setRefClass("Impression", fields = list(.datastore = "character", .dataset="Dataset", .partition = "list", .config="list"))

#'@import methods
#'@export Response
#'@exportClass Response
Response <- setRefClass("Response", fields = list(.datastore = "character", .dataset="Dataset", .partition = "list", .config="list"))

#'@import methods
#'@export Profile
#'@exportClass Profile
Profile <- setRefClass("Profile", fields = list(.datastore = "character", .dataset="Dataset", .partition = "list", .config="list"))

#'@import methods
#'@export Activity
#'@exportClass Activity
Activity <- setRefClass("Activity", fields = list(.datastore = "character", .dataset="Dataset", .partition = "list", .config="list"))

#'@import methods
#'@export CombineActivity
#'@exportClass CombineActivity
CombineActivity <- setRefClass("CombineActivity", fields = list(.activity = "list", .profile = "list"))
Offer <- setRefClass("Offer", fields = list(.impression = "Impression", .response = "Response", .config="list"))

#'@import methods
#'@export ClickStream
#'@exportClass ClickStream
ClickStream <- setRefClass("ClickStream", fields = list(.combineActivity = "CombineActivity", .offer = "Offer"))

#'@export Model
#'@exportClass Model
Model <- setRefClass("Model", fields = list(.project = "Project", .clickStream = "ClickStream", .config = "list",.name="character",.description="character",.id="numeric",.saved="logical", .global="list"))

#'@import methods
#'@export Score
#'@exportClass Score
Score <- setRefClass("Score", fields = list(.model = "list", .combineActivity = "CombineActivity", .config = "list",.name="character",.description="character",.id="numeric",.saved="logical", .global="list"))

#'@import methods
#'@export Report
#'@exportClass Report
Report <- setRefClass("Report", fields = list(.score = "list", .offer = "Offer", .config = "list",.name="character",.description="character",.id="numeric",.saved="logical", .global="list"))

#'@import methods
#'@export Dimensions
#'@exportClass Dimensions
Dimensions <- setRefClass("Dimensions", fields = list(.dimensionList = "list", .dimensionListString = "character", .unexpandedDimensions = "character"))

#'@import methods
#'@export ModelRun
#'@exportClass ModelRun
ModelRun <- setRefClass("ModelRun", fields = list(.model = "list", .score = "list", .report = "list", .global="list"))
#' @import methods
BaseStatistics <- setRefClass("BaseStatistics", fields = list(.datastore="character", .dataset="Dataset", .partition="Partition" ,.overAllStats="data.frame", .columnLevelStats="data.frame"))
ApigeeInsights$methods(
  setAccount = function(account){
    signatures <- c("character")
    if(!Utils.validateSignature(account,signatures))
    {
      stop("Invalid signature : account should be of type ", paste(signatures,collapse=" or "))
    }
    orgL <- getOrgList()
    orgId <- unlist(orgL[tolower(orgL$name) == tolower(account),]$id)
    if(is.null(orgId) || length(orgId) == 0)
    {
      stop(paste("Invalid org. Please select from : ", unlist(orgL$name),collapse=",",sep=""))
    }
    setId(orgId)
    .account <<- account
  },
  getAccount = function(){return(.account)},
  setOrg = function(orgName){
    signatures <- c("character")
    if(!Utils.validateSignature(orgName,signatures))
    {
      stop("Invalid signature : org should be of type ", paste(signatures,collapse=" or "))
    }
    orgL <- getOrgList()
    orgId <- unlist(orgL[tolower(orgL$name) == tolower(orgName),]$id)
    if(is.null(orgId) || length(orgId) == 0)
    {
      stop(paste("Invalid org. Please select from : ", unlist(orgL$name),collapse=",",sep=""))
    }
    setId(orgId)
    .account <<- orgName
  },
  getOrg = function(){return(.account)},
  setToken = function(token){
    signatures <- c("character")
    if(!Utils.validateSignature(token,signatures))
    {
      stop("Invalid signature : token should be of type ", paste(signatures,collapse=" or "))
    }
    .token <<- token
  },
  getToken = function(){return(.token)},
  setUser = function(user){
    signatures <- c("character")
    if(!Utils.validateSignature(user,signatures))
    {
      stop("Invalid signature : user should be of type ", paste(signatures,collapse=" or "))
    }
    .user <<- user
  },
  getUser = function(){return(.user)},
  setHost = function(host){
    signatures <- c("character")
    if(!Utils.validateSignature(host,signatures))
    {
      stop("Invalid signature : host should be of type ", paste(signatures,collapse=" or "))
    }
    .host <<- host
  },
  getOrgList = function()
  {
    h <- Utils.trim(getHost())
    url <- paste(h,"/users/~current?",sep="")
    params = list(token=getToken(), account="")
    tryCatch({
      Utils.info("Fetching org list...")
      data <- sendRequest(url,"get",params,NULL,TRUE)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })  
    Utils.info("Fetching successful...")
    lo <- data.frame(do.call("rbind",data$accountList))
    return(lo)
  },
  getHost = function(){return(.host)},
  setId = function(id){
    signatures <- c("numeric")
    if(!Utils.validateSignature(id,signatures))
    {
      stop("Invalid signature : id should be of type ", paste(signatures,collapse=" or "))
    }
    .id <<- id
  },
  getId = function(){return(.id)},
  setConfig = function(config){
    signatures <- c("list")
    if(!Utils.validateSignature(config,signatures))
    {
      stop("Invalid signature : config should be of type ", paste(signatures,collapse=" or "))
    }
    .config <<- c(config)
  },
  getConfig = function(){return(.config)},
  generateEndPoint = function() {
              h <- Utils.trim(getHost())
              return(paste(h,"/accesstokens",sep=""))
        },
  getDataManager = function() {
    return(DataManager$new(.account=.self))
  },
  getProjectList = function()
  {
    h <- Utils.trim(getHost())
    url <- paste(h,"/projects",sep="")
    params = list(accountId=getId(),token=getToken(),entityIdType="name")
    tryCatch({
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })  
    lc <- data.frame(do.call("rbind",data$projects))
    return(lc)
  },
  getProject = function(name){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    Utils.signatureValidation(params, globalSignatures=globalSignatures)
    name <- curlEscape(name)
    h <- Utils.trim(getHost())
    url <- paste(h,"/projects/",name,sep="")
    params = list(accountId=getId(),token=getToken(),entityIdType="name")
    Utils.info(paste("Fetching project - ",name,"...",sep=""))
    tryCatch({
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES$ENTITY$PROJECT,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<PROJECT>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })  
    
    if(length(data$project$description) == 0)
    {
      data$project$description = ""
    }
    project <- Project$new(.account = .self, .name = data$project$name, .description = data$project$description)
    project$setSaved(TRUE)
    Utils.info("Fetching successful")
    return(project)
  }
  )
#' @export
setDebug <- function(x){
  assign(".isDebug",x, envir=.AIEnv)
}

#'Set the catalog.
#'
#'Sets the name of the catalog to use in modeling.
#'
#'@param name character. Name of the catalog. Required. 
#'
#'@seealso \code{\link{Catalog}} 
#'
#'@export
setCatalog <- function(name){
  params <- c(as.list(environment()))
  globalSignatures <- "character"
  Utils.signatureValidation(params, globalSignatures=globalSignatures)
  assign(".catalog",name, envir=.AIEnv)
}
#'@export
setProject <- function(name){
  params <- c(as.list(environment()))
  globalSignatures <- "character"
  Utils.signatureValidation(params, globalSignatures=globalSignatures)
  assign(".project",name, envir=.AIEnv)
}

#'Set the partitions.
#'
#'Sets the names of the Hadoop partitions to use in modeling. Partitions
#'separate uploaded data by date ranges.
#'
#'@param partitions character. Names of partitions. Required. 
#'
#'@seealso \code{\link{Partition}}
#'
#' @export
setPartitions <- function(names){
  params <- c(as.list(environment()))
  globalSignatures <- "character"
  Utils.signatureValidation(params, globalSignatures=globalSignatures)
  assign(".partitions",names, envir=.AIEnv)
}

#'Set the datastore to use.
#'
#'@param name Name of the datastore to use.
#'
#' @export
setDatastore <- function(name){
  params <- c(as.list(environment()))
  globalSignatures <- "character"
  Utils.signatureValidation(params, globalSignatures=globalSignatures)
  assign(".datastore",name, envir=.AIEnv)
}

#' @export
setInfo <- function(x){
  assign(".isInfo",x, envir=.AIEnv)
}
getDatastore <- function()
{
  if(!exists(".AIEnv") || is.null(.AIEnv$.datastore))
  {
    acc <- .AIEnv$.ApigeeInsights
    dm <- DataManager$new(.account=acc)
    ds <- dm$getDefaultDatastore()
    setDatastore(ds)
  }
  datastore <- .AIEnv$.datastore
  return(datastore)
}
createEnv <- function()
{
  if(!exists(".AIEnv") || !is.environment(.AIEnv))
  {
    .AIEnv <<- new.env()
  }
}
getAllPartitions <- function(catalog, dataset, filter, datastore)
{
  if(missing(datastore))
  {
    ds <- getDatastore()
  }
  else
  {
    ds <- datastore
  }
  if(is.character(dataset))
  {
    acc <- .AIEnv$.ApigeeInsights
    dm <- acc$getDataManager()
    c <- dm$getCatalog(catalog)
    d <- c$getDataset(dataset)
  }
  else
  {
    d <- dataset
  }
  if(missing(filter))
  {
    allPartitions <- d$getPartitionList()
    if(nrow(allPartitions) == 0)
    {    
      stop("No partitions available for the given catalog and dataset")
    }    
    partitionsInDefaultDatastore <- unlist(subset(allPartitions, datastore == ds)[,"name"])
	names(partitionsInDefaultDatastore) <- NULL
  }
  else 
  {
    partitionsInDefaultDatastore <- filter
  }
  if(is.null(partitionsInDefaultDatastore))
  {
    stop("Datastore might be invalid")
  }
  partitions <- d$getPartitions(partitionsInDefaultDatastore, datastore=ds)
  return(partitions)
}
#'@export
setMethod("show","data.frame",function(object){ if(nrow(object) > 0 ) {pandoc.table(object, split.cells=150, split.table=1120,style="grid")}})
#'@export
setMethod("print","data.frame",function(x){ if(nrow(x) > 0 ) {pandoc.table(x, split.cells=150, split.table=1120,style="grid")}})

#'Open the Job Manager.
#'
#'Use this method to open the job manager and get details of jobs.
#'
#'@param object \code{\link{Model}} / \code{\link{Score}} / \code{\link{Report}} / \code{\link{ModelRun}}. The object to set as context for the job manager.
#'
#'@examples 
##' openJobManager(model)
##' openJobManager(score)
##' openJobManager(report)
#' 
#'@usage openJobManager(object)
#'
#'object$openJobManager()
#'
#'@export
openJobManager <- function(object)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","Score","Report","ModelRun"))
  Utils.signatureValidation(params, signatures)
  object$openJobManager()
}

#'Set training data as a split.
#'
#'Sets the portion of data to use for training the model.
#'
#'@param object \code{\link{Model}}. The model in which to set
#'training data.
#'@param totalBucket Number. Total number of buckets. Required. 
#'@param split character. The split values to be selected for training. Required.
#' 
#'@examples 
#' model <- setTestingSplit(model, 100,41:99)
#' model$setTestingSplit(100,41:99)
#'
#'@usage setTrainingSplit(object, totalBucket, split=NULL)
#'
#'object$setTrainingSplit(totalBucket, split=NULL)
#'
#'@export
setTrainingSplit <- function(object, totalBucket, split=NULL)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model"),
                     totalBucket="numeric")
  Utils.signatureValidation(params, signatures)
  object$setTrainingSplit(totalBucket, split)
}
#'Set training data as a percentage.
#'
#'Sets the percentage of data to use for training the model.
#'
#'@param object \code{\link{Model}}. The model in which to set training data.
#'@param percentage number. The amount of data in terms of percentages to be considered for training. Required. 
#'
#'@usage setTrainingPercent(object, split)
#'
#'object$setTrainingPercent(object, split)
#'
#'@export
setTrainingPercent = function(object, split)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model"),
                     split="numeric")
  Utils.signatureValidation(params, signatures)
  object$setTrainingPercent(split)
}
#'Add activity event datasets.
#'
#'Add activity datasets to the specified model or score. This function returns an 
#'instance of the class passed as its \code{object} parameter.
#'
#'@param object \code{\link{Model}} / \code{\link{Score}} / 
#'\code{\link{Report}} / \code{\link{ModelRun}}. The object to which the event has to be added.
#'@param dataset character. The name of the dataset to be used as activity dataset. Required.
#'@param dimensions character/ \code{\link{Dimensions}} / list. The dimension (or a set of dimensions) representing the entity on which an activity is taking place. This parameter can be set only for Model and ModelRun object.
#'If the type is character vector, then each item in the vector is considered to be a simple dimension.
#'If the type is Dimensions, then it contains a mixture of simple and complex dimensions.
#'If the type is list, then it is similar to type 'Dimensions' but the names are derived. Required. 
#'@param catalog character. Name of the catalog. Optional if catalog is set using the global setter function "setCatalog".
#'@param metric character. The metric to be used. Optional. Default: metrics_count (Count of rows). 
#'This parameter can be set only for Model and ModelRun object.
#'@param startTime character / POSIXlt (\%Y-\%m-\%d \%H:\%M:\%S). The start date filter for this dataset. Optional.
#'\cr Default: 
#'\itemize{
#'\item If startTime is set using the object's global setter function "setDateFilter". This will take precedence.
#'\item If parameter object is of type Model, then the startTime is derived from the data.
#'\item If parameter object is of type Score, then the startTime is derived from the model dataset time window. i.e, If the model dataset time window is M months and target score time is T, then startTime for Score object is (T - M months).
#'}
#'@param endTime character / POSIXlt (\%Y-\%m-\%d \%H:\%M:\%S). The end date filter for this dataset. Optional.
#'\cr Default: 
#'\itemize{
#'\item If endTime is set using the object's global setter function "setDateFilter". This will take precedence.
#'\item If parameter object is of type Model, then the endTime is derived from the data.
#'\item If parameter object is of type Score, then the endTime will be (targetScoreTime - 1 sec).
#'}
#'@param partitions character. A character vector of partition names. Optional. 
#'\cr It is always best to *not* set this parameter unless you are an advanced user.
#'\cr Default by precedence: 
#'\itemize{
#'\item partitions set using the global setter function "setPartitions".
#'\item partitions derived based on startTime and endTime.
#'}
#'@param datastore character. The name of the datastore. Optional.
#'\cr It is always best to *not* set this parameter unless you are an advanced user.
#'\cr Default by precedence: 
#'\itemize{
#'\item datastore set using the global setter function \code{\link{setDatastore}}.
#'\item datastore is set as persistent datastore.
#'}
#'@usage addActivityEvent(object, dataset, dimensions, catalog = NULL, metric = NULL, 
#'startTime = NULL, endTime = NULL, partitions = NULL, datastore = NULL)
#'
#'object$addActivityEvent(dataset, dimensions, catalog = NULL, metric = NULL, 
#'startTime = NULL, endTime = NULL, partitions = NULL, datastore = NULL)
#'
#'@export
addActivityEvent <- function(object, dataset, dimensions, catalog=NULL, metric=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","Score","ModelRun"))
  Utils.signatureValidation(params, signatures)
  if(Utils.checkClass(object, "Score"))
  {
    object$addActivityEvent(dataset, catalog, startTime, endTime, partitions, datastore)
  }
  else
  {
    object$addActivityEvent(dataset, dimensions, catalog, metric, startTime, endTime, partitions, datastore)
  }
}

#'@export
setImpRespConfig <- function(object, joinWindow, joinMode)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","ModelRun"))
  Utils.signatureValidation(params, signatures)
  object$setImpRespConfig(joinWindow, joinMode)
}

#'Set date range for included data.
#'
#'Sets the date range for selecting data in included datasests.
#'
#'@param object \code{\link{Model}} / \code{\link{Score}} / \code{\link{Report}}. The
#'object in which to set the range. 
#'@param startTime character / Date (\%Y-\%m-\%d \%H:\%M:\%S). The start date filter for all the datasets configured in the model. Optional is endTime is provided. 
#'@param endTime character / Date (\%Y-\%m-\%d \%H:\%M:\%S). The end date filter for the datasets configured in the model. Optional if startTime is provided. 
#'
#'@usage setDateFilter(object, startTime=NULL, endTime=NULL)
#'
#'object$setDateFilter(startTime=NULL, endTime=NULL)
#'
#'@export
setDateFilter <- function(object, startTime=NULL, endTime=NULL)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","Score","Report"))
  Utils.signatureValidation(params, signatures)
  object$setDateFilter(startTime, endTime)
}
#'Set configuration.
#'
#'Sets the configuration to use.
#'
#'@param object \code{\link{Model}} / \code{\link{Score}} / \code{\link{Report}}. The
#'object in which to set the configuration.
#'@param key character. The name of the configuration. Required. 
#'@param value character. The value of the configuration. Required. 
#'
#'@usage setConfiguration(object, key, value)
#'
#'object$setConfiguration(key, value)
#'
#'@export
setConfiguration <- function(object, key, value)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","Score","Report"))
  Utils.signatureValidation(params, signatures)
  object$setConfiguration(key, value)
}

#'Set score type
#'
#'Sets the score type (lift or propensity). If this is not used to set the score type, by default it is lift.
#'Lift is the increase in propensity for the user to respond to the offer relative to the average user, 
#'whereas the propensity is the likelihood of a user responding to an offer based on the micro segments he belongs to.
#'
#'@param object \code{\link{Score}} / \code{\link{ModelRun}} . The
#'object in which to set the score type
#'@param value character. The value of the score type (lift or propensity) Required. 
#'
#'@usage setScoreType(object, value)
#'
#'object$setScoreType(value)
#'
#'@export
setScoreType <- function(object, value)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Score","ModelRun"))
  Utils.signatureValidation(params, signatures)
  object$setScoreType(value)
}
#'Set profile data.
#'
#'Sets the dataset to use for profile data.
#'
#'@param object \code{\link{Model}} / \code{\link{ModelRun}}. The object in 
#'which to set the profile data.
#'@param catalog character. Name of the catalog. Optional if catalog is set using the global setter function "setCatalog". 
#'@param dataset character. The name of the dataset to be used as profile dataset. Required. 
#'@param dimensions character / \code{\link{Dimensions}} / list. The dimension (or a set of dimensions) representing the profile attributes. Required.  This parameter can be set only for Model and ModelRun object.
#'@param partitions character. List of partition names. Optional. Default: Considers all partitions.
#'@param datastore character. The name of the datatstore. Optional. Default: By default considers persistent datastore.
#'
#'@usage setProfile(object, dataset, dimensions, catalog=NULL, partitions=NULL, datastore=NULL)
#'
#'object$setProfile(dataset, dimensions, catalog=NULL, partitions=NULL, datastore=NULL)
#'
#'@export
setProfile <- function(object, dataset, dimensions, catalog=NULL, partitions=NULL, datastore=NULL)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","ModelRun"))
  Utils.signatureValidation(params, signatures)
  object$setProfile(dataset, dimensions, catalog, partitions, datastore)
}

#'Clone an object.
#'
#'Clone the specified object with a new name and description.
#'
#'@param object \code{\link{Model}} / \code{\link{ModelRun}} / \code{\link{Score}} / \code{\link{Report}}. The object to clone.
#'@param name Name to use for the new object.
#'@param description Description to use for the new object.
#'@return An instance of the new object.
#'
#'@usage cloneObject(object, name, description="", targetScoreTime=NULL)
#'
#'object$cloneObject(name, description="", targetScoreTime=NULL)
#'
#'@export
cloneObject <- function(object, name, description="", targetScoreTime=NULL)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","ModelRun","Score","Report"))
  Utils.signatureValidation(params, signatures)
  if(Utils.checkClass(object,"Score" || Utils.checkClass(object,"ModelRun")))
  {
    return(object$cloneObject(name, description, targetScoreTime))
  }
  return(object$cloneObject(name, description))
}

#'Add a response event dataset.
#'
#'Adds a response dataset to the specified model or report. You can add only one dataset as a response. This function returns an instance of the class passed as its \code{object} parameter.
#'
#'@param object \code{\link{Model}} / \code{\link{Report}} / \code{\link{ModelRun}} The 
#'object in which to add the dataset.
#'@param dataset character. The name of the dataset to be used as response dataset. Required.
#'@param predictionDimensions character. The dimension (or a set of dimensions) representing the entity to which the consumer responds. Optional if it is provided in setImpressionEvent.
#'@param catalog character. Name of the catalog. Optional if catalog is set using the global setter function "setCatalog".
#'@param metric character. The metric to be used. Optional. Default: metrics_count (Count of rows). 
#'This parameter can be set only for Model and ModelRun object.
#'@param startTime character / POSIXlt (\%Y-\%m-\%d \%H:\%M:\%S). The start date filter for this dataset. Optional.
#'\cr Default: 
#'\itemize{
#'\item If startTime is set using the object's global setter function "setDateFilter". This will take precedence.
#'\item If parameter object is of type Model, then the startTime is derived from the data.
#'\item If parameter object is of type Score, then the startTime is derived from the model dataset time window. i.e, If the model dataset time window is M months and target score time is T, then startTime for Score object is (T - M months).
#'}
#'@param endTime character / POSIXlt (\%Y-\%m-\%d \%H:\%M:\%S). The end date filter for this dataset. Optional.
#'\cr Default: 
#'\itemize{
#'\item If endTime is set using the object's global setter function "setDateFilter". This will take precedence.
#'\item If parameter object is of type Model, then the endTime is derived from the data.
#'\item If parameter object is of type Score, then the endTime will be (targetScoreTime - 1 sec).
#'}
#'@param partitions character. A character vector of partition names. Optional. 
#'\cr It is always best to *not* set this parameter unless you are an advanced user.
#'\cr Default by precedence: 
#'\itemize{
#'\item partitions set using the global setter function "setPartitions".
#'\item partitions derived based on startTime and endTime.
#'}
#'@param datastore character. The name of the datastore. Optional.
#'\cr It is always best to *not* set this parameter unless you are an advanced user.
#'\cr Default by precedence: 
#'\itemize{
#'\item datastore set using the global setter function \code{\link{setDatastore}}.
#'\item datastore is set as persistent datastore.
#'}
#'@usage setResponseEvent(object, dataset, predictionDimensions, catalog = NULL, metric = NULL, 
#'startTime = NULL, endTime = NULL, partitions = NULL, datastore = NULL)
#'
#'object$setResponseEvent(dataset, predictionDimensions, catalog = NULL, metric = NULL, 
#'startTime = NULL, endTime = NULL, partitions = NULL, datastore = NULL)
#'
#'@export
setResponseEvent <- function(object, dataset, predictionDimensions=NULL, catalog=NULL, metric=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","Report","ModelRun"))
  Utils.signatureValidation(params, signatures)
  if(Utils.checkClass(object, "Report"))
  {
    object$setResponseEvent(dataset, catalog, startTime, endTime, partitions, datastore)
  }
  else
  {
    object$setResponseEvent(dataset, predictionDimensions, catalog, metric, startTime, endTime, partitions, datastore)
  }
}
#'Set impression data.
#'
#'Sets the dataset to use for impression data.
#'
#'@param object \code{\link{Model}} / \code{\link{Report}} / \code{\link{ModelRun}} The 
#'object in which to add the dataset.
#'@param dataset character. The name of the dataset to be used as impression dataset. Required. 
#'@param predictionDimensions character. The dimension (or a set of dimensions) representing the entity to which the consumer responds. Optional if it is provided in setResponseEvent.
#'@param responseMerge List. A list containing response and impression fields to be used as joinKeys (The user can use the ApigeeInights::merge method to generate the list). Optional (In case of impression less model).
#'@param catalog character. Name of the catalog. Optional if catalog is set using the global setter function "setCatalog". 
#'@param metric character. The metric representing the measure of responses. Optional. Default: metrics_count (Count of rows).
#'This parameter can be set only for Model and ModelRun object.
#'@param startTime character / POSIXlt (\%Y-\%m-\%d \%H:\%M:\%S). The start date filter for this dataset. Optional.
#'\cr Default: 
#'\itemize{
#'\item If startTime is set using the object's global setter function "setDateFilter". This will take precedence.
#'\item If parameter object is of type Model, then the startTime is derived from the data.
#'\item If parameter object is of type Score, then the startTime is derived from the model dataset time window. i.e, If the model dataset time window is M months and target score time is T, then startTime for Score object is (T - M months).
#'}
#'@param endTime character / POSIXlt (\%Y-\%m-\%d \%H:\%M:\%S). The end date filter for this dataset. Optional.
#'\cr Default: 
#'\itemize{
#'\item If endTime is set using the object's global setter function "setDateFilter". This will take precedence.
#'\item If parameter object is of type Model, then the endTime is derived from the data.
#'\item If parameter object is of type Score, then the endTime will be (targetScoreTime - 1 sec).
#'}
#'@param partitions character. A character vector of partition names. Optional. 
#'\cr It is always best to *not* set this parameter unless you are an advanced user.
#'\cr Default by precedence: 
#'\itemize{
#'\item partitions set using the global setter function "setPartitions".
#'\item partitions derived based on startTime and endTime.
#'}
#'@param datastore character. The name of the datastore. Optional.
#'\cr It is always best to *not* set this parameter unless you are an advanced user.
#'\cr Default by precedence: 
#'\itemize{
#'\item datastore set using the global setter function \code{\link{setDatastore}}.
#'\item datastore is set as persistent datastore.
#'}
#'@usage setImpressionEvent(object, dataset, predictionDimensions=NULL, responseMerge, catalog=NULL, metric=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
#'
#'object$setImpressionEvent(dataset, predictionDimensions=NULL, responseMerge, catalog=NULL, metric=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
#'
#'@export 
setImpressionEvent <- function(object, dataset, predictionDimensions=NULL, responseMerge, catalog=NULL, metric=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","Report","ModelRun"))
  Utils.signatureValidation(params, signatures)
  if(Utils.checkClass(object, "Report"))
  {
    object$setImpressionEvent(dataset, catalog, startTime, endTime, partitions, datastore)
  }
  else
  {
    object$setImpressionEvent(dataset, predictionDimensions, responseMerge, catalog, metric, startTime, endTime, partitions, datastore)
  }
}

#'Convert to JSON.
#'
#'Returns the specified object as JSON.
#'
#'@param object \code{\link{Model}} / \code{\link{Report}} / \code{\link{Score}} The 
#'object to convert.
#'
#'@usage toJsonStructure(object)
#'
#'object$toJsonStructure()
#'
#'@export
toJsonStructure <- function(object)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","Report","Score"))
  Utils.signatureValidation(params, signatures)
  return(object$toJsonStructure())
}

#'Store object configuration.
#'
#'Stores the configuration for the specified object in the Insights
#'data store.
#'
#'@param object \code{\link{Model}} / \code{\link{Report}} / \code{\link{Score}} / \code{\link{ModelRun}} The object to store.
#'
#'@usage store(object)
#'
#'object$store()
#'
#'@export
store <- function(object)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","Report","Score","ModelRun"))
  Utils.signatureValidation(params, signatures)
  object$store()
}

#'Execute a model object.
#'
#'Executes the specified model object.
#'
#'@param object \code{\link{Model}} / \code{\link{Report}} / \code{\link{Score}} / \code{\link{ModelRun}} The object to execute.
#'
#'@usage execute(object)
#'
#'object$execute()
#'
#'@export
execute <- function(object)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","Report","Score","ModelRun"))
  Utils.signatureValidation(params, signatures)
  object$execute()
}

#'Get object status.
#'
#'Gets state for the object. Examples of status include Unsaved, Saved, 
#'Submitted, Running, and Completed.
#'
#'@param object \code{\link{Model}} / \code{\link{Score-class}} /
#'\code{\link{Report-class}} / \code{\link{ModelRun-class}}. The object for 
#'which you want status.
#'@return character (Unsaved, Saved, Submitted, Running, Failed, Completed)
#'
#'@usage getStatus(object)
#'
#'object$getStatus()
#'
#'@export
getStatus <- function(object)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","Report","Score","ModelRun"))
  Utils.signatureValidation(params, signatures)
  return(object$getStatus())
}

#'Build and validate a model.
#'
#'Builds and validates the specified modelrun.
#'
#'@param object \code{\link{ModelRun}} The modelrun to build and validate.
#'
#'@usage buildAndValidate(object)
#'
#'object$buildAndValidate()
#'
#'@export
buildAndValidate <- function(object)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("ModelRun"))
  Utils.signatureValidation(params, signatures)
  object$buildAndValidate()
}

#'Get a validation report.
#'
#'Gets the validation report for the specified modelrun.
#'
#'@param object \code{\link{ModelRun}} The modelrun for which to get the validation report.
#'@return The \code{\link{Report}}.
#'
#'@usage getValidationReport(object)
#'
#'object$getValidationReport()
#'
#'@export
getValidationReport <- function(object)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("ModelRun"))
  Utils.signatureValidation(params, signatures)
  return(object$getValidationReport())
}

#'@export
getScore <- function(object, name)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model"))
  Utils.signatureValidation(params, signatures)
  return(object$getScore(name))
}
#'Stream data.
#'
#'Streams data from the specified object.
#'
#'@param object \code{\link{Model}} / \code{\link{Report}} / \code{\link{Score}} / \code{\link{ModelRun}} The object to stream.
#'@param topN The maximum number of rows to stream.
#'@param sep The characters to use as a separator between columns, such as '\\t' for tab.
#'@return The stream.
#'
#'@usage stream(object, topN, sep)
#'
#'object$stream(topN, sep)
#'
#'@export
stream <- function(object, topN,sep)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model","Report","Score","ModelRun"))
  Utils.signatureValidation(params, signatures)
  if(missing(topN) && missing(sep))
  {
    return(object$stream())
  }
  if(missing(sep))
  {
    return(object$stream(topN))
  }
  if(missing(topN))
  {
    return(object$stream(sep))
  }
  return(object$stream(topN, sep))
}
#'@export
getScoreList <- function(object)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Model"))
  Utils.signatureValidation(params, signatures)
  return(object$getScoreList())
}

#'Set scoring data split.
#'
#'Splits the data into buckets, then specifies which of those buckets
#'to use for scoring.
#'
#'@param object \code{\link{Score}}. The score for which to set the split.
#'@param totalBucket Number. Total number of buckets. Required. 
#'@param split character. The split values to be selected for training. Required. 
#'
#'@examples 
#' score <- setTestingSplit(score, 100,41:99)
#' score$setTestingSplit(100,41:99)
#' 
#'@usage setScoringSplit(object, totalBucket, split=NULL)
#'
#'object$setScoringSplit(totalBucket, split=NULL)
#'
#'@export
setScoringSplit <- function(object, totalBucket, split=NULL)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Score"))
  Utils.signatureValidation(params, signatures)
  object$setScoringSplit(totalBucket, split=NULL)
}

#'Set scoring data percentage.
#'
#'Sets the percentage of data to use for scoring.
#'
#'@param object \code{\link{Score}}. The score for which to set the percentage.
#'@param split Number. The amount of data in terms of percentages to be considered for testing. Required. 
#'
#'@usage setScoringPercent(object, split)
#'
#'object$setScoringPercent(split)
#'
#'@export
setScoringPercent <- function(object, split)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Score"))
  Utils.signatureValidation(params, signatures)
  object$setScoringPercent(split)
}

#'@export
getReport <- function(object, name)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Score"))
  Utils.signatureValidation(params, signatures)
  return(object$getReport(name))
}
#'@export
getReportList <- function(object)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Score"))
  Utils.signatureValidation(params, signatures)
  return(object$getReportList())
}

#'Plot a report.
#'
#'Plots a report for the specified object.
#'
#'@param object \code{\link{Report}} / \code{\link{ModelRun}}
#'@param type character. Possible values are AUC, GAIN, LIFT
#'@param predictionDimensionValue character. The value of the predictionDimension. Optional. Default: Takes the first available value.
#'@param sep
#'
#'@usage plotReport(object, type="AUC", predictionDimensionValue=NULL, sep="\t")
#'
#'object$plot(type="AUC",predictionDimensionValue=NULL, sep="\t")
#'
#'@export
plotReport = function(object, type="AUC",predictionDimensionValue=NULL, sep="\t") {
  params <- c(as.list(environment()))
  signatures <- list(object=c("Report","ModelRun"))
  Utils.signatureValidation(params, signatures)
  object$plot(type, predictionDimensionValue, sep)
}

#'Set testing split.
#'
#'Use this method to split the data and use parts of the split for report.
#'
#'@param object \code{\link{Report}}. The report in which to set the split.
#'@param totalBucket character. Total number of buckets.
#'@param split character. Split value.
#'@examples 
#' report <- setTestingSplit(report, 100,41:99)
#' report$setTestingSplit(100,41:99)
#'
#'@usage setTestingSplit(object, totalBucket, split=NULL)
#'
#'object$setTestingSplit(totalBucket, split=NULL)
#'
#'@export
setTestingSplit <- function(object, totalBucket, split=NULL)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Report"))
  Utils.signatureValidation(params, signatures)
  object$setTestingSplit(totalBucket, split=NULL)
}

#'Set testing percent.
#'
#'Use this method to specify the percentage of data to use for reporting.
#'
#'@param object \code{\link{Report}}. The report in which to set the testing data.
#'@param split character. Split value.
#'
#'@usage setTestingPercent(object, split)
#'
#'object$setTestingPercent(split)
#'
#'@export
setTestingPercent <- function(object, split)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("Report"))
  Utils.signatureValidation(params, signatures)
  object$setTestingPercent(split)
}


#'Get a list of projects.
#'
#'Gets a list of the projects within the scope of the current
#'account.
#'
#'@param object \code{\link{ApigeeInsights}}. An ApigeeInsights instance.
#'@return A data frame representing available \code{\link{Project}} instances.
#'@usage getProjectList(object)
#'
#'object$getProjectList()
setGeneric("getProjectList",
           function(object) {
             standardGeneric("getProjectList")
           })
#'@export
setMethod("getProjectList", signature(object="missing"),
          function(object) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getProjectList())
          })
#'@export
setMethod("getProjectList", signature(object="ApigeeInsights"),
          function(object) {
            return(object$getProjectList())
          })


#'Get a project.
#'
#'Retrieves the specified project.
#'
#'@param object \code{\link{ApigeeInsights}}. An ApigeeInsights instance.
#'@param name character. Name of the project to get.
#'@return \code{\link{Project}}
#'
#'@usage getProject(object, name)
#'
#'object$getProject(name)
setGeneric("getProject",
           function(object,...) {
             standardGeneric("getProject")
           })
#'@export
setMethod("getProject", signature(object="missing"),
          function(object, name) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getProject(name))
          })
#'@export
setMethod("getProject", signature(object="ApigeeInsights"),
          function(object, name) {
            return(object$getProject(name))
          })


#'Get a list of models.
#'
#'Gets a model list for the specified project.
#'
#'@param object \code{\link{ApigeeInsights}}. An ApigeeInsights instance.
#'@param project character. The name of the project containing the models.
#'@return A data frame representing available \code{\link{Model}}
#' instances.
#' 
#'@usage getModelList(object, project)
#'
#'project$getModelList()
setGeneric("getModelList",
           function(object, project) {
             standardGeneric("getModelList")
           })
#'@export
setMethod("getModelList", signature(object="missing", project="character"),
          function(object, project) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getProject(project)$getModelList())
          })
#'@export
setMethod("getModelList", signature(object="ApigeeInsights", project="character"),
          function(object, project) {
            return(object$getProject(project)$getModelList())
          })


#'Get a model.
#'
#'Retrieves the specified model from the specified project.
#'
#'@param object \code{\link{ApigeeInsights}}. An ApigeeInsights instance.
#'@param name character. The model name
#'@return \code{\link{Model}}
#'
#'@usage getModel(object, project, name)
#'
#'project$getModel(name)
setGeneric("getModel",
           function(object, project, name) {
             standardGeneric("getModel")
           })
#'@export
setMethod("getModel", signature(object="missing", project="character", name="character"),
          function(object, project, name) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getProject(project)$getModel(name))
          })
#'@export
setMethod("getModel", signature(object="ApigeeInsights", project="character", name="character"),
          function(object, project, name) {
            return(object$getProject(project)$getModel(name))
          })


#'Get a list of scores
#'
#'Gets a score list for the specified model.
#'
#'@param object \code{\link{ApigeeInsights}}. An ApigeeInsights instance.
#'@param project character. The name of the project containing the model 
#'that was scored.
#'@param model character. The name of the model that was scored.
#' @return A data frame representing available \code{\link{Score}}
#' instances.
#' 
#'@usage getScoreList(object, project, model)
#'
#'model$getScoreList()
setGeneric("getScoreList",
           function(object, project, model) {
             standardGeneric("getScoreList")
           })
#'@export
setMethod("getScoreList", signature(object="missing", project="character", model="character"),
          function(object, project, model) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getProject(project)$getModel(model)$getScoreList())
          })
#'@export
setMethod("getScoreList", signature(object="ApigeeInsights", project="character", model="character"),
          function(object, project, model) {
            return(object$getProject(project)$getModel(model)$getScoreList())
          })


#'Get a score
#'
#'Gets a score object for the specified model.
#'
#'@param object \code{\link{ApigeeInsights}}. An ApigeeInsights instance.
#'@param project character. The name of the project containing the model.
#'@param model character. The name of the model.
#'@param name character. The name of the score to get.
#'@return A \code{\link{Score}} instance representing the score.
#'
#'@usage getScore(object, project, model, name)
#'
#'model$getScore(name)
setGeneric("getScore",
           function(object, project, model, name) {
             standardGeneric("getScore")
           })
#'@export
setMethod("getScore", signature(object="missing", project="character", model="character", name="character"),
          function(object, project, model, name) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getProject(project)$getModel(model)$getScore(name))
          })
#'@export
setMethod("getScore", signature(object="ApigeeInsights", project="character", model="character", name="character"),
          function(object, project, model, name) {
            return(object$getProject(project)$getModel(model)$getScore(name))
          })

#'Get a report list
#'
#'Retrieve all reports for the specified score.
#'
#'@param object \code{\link{ApigeeInsights}}. An ApigeeInsights instance.
#'@param project character. Name of the project containing the model
#'and score for which the report was created.
#'@param model character. Name of the model that was scored.
#'@param score character. Name of the score for which the reports were
#'created.
#'@return A data frame representing available \code{\link{Report}}
#'instances.
#' 
#'@usage getReportList(object, project, model, score)
#'
#'score$getReportList()
setGeneric("getReportList",
           function(object, project, model, score) {
             standardGeneric("getReportList")
           })
#'@export
setMethod("getReportList", signature(object="missing", project="character", model="character", score="character"),
          function(object, project, model, score) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getProject(project)$getModel(model)$getScore(score)$getReportList())
          })
#'@export
setMethod("getReportList", signature(object="ApigeeInsights", project="character", model="character", score="character"),
          function(object, project, model, score) {
            return(object$getProject(project)$getModel(model)$getScore(score)$getReportList())
          })

#'Get a report.
#'
#'Retrieves a report for the specified \code{score}.
#'
#'@param object \code{\link{ApigeeInsights}}. An ApigeeInsights instance.
#'@param project character. Name of the project containing the model
#'and score.
#'@param model character. Name of the model that was scored.
#'@param score character. Name of the score for which the report was
#'created.
#'@param name character. Name of the report to get.
#'@return \code{\link{Report}}
#'
#'@usage getReport(object, project, model, score, name)
#'
#'score$getReport(name)
setGeneric("getReport",
           function(object, project, model, score, name) {
             standardGeneric("getReport")
           })
#'@export
setMethod("getReport", signature(object="missing", project="character", model="character", score="character", name="character"),
          function(object, project, model, score, name) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getProject(project)$getModel(model)$getScore(score)$getReport(name))
          })
#'@export
setMethod("getReport", signature(object="ApigeeInsights", project="character", model="character", score="character", name="character"),
          function(object, project, model, score, name) {
            return(object$getProject(project)$getModel(model)$getScore(score)$getReport(name))
          })


#'Get a catalog list.
#'
#'Retrieves all of the data store catalogs based on the scope of \code{object}.
#'
#'@param object \code{\link{ApigeeInsights}} / \code{\link{DataManager}}. The 
#'object from which to get the list of catalogs.
#'@return A data frame representing available catalogs.
#'
#'@usage getCatalogList(object)
#'
#'DataManger$getCatalogList()
setGeneric("getCatalogList",
           function(object) {
             standardGeneric("getCatalogList")
           })
#'@export
setMethod("getCatalogList", signature(object="missing"),
          function(object) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getDataManager()$getCatalogList())
          })
#'@export
setMethod("getCatalogList", signature(object="ApigeeInsights"),
          function(object) {
            return(object$getDataManager()$getCatalogList())
          })
#'@export
setMethod("getCatalogList", signature(object="DataManager"),
          function(object) {
            return(object$getCatalogList())
          })









#'Get organization list.
#'
#'Get a list of organization to which the user belongs.
#'@param object \code{\link{ApigeeInsights}}/ missing. The 
#'object from which to get the list of organizations.
#'
#'@export
getOrgList <- function(object = NULL)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("ApigeeInsights","NULL"))
  Utils.signatureValidation(params, signatures)
  if(is.null(object))
  {
    object <- .AIEnv$.ApigeeInsights
  }
  return(object$getOrgList())
}

#'Set org.
#'
#'Set the name of the org.
#'@param object \code{\link{ApigeeInsights}} / missing. The 
#'object on which the organization has to be set.
#'
#'@param orgName character. The 
#'name of the org to be set.
#'
#'@export
setOrg <- function(object = NULL, orgName)
{
  params <- c(as.list(environment()))
  signatures <- list(object=c("ApigeeInsights","NULL"),
                     orgName="character")
  Utils.signatureValidation(params, signatures)
  if(is.null(object))
  {
    object <- .AIEnv$.ApigeeInsights
  }
  return(object$setOrg(orgName))
}

#'Get a catalog.
#'
#'Returns the catalog specified by \code{name}.
#'
#'@param object \code{\link{ApigeeInsights}} / \code{\link{DataManager}}. The 
#'object from which to get the specified catalog.
#'@param name character. Name of the catalog.
#'@return A \code{\link{Catalog}} object representing the catalog.
#'
#'@usage getCatalog(object, name=NULL)
#'
#'DataManager$getCatalog(name=NULL)
setGeneric("getCatalog",
           function(object, ...) {
             standardGeneric("getCatalog")
           })
#'@export
setMethod("getCatalog", signature(object="missing"),
          function(object, name=NULL) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getDataManager()$getCatalog(name))
          })
#'@export
setMethod("getCatalog", signature(object="ApigeeInsights"),
          function(object, name=NULL) {
            return(object$getDataManager()$getCatalog(name))
          })
#'@export
setMethod("getCatalog", signature(object="DataManager"),
          function(object, name=NULL) {
            return(object$getCatalog(name))
          })

#'Get dataset list
#'
#'Gets the specified object's datasets.
#'
#'@param object \code{\link{ApigeeInsights}} / \code{\link{DataManager}} / \code{\link{Catalog}}. The object for which to get a list of datasets.
#'@return A data frame with the datasets.
#'
#'@usage getDatasetList(object, catalog=NULL)
#'
#'catalog$getDatasetList()
setGeneric("getDatasetList",
           function(object, ...) {
             standardGeneric("getDatasetList")
           })
#'@export
setMethod("getDatasetList", signature(object="missing"),
          function(object, catalog=NULL) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getDataManager()$getCatalog(catalog)$getDatasetList())
          })
#'@export
setMethod("getDatasetList", signature(object="ApigeeInsights"),
          function(object, catalog=NULL) {
            return(object$getDataManager()$getCatalog(catalog)$getDatasetList())
          })
#'@export
setMethod("getDatasetList", signature(object="DataManager"),
          function(object, catalog=NULL) {
            return(object$getCatalog(catalog)$getDatasetList())
          })
#'@export
setMethod("getDatasetList", signature(object="Catalog"),
          function(object) {
            return(object$getDatasetList())
          })


#'Get a schema
#'
#'Gets the schema for a dataset or partition.
#'
#'@param object \code{\link{Dataset}} / \code{\link{Partition}}. The object the schema represents.
#'
#'@usage getSchema(object)
#'
#'object$getSchema()
setGeneric("getSchema",
           function(object) {
             standardGeneric("getSchema")
           })
#'@export
setMethod("getSchema", signature(object="Dataset"),
          function(object) {
            return(object$getSchema())
          })
#'@export
setMethod("getSchema", signature(object="Partition"),
          function(object) {
            return(object$getSchema())
          })


#'Show schema.
#'
#'Describe the dataset or partition schema.
#'
#'@param object \code{\link{Dataset}} / \code{\link{Partition}}. The dataset or partition object.
#'
#'@usage showSchema(object)
#'
#'object$showSchema()
setGeneric("showSchema",
           function(object) {
             standardGeneric("showSchema")
           })
#'@export
setMethod("showSchema", signature(object="Partition"),
          function(object) {
            object$showSchema()
          })
setMethod("showSchema", signature(object="Dataset"),
          function(object) {
            object$showSchema()
          })


#'Generate data statistics.
#'
#'Generates statistics metadata for the specified dataset or partition.
#'
#'@param object \code{\link{Dataset}} / \code{\link{Partition}}. The dataset or partition object
#'
#'@usage generateStatistics(object)
#'
#'object$generateStatistics()
setGeneric("generateStatistics",
           function(object) {
             standardGeneric("generateStatistics")
           })
setMethod("generateStatistics", signature(object="Dataset"),
          function(object) {
            return(object$generateStatistics())
          })
setMethod("generateStatistics", signature(object="Partition"),
          function(object) {
            return(object$generateStatistics())
          })


#'Get statistics about data.
#'
#'Gets metadata statistics about the specified object.
#'
#'@param object \code{\link{Dataset}} / \code{\link{Partition}}. The object about which
#'to get statistics.
#'@return The statistics.
#'
#'@usage getStatistics(object)
#'
#'object$getStatistics()
setGeneric("getStatistics",
           function(object) {
             standardGeneric("getStatistics")
           })
setMethod("getStatistics", signature(object="Dataset"),
          function(object) {
            return(object$getStatistics())
          })
setMethod("getStatistics", signature(object="Partition"),
          function(object) {
            return(object$getStatistics())
          })

#'Get a dataset.
#'
#'Gets the specified dataset from the specified object.
#'
#'@param object \code{\link{ApigeeInsights}} / \code{\link{DataManager}} / \code{\link{Catalog}}. The object containing the dataset.
#'@param name character. The dataset name.
#'@param catalog character. Name of the catalog from which to get partitions.
#'@return The requested \code{\link{Dataset}}
#'
#'@usage getDataset(object, catalog=NULL, name)
#'
#'catalog$getDataset(name)
setGeneric("getDataset",
           function(object, ...) {
             standardGeneric("getDataset")
           })
#'@export
setMethod("getDataset", signature(object="missing"),
          function(object, catalog=NULL, name) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getDataManager()$getCatalog(catalog)$getDataset(name))
          })
#'@export
setMethod("getDataset", signature(object="ApigeeInsights"),
          function(object, catalog=NULL, name) {
            return(object$getDataManager()$getCatalog(catalog)$getDataset(name))
          })
#'@export
setMethod("getDataset", signature(object="DataManager"),
          function(object, catalog=NULL, name) {
            return(object$getCatalog(catalog)$getDataset(name))
          })
#'@export
setMethod("getDataset", signature(object="Catalog"),
          function(object, name) {
            return(object$getDataset(name))
          })


#'Get partition list.
#'
#'Gets a list of the partitions for the specified object. Use the parameters
#'as a sequence to specify the scope of the paritions to get -- for example,
#'catalog > dataset > partition
#'
#'@param object \code{\link{ApigeeInsights}} / \code{\link{DataManager}} / \code{\link{Catalog}} / \code{\link{Dataset}}. The object for which to get the partition list.
#'@param name character. The name of the partitions to get.
#'@param datastore character. Datastore from which to get the partitions.
#'@param catalog character. Name of the catalog from which to get partitions.
#'@param dataset character. Dataset from which to get the partitions.
#'@return \code{\link{Partition}} List
#'
#'@usage getPartitionList(object, catalog=NULL, dataset)
#'
#'dataset$getPartitionList()
#'
setGeneric("getPartitionList",
           function(object, ...) {
             standardGeneric("getPartitionList")
           })
#'@export
setMethod("getPartitionList", signature(object="missing"),
          function(object, catalog=NULL, dataset) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getDataManager()$getCatalog(catalog)$getDataset(dataset)$getPartitionList())
          })
#'@export
setMethod("getPartitionList", signature(object="ApigeeInsights"),
          function(object, catalog=NULL, dataset) {
            return(object$getDataManager()$getCatalog(catalog)$getDataset(dataset)$getPartitionList())
          })
#'@export
setMethod("getPartitionList", signature(object="DataManager"),
          function(object, catalog=NULL, dataset) {
            return(object$getCatalog(catalog)$getDataset(dataset)$getPartitionList())
          })
#'@export
setMethod("getPartitionList", signature(object="Catalog"),
          function(object, dataset) {
            return(object$getDataset(dataset)$getPartitionList())
          })
#'@export
setMethod("getPartitionList", signature(object="Dataset"),
          function(object) {
            return(object$getPartitionList())
          })

#'Get a partition.
#'
#'Gets the specified dataset partition. 
#'
#'@param object \code{\link{ApigeeInsights}} / \code{\link{DataManager}} / \code{\link{Catalog}} / \code{\link{Dataset}}. The object from which to get the partition.
#'@param name character. The partition name.
#'@param datastore character. Datastore from which to get the partitions.
#'@param catalog character. Name of the catalog from which to get partition.
#'@param dataset character. Dataset from which to get the partition.
#'@return A \code{\link{Partition}} instance representing the partition.
#'
#'@usage getPartition(object, catalog=NULL, dataset, datastore=NULL, name)
#'
#'dataset$getPartition(name, datastore)
#'
setGeneric("getPartition",
           function(object, ...) {
             standardGeneric("getPartition")
           })
#'@export
setMethod("getPartition", signature(object="missing"),
          function(object, catalog=NULL, dataset, datastore=NULL, name) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getDataManager()$getCatalog(catalog)$getDataset(dataset)$getPartition(name, datastore))
          })
#'@export
setMethod("getPartition", signature(object="ApigeeInsights"),
          function(object, catalog=NULL, dataset, datastore=NULL, name) {
            return(object$getDataManager()$getCatalog(catalog)$getDataset(dataset)$getPartition(name, datastore))
          })
#'@export
setMethod("getPartition", signature(object="DataManager"),
          function(object, catalog=NULL, dataset, datastore=NULL, name) {
            return(object$getCatalog(catalog)$getDataset(dataset)$getPartition(name, datastore))
          })
#'@export
setMethod("getPartition", signature(object="Catalog"),
          function(object, dataset, datastore=NULL, name) {
            return(object$getDataset(dataset)$getPartition(name, datastore))
          })
#'@export
setMethod("getPartition", signature(object="Dataset"),
          function(object, datastore=NULL, name) {
            return(object$getPartition(name, datastore))
          })

#'Get the data manager.
#'
#'Get the DataManager object to explore catalogs, datasets, and partitions. 
#'For example, pass the retrieved DataManager object to getCatalog.
#'
#'@param object \code{\link{ApigeeInsights}}. The object for which to get the 
#'data manager.
#'@return \code{\link{DataManager}}
#'
#'@usage getDataManager(object)
#'
#'object$getDataManager()
setGeneric("getDataManager",
           function(object, ...) {
             standardGeneric("getDataManager")
           })
#'@export
setMethod("getDataManager", signature(object="missing"),
          function(object) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getDataManager())
          })
#'@export
setMethod("getDataManager", signature(object="ApigeeInsights"),
          function(object) {
            return(object$getDataManager())
          })

#'Get partition list.
#'
#'Gets a list of the partitions for the specified object. Use the parameters
#'as a sequence to specify the scope of the paritions to get -- for example,
#'catalog > dataset > partition
#'
#'@param object \code{\link{ApigeeInsights}} / \code{\link{DataManager}} / \code{\link{Catalog}} / \code{\link{Dataset}}. The object for which to get the partition list.
#'@param name character. The name of the partitions to get.
#'@param datastore character. Datastore from which to get the partitions.
#'@param catalog character. Name of the catalog from which to get partitions.
#'@param dataset character. Dataset from which to get the partitions.
#'@return \code{\link{Partition}} List
#'
#'@usage getPartitions(object, catalog=NULL, dataset, datastore=NULL, name=NULL)
#'
#'dataset$getPartitions(names, datastore)
setGeneric("getPartitions",
           function(object, ...) {
             standardGeneric("getPartitions")
           })
#'@export
setMethod("getPartitions", signature(object="missing"),
          function(object, catalog=NULL, dataset, datastore=NULL, name=NULL) {
            account <- .AIEnv$.ApigeeInsights
            return(account$getDataManager()$getCatalog(catalog)$getDataset(dataset)$getPartitions(name, datastore))
          })
#'@export
setMethod("getPartitions", signature(object="ApigeeInsights"),
          function(object, catalog=NULL, dataset, datastore=NULL, name=NULL) {
            return(object$getDataManager()$getCatalog(catalog)$getDataset(dataset)$getPartitions(name, datastore))
          })
#'@export
setMethod("getPartitions", signature(object="DataManager"),
          function(object, catalog=NULL, dataset, datastore=NULL, name=NULL) {
            return(object$getCatalog(catalog)$getDataset(dataset)$getPartitions(name, datastore))
          })
#'@export
setMethod("getPartitions", signature(object="Catalog"),
          function(object, dataset, datastore=NULL, name=NULL) {
            return(object$getDataset(dataset)$getPartitions(name, datastore))
          })
#'@export
setMethod("getPartitions", signature(object="Dataset"),
          function(object, datastore=NULL, name=NULL) {
            return(object$getPartitions(name, datastore))
          })

#'Get overall statistics.
#'
#'Describes the object statistics.
#'
#'@param object \code{\link{BaseStatistics}}. The statistics object.
#'
#'@usage getOverAllStats(object)
#'
#'object$getOverAllStats()
setGeneric("getOverAllStats",
           function(object, ...) {
             standardGeneric("getOverAllStats")
           })
#'@export
setMethod("getOverAllStats", signature(object="BaseStatistics"),
          function(object) {
            return(object$getOverAllStats())
          })

#'Get column-level statistics.
#'
#'Describes column-level stats.
#'
#'@param object \code{\link{BaseStatistics}}. The statistics object.
#'
#'@usage getColumnLevelStats(object)
#'
#'object$getColumnLevelStats()
setGeneric("getColumnLevelStats",
           function(object, ...) {
             standardGeneric("getColumnLevelStats")
           })
#'@export
setMethod("getColumnLevelStats", signature(object="BaseStatistics"),
          function(object) {
            return(object$getColumnLevelStats())
          })

#'Show stats.
#'
#'Describes the object statistics.
#'
#'@param object \code{\link{BaseStatistics}}. The statistics object.
#'
#'@usage showStats(object)
#'
#'object$showStats()
setGeneric("showStats",
           function(object, ...) {
             standardGeneric("showStats")
           })
#'@export
setMethod("showStats", signature(object="BaseStatistics"),
          function(object) {
            object$showStats()
          })
