#Copyright 2014 Apigee Corporation
Report$methods(
  initialize = function(score, name, description="", .skipI=FALSE){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(score=c("Score"),
                       name=c("character"),
                       description=c("character"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    setName(name)
    setDescription(description)
    setScore(score)
    if(!score$getSaved())
    {
      warning("Score is not saved. Use store method to save the score before saving the report object")
    }
    if(!is.null(score$getConfig()$splitConfig))
    {
      c <- list()
      c$splitConfig <- score$getConfig()$splitConfig
      setConfig(c)
    }
    if(.skipI)
    {
      Utils.info("Report created successfully")
      return()
    }
    profileOnly <- FALSE
    if(!score$getModel()$getClickStream()$getOffer()$getResponse()$isSet() && !score$getModel()$getClickStream()$getOffer()$getImpression()$isSet() && length(score$getModel()$getClickStream()$getCombineActivity()$getActivity()) == 0)
    {
      profileOnly <- TRUE
    }
    
    tryCatch({
      reportNames <- getScore()$getReportList()$name
      Utils.info("Checking for report duplicity...")
      if(name %in% reportNames)
      {
        stop("Report - ",name," already available. Use getReport method to fetch the report or change the report name")
      }
    }, AIErr=function(err){
    })
    setSaved(FALSE)
    mOffer <- getScore()$getModel()$getClickStream()$getOffer()$copy()
    startTime <- as.POSIXlt(getScore()$.global$targetScoreTime)+1
    setOffer(mOffer)
    Utils.info("Inheriting impression and response from model")
    startTime <- as.character(startTime)
    if(!profileOnly)
      Utils.info(paste("Setting (targetScoreTime + 1 second) i.e. ", startTime," as the start date for impression and response",sep="",collapse=""))
    #reset start and end time
    setDateFilter()
    setDateFilter(startTime=startTime)
    off <- NULL
    
    if(mOffer$getResponse()$isSet())
    {
      off <- c(off,mOffer$getResponse())
    }
    if(mOffer$getImpression()$isSet())
    {
        
    }
    isInfoSet <- 1
    if(.AIEnv[[".isInfo"]] == 0)
    {
      isInfoSet <- 0
    }
    Utils.info("Validating configuration...")
    setInfo(0)
    #for(o in off)
    #  {
    #    c <- o$getConfig()
    #    p <- getAllPartitions(dataset=o$getPartition()[[1]]$getDataset(),datastore=o$getPartition()[[1]]$getDatastore())
    #    data <- Utils.getStEtFromPartitions(p)
    #    fp <- NULL
    #    if(!is.null(data))
    #    {
    #      fp <- Utils.getPartitionsGivenStEt(c$startTime,data=data)
    #      if(length(fp) != 0)
    #      {
    #        o$setPartition(fp)
    #      }
    #      else
    #      {
    #        warning("Cannot find data for the given time range for the dataset ", p[[1]]$getDataset()$getName())
    #        o$setPartition(p)
    #      }
    #      
    #    }
    #    else
    #    {
    #     o$setPartition(p)
    #    }
    #  }
      #getOffer()$setImpression(newAct)
    
    if(isInfoSet == 1)
      setInfo(1)
    
    
    
    
    

    #fill if any config has to be derived from model
    derivedConfig <- c()
    mConfig <- getScore()$getModel()$getConfig()
    rConfig <- list()
    if(Utils.isSet(mConfig))
    {
      for(c in derivedConfig)
      {
        if(Utils.isSet(mConfig[[c]]))
        {
          Utils.info(paste("Inheriting config '",c,"' from model",sep="",collapse=""))
          rConfig[[c]] <- mConfig[[c]]
        }
      }
    }
    if(Utils.isSet(rConfig))
    {
      setConfig(rConfig)
    }
    ms <- mConfig$splitConfig
    if(!is.null(ms))
    {
      split <- unlist(strsplit(ms,":"))[2]
      r <- unlist(strsplit(split,"-"))
      if(length(r) == 2)
      {
        r <- as.numeric(r)
        rs <- setdiff(0:99,seq(r[1],r[2]))
      }
      else
        rs <- setdiff(0:99,as.numeric(unlist(strsplit(split,","))))
      setTestingSplit(100,rs)
    }
    setBinDefinition("1%")
    Utils.info("Validation done")
    Utils.info("Report created successfully")
  },
  toJsonStructure = function()
  {
    obj <- list()
    if(Utils.isSet(.name))  
      obj[["name"]] <- getName()
    if(Utils.isSet(.description))
      obj[["description"]] <- getDescription()
    if(Utils.isSet(.config))
      obj[["config"]] <- .config
    obj[["offer"]] <- .offer$toJsonStructure()
    if(Utils.isSet(.id))
    {
      obj[["id"]] <- .id
    }
    if(!is.null(.global$visibility))
    {
      obj[["visibility"]] <- .global$visibility
    }
    return(obj)
  },
  setBinDefinition = function(interval="10%", start=0, end=NULL) {
    #remove all whitespace
    orgInterval <- interval
    interval <- Utils.removeWhitespace(interval)
    if(length(grep("%",interval)==1))
    {   
      interval <- gsub("%+", "%", interval)
      if(!Utils.isPercentage(interval))
      {   
        stop("Invalid percentage input : ",orgInterval,"-",interval)
      }   
      interval <- as.numeric(unlist(strsplit(interval,"%")))
      if(is.null(start) || start == 0 || start < 0)
      {   
        if(!is.null(start) && start < 0)
        {   
          warning("start is negative. Using start=",interval)
        }   
        start <- interval
      }   
      if(is.null(end) || end > 100 || end < 0 || end < start)
      {   
        if(!is.null(end) && end < 0)
        {   
          warning("end is negative. Using start=100")
        }   
        if(!is.null(end) && end < start)
        {
          warning("end is smaller than start. Using end=100")
        }
        if(!is.null(end) && end > 100)
        {
          warning("end is greater than 100. Using end=100")
        }
        end <- 100
      }
      
      i <- start
      binDef <- NULL
      last <- 0
      while(i <= end)
      {
        op <- i
        if(is.null(binDef))
        {
          binDef <- paste(op,"%",sep="")
        }
        else{
          binDef <- paste(binDef,",",op,"%",sep="")
        }
        last <- i
        i <- i + interval
      }
      if(last != 100)
      {
        binDef <- paste(binDef,",100%",sep="")
      }
    }
    else
    {
      if(!Utils.isNumber(interval))
      {
        stop("Invalid number : ",orgInterval)
      }
      interval <- as.numeric(interval)
      if(is.null(start) || start == 0 || start < 0)
      {
        if(!is.null(start) && start < 0)
        {
          warning("start is negative. Using start=",interval)
        }
        start <- interval
      }
      if(is.null(end) || end < 0 || end < start)
      {
        stop("Invalid end value. end value cannot be missing, negative or less than start value")
      }
      i <- start
      binDef <- NULL
      while(i <= end)
      {
        op <- i
        if(is.null(binDef))
        {
          binDef <- paste(op,sep="")
        }
        else{
          binDef <- paste(binDef,",",op,sep="")
        }
        i <- i + interval
      }
    }
    setConfiguration("reportingBuckets", binDef)
    
  },
  setVisibility = function(flag="External")
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(
      flag=c("character")
    )
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(length(flag) == 1 && (flag == "External" || flag == "Internal"))
    {
      .global$visibility <<- flag
    }
  },
  openJobManager = function()
  {
    url <- getScore()$getModel()$getProject()$getAccount()$getConfig()$jobManager
    if(!is.null(url))
    {   
      mn <- curlEscape(getName())
      url <- paste(url,"#resource=/management/jobBrowser&objectType=Report&objectName=",mn,"&objectId=",getId(),"&token=",getScore()$getModel()$getProject()$getAccount()$getToken(),"&userName=",getScore()$getModel()$getProject()$getAccount()$getUser(),sep="")
    }   
    else
    {   
      stop("jobManager base url not available in the configuration")
    }   
    browseURL(url)
  },
  show = function()
  {
    cat("Account = ", getScore()$getModel()$getProject()$getAccount()$.account)
    cat("\nProject = ", getScore()$getModel()$getProject()$getName())
    cat("\nModel = ", getScore()$getModel()$getName())
    cat("\nScore = ", getScore()$getName())
    cat("\nReport Object :\n\n")
    cat("Report Name =",getName(),"\n")
    cat("Report Description =",getDescription(),"\n")
    if(length(getConfig()) > 0)
    {   
      cat("********* Report Configs *********")
      pandoc.table(as.data.frame(getConfig()), split.cells=50, split.table=1220,style="grid")
    }   
    if(length(getOffer()$getConfig()) > 0)
    {   
      cat("********* Offer Configs *********")
      pandoc.table(as.data.frame(getOffer()$getConfig()), split.cells=50, split.table=1220,style="grid")
    }
    if(getOffer()$getImpression()$isSet())
    {   
      cat("\n********* Impression Dataset *********")
      impression <- collapsePartitions(getOffer()$getImpression()$toJsonStructure())
      if(impression$config$impressionMetric == "")
      {
        impression$config$impressionMetric <- "impression_count"
      }
      uli <- unlist(impression)
      pandoc.table(t(uli), split.cells=50, split.table=1220,style="grid")
    }   
    if(getOffer()$getResponse()$isSet() > 0)
    {   
      cat("\n********* Response Dataset *********")
      response <- collapsePartitions(getOffer()$getResponse()$toJsonStructure())
      if(response$config$responseMetric == "")
      {
        response$config$responseMetric <- "response_count"
      }
      ulr <- unlist(response)
      pandoc.table(t(ulr), split.cells=50, split.table=1220,style="grid")
    }
  },
  setConfiguration = function(key, value)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(key=c("character"),
                       value=c("character","numeric"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(class(value) == "numeric")
    {   
      value <- sprintf("%.f",value)
    }   
    key <- Utils.trim(key)
    config <- getConfig()
    config[[key]] <- value
    setConfig(config)
  },
  cloneObject = function(name, description="")
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(name=c("character"),
                       description = "character")
    Utils.signatureValidation(params, signatures, globalSignatures)
    
    clonedReport <- Report$new(getScore(),name,description,.skipI=T)
    if(Utils.isSet(getConfig()))
      clonedReport$setConfig(getConfig())
    if(Utils.isSet(getOffer()$getConfig()))
      clonedReport$getOffer()$setConfig(getOffer()$getConfig())
    
    clonedReport$getOffer()$setImpression(getOffer()$getImpression()$copy())
    clonedReport$getOffer()$setResponse(getOffer()$getResponse()$copy())
    clonedReport$.global$endTime <- .global$endTime
    clonedReport$setSaved(FALSE)
    return(clonedReport)
  },
  setDateFilter = function(startTime=NULL, endTime=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(
      startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
      endTime=c("character","POSIXt","POSIXlt","missing","NULL")
    )
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(!is.null(startTime))
    {    
      startTime <- as.character(startTime)
      st <- as.Date(startTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(st))
      {    
        stop("The start time must be of the format YYYY-MM-DD HH:MM:SS")
      }
      .global$startTime <<- startTime
    }    
    if(!is.null(endTime))
    {    
      endTime <- as.character(endTime)
      et <- as.Date(endTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(et))
      {    
        stop("The end time must be of the format YYYY-MM-DD HH:MM:SS")
      }
      .global$endTime <<- endTime
      
    }
    #activity start and end time
    if(getOffer()$getImpression()$isSet())
    {
      obj <- getOffer()$getImpression()
      config <- obj$getConfig()
      if(!is.null(startTime))
        config$startTime <- startTime
      else if(is.null(endTime))
        config$endTime <- NULL
      if(!is.null(endTime))
        config$endTime <- endTime
      else if(is.null(startTime))
        config$startTime <- NULL
      obj$setConfig(config)
    }
    if(getOffer()$getResponse()$isSet())
    {
      obj <- getOffer()$getResponse()
      config <- obj$getConfig()
      if(!is.null(startTime))
        config$startTime <- startTime
      else if(is.null(endTime))
        config$endTime <- NULL
      if(!is.null(endTime))
        config$endTime <- endTime
      else if(is.null(startTime))
        config$startTime <- NULL
      obj$setConfig(config)
    }
    if(!is.null(startTime) || !is.null(endTime))
    refreshPartitions()
  },
  refreshPartitions = function()
  {
    objects <- NULL
    if(getOffer()$getImpression()$isSet())
      objects <- c(objects, getOffer()$getImpression())
    
    if(getOffer()$getResponse()$isSet())
      objects <- c(objects, getOffer()$getResponse())
    for(obj in objects)
    {
      startTime <- obj$getConfig()$startTime
      endTime <- obj$getConfig()$endTime
      d <- obj$getPartition()[[1]]$getDataset()
      datastore <- obj$getPartition()[[1]]$getDatastore()
      p <- getAllPartitions(dataset=d, datastore=datastore)
      data <- Utils.getStEtFromPartitions(p)
      if(!is.null(data))
        p <- Utils.getPartitionsGivenStEt(startTime,endTime,data)
      
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      if(is.null(p) || length(p) == 0)
      {
        warning("Based on the time range, no data available for catalog=",d$getCatalog()$getName()," dataset=",d$getName())
      }
      else
        obj$setPartition(p)
      #a$setDatastore(datastore)
      #a$setDataset(d)
    }
  },
  setScore = function(score){
    signatures <- c("list-Score","Score")
    if(!Utils.validateSignature(score,signatures))
    {
      stop("Invalid signature : score should be of type ", paste(signatures,collapse=" or "))
    }
    .score <<- c(score)
  },
  getScore = function(){return(.score[[1]])},
  setOffer = function(offer){
    signatures <- c("Offer")
    if(!Utils.validateSignature(offer,signatures))
    {
      stop("Invalid signature : offer should be of type ", paste(signatures,collapse=" or "))
    }
    .offer <<- offer
  },
  getOffer = function(){return(.offer)},
  setConfig = function(config){
    signatures <- c("list")
    if(!Utils.validateSignature(config,signatures))
    {
      stop("Invalid signature : config should be of type ", paste(signatures,collapse=" or "))
    }
    .config <<- c(config)
  },
  getConfig = function(){return(.config)},
  setName = function(name){
    signatures <- c("character")
    if(!Utils.validateSignature(name,signatures))
    {
      stop("Invalid signature : name should be of type ", paste(signatures,collapse=" or "))
    }
    .name <<- name
  },
  getName = function(){return(.name)},
  setDescription = function(description){
    signatures <- c("character")
    if(!Utils.validateSignature(description,signatures))
    {
      stop("Invalid signature : description should be of type ", paste(signatures,collapse=" or "))
    }
    .description <<- description
  },
  getDescription = function(){return(.description)},
  setId = function(id){
    signatures <- c("numeric")
    if(!Utils.validateSignature(id,signatures))
    {
      stop("Invalid signature : id should be of type ", paste(signatures,collapse=" or "))
    }
    .id <<- id
  },
  getId = function(){return(.id)},
  setSaved = function(saved){
    signatures <- c("logical")
    if(!Utils.validateSignature(saved,signatures))
    {
      stop("Invalid signature : saved should be of type ", paste(signatures,collapse=" or "))
    }
    .saved <<- saved
  },
  getSaved = function(){return(.saved)},
  generateEndPoint = function(id="")
  {
    return(getScore()$generateCEndPoint(id))
  },
  execute = function()
  {
    name <- getName()
    if(getStatus() == "Unsaved")
    {
      store()
    }
    url <- generateEndPoint(name)
    url <- paste(url,"/execute_op",sep="")
    params = list(accountId=getScore()$getModel()$getProject()$getAccount()$getId(),token=getScore()$getModel()$getProject()$getAccount()$getToken(),entityIdType="name",project=getScore()$getModel()$getProject()$getName())
    tryCatch({
      data <- sendRequest(url,"put",params,"{}")
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {
        stop(x)
      }
      template <- paste(MESSAGES$ENTITY$REPORT,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<REPORT>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })
    
  },
  getStatus = function()
  {
    name <- getName()
    if(getSaved() == FALSE)
    {   
      s <- "Unsaved"
      return(s)
    }   
    else
    {   
      url <- generateEndPoint(getName())
      url <- paste(url,"/getState_op",sep="")
      params = list(accountId=getScore()$getModel()$getProject()$getAccount()$getId(),token=getScore()$getModel()$getProject()$getAccount()$getToken(),entityIdType="name",project=getScore()$getModel()$getProject()$getName())
      tryCatch({
        data <- sendRequest(url,"get",params)
      },AIErr=function(x){
        if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
        {   
          stop(x)
        }   
        template <- paste(MESSAGES$ENTITY$REPORT,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
        tv <- .AIEnv[[".TEMPLATE_VALUES"]]
        tv[["<REPORT>"]] <- name
        msg <- replaceTemplate(template,tv)
        stop(createAIErr(x$code,msg))
      })  
      return(data$state)
    }
  },
  update = function()
  {
    name <- getName()
    url <- generateEndPoint(name)
    params = list(accountId=getScore()$getModel()$getProject()$getAccount()$getId(),token=getScore()$getModel()$getProject()$getAccount()$getToken(),entityIdType="name",project=getScore()$getModel()$getProject()$getName())
    jsonObj = toJsonStructure()
    JSON = toJSON(jsonObj)
    tryCatch({
      data <- sendRequest(url,"put",params,JSON)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {
        stop(x)
      }
      template <- paste(MESSAGES$ENTITY$REPORT,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<REPORT>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })
    setSaved(TRUE)
  },
  store = function()
  {
    name <- getName()
    if(getScore()$getSaved() == FALSE)
    {   
      stop("Save the score in order to continue")
    }   
    if(getSaved() == TRUE){
      return(update())
    }   
    url <- generateEndPoint()
    params = list(accountId=getScore()$getModel()$getProject()$getAccount()$getId(),token=getScore()$getModel()$getProject()$getAccount()$getToken(),entityIdType="name",project=getScore()$getModel()$getProject()$getName())
    jsonObj = toJsonStructure()
    JSON = toJSON(jsonObj)
    tryCatch({
      data <- sendRequest(url,"post",params,JSON)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {
        stop(x)
      }
      template <- paste(MESSAGES$ENTITY$REPORT,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<REPORT>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })
    setSaved(TRUE)
    setId(data$reportId)
  },
  stream = function(topN=-1,sep="\t")
  {
    acc<- .AIEnv$.ApigeeInsights
    dm <- acc$getDataManager()
    cn <- paste(getScore()$getModel()$getProject()$getName(),".",getScore()$getModel()$getName(),".",getScore()$getName(),sep="")
    p <- dm$getPartition(catalog=cn, dataset="report", partition=getName())
    pdf <- p$stream(topN=topN, sep=sep)
    if(!("active_users" %in% names(pdf)))
    {
      stop("This report can have multiple impressions/responses per user. Please regenerate the report if you want to consider unique impressions/responses per user. Use \"cloneObj\" method to create and re-run the report.")
    }
    n1 <- names(pdf[,1:4])
    n2 <- names(pdf[,c("active_users","responders")])
    return(pdf[,c(n1,n2)])
  },
  plotAUC = function(predictionDimensionValue=NULL, fp, tp)
  {
    fp <- c(0,fp)
    tp <- c(0,tp)
    fpr <- fp/fp[length(fp)]
    tpr <- tp/tp[length(tp)]
    len <- length(fpr)
    sum = 0
    for(i in 2:len)
    {
      deltaAuc <- (fpr[[i]]-fpr[[i-1]])*((tpr[[i]]+tpr[[i-1]])/2)
      sum = sum + deltaAuc
    }
    title <- paste("AUC for ", predictionDimensionValue," is ",format(sum,digits=4),sep="")
    graphics::plot(fpr,tpr,col=4,type="l",xlab="False Positive Rate",ylab="True Positive Rate",ylim=c(0,1),xlim=c(0,1),main=title,xaxs="i",yaxs="i")
    abline(0,1,col="red")
    legend("bottomright", c("AUC","Random"), cex=0.8, col=c("blue","red"), lty=rep(1,1), lwd=2, bty="n")
  },
  plotLift = function(predictionDimensionValue=NULL, fn, tp, population, populationTotal)
  {
    recallPercent <- (tp/(tp+fn))*100
    lift <- recallPercent/population
    title <- paste("Lift for ", predictionDimensionValue,sep="")
    graphics::plot(population,lift,col=4,type="l",xlab=paste("% population (Total = ",populationTotal,")",sep="",collapse=""),ylab="Lift",ylim=c(0,ceiling(max(lift))),xlim=c(0,100),main=title,xaxs="i",yaxs="i")
    abline(h=1,col="red")
    legend("topright", c("Lift","Random"), cex=0.8, col=c("blue","red"), lty=rep(1,1), lwd=2, bty="n")
  },
  plotGain = function(predictionDimensionValue=NULL, fn, tp, population, populationTotal)
  {
    population <- c(0,population)
    recallPercent <- (tp/(tp+fn))*100
    recallPercent <- c(0,recallPercent)
    title <- paste("Gain for ", predictionDimensionValue,sep="")
    graphics::plot(population,recallPercent,col=4,type="l",xlab=paste("% population (Total = ",populationTotal,")",sep="",collapse=""),ylab=paste("% positive response / gain (Total = ",tp[length(tp)],")",sep="",collapse=""),ylim=c(0,100),xlim=c(0,100),main=title,xaxs="i",yaxs="i")
    abline(0,1,col="red")
    legend("bottomright", c("% positive response / gain","Random"), cex=0.8, col=c("blue","red"), lty=rep(1,1), lwd=2, bty="n")
  },
  plot = function(type="AUC",predictionDimensionValue=NULL, sep="\t")
  {
    if(is.null(.global$fullReport))
    {
      rep <- stream(sep=sep)
      .global$fullReport <<- rep
    }
    rdf <- .global$fullReport[.global$fullReport$node %in% c(predictionDimensionValue),]
    nrow <- nrow(rdf)
    if(nrow == 0)
    {
      if(nrow(.global$fullReport) == 0)
      {
        stop("Report is empty")
      }
      predictionDimensionValue <- as.character(.global$fullReport[1,1])
      warning("Since predictionDimensionValue is missing or invalid, the first value, ",predictionDimensionValue,", in the report is considered")
      n <- unique(.global$fullReport[,1])
      if(length(n) > 200)
      {
        Utils.info(paste("Showing first 200. Other possible predictionDimensionValues are : ",paste(head(n,200),sep="",collapse=","),sep=""))
      }
      else
      {
        Utils.info(paste("Other possible predictionDimensionValues are : ",paste(n,sep="",collapse=","),sep=""))
      }
      rdf <- .global$fullReport[.global$fullReport$node %in% c(predictionDimensionValue),]
    }
    im <- "active_users"
    rm <- NULL
    if(!("active_users" %in% names(rdf)))
    {
        stop("This report can have multiple impressions/responses per user. Please regenerate the report if you want to consider unique impressions/responses per user. Use \"cloneObj\" method to create and re-run the report.")
    }
    else
    {
      if(type == "AUC")
      {
        rm <- "responders"
      }
      else
      {
          rm <- getOffer()$getResponse()$getConfig()$responseMetric
          if(rm == "" || is.null(rm))
          {
            rm <- "response_count"
          }
      }
    }
    cols <- paste("\\b",im,"\\b|\\b",rm,"\\b",sep="",collapse="")
    part_rdf <- rdf[,grep(cols,names(rdf))]
    px <- as.numeric(as.character(part_rdf[,im]))
    py <- as.numeric(as.character(part_rdf[,rm]))
    
    cpx <- cumsum(px)
    cpy <- cumsum(py)
    
    cfp <- cpx-cpy
    ctp <- cpy
    cfpr <- cfp/cfp[length(cfp)]
    ctpr <- ctp/ctp[length(ctp)]
    
    ctn <- (cpx[length(cpx)] - cpx) - (cpy[length(cpy)] - cpy)
    cfn <- (cpy[length(cpy)] - cpy)
    
    cfn <- (cpy[length(cpy)] - cpy)
    cfnr <- cfn/cfn[length(cfn)]
    ctnr <- ctn/ctn[length(ctn)]
    
    population <- (cpx/cpx[length(cpx)])*100
    populationTotal <- cpx[length(cpx)]
    
    cdf <- data.frame(cfp,ctp,cfn,ctn,population)
    if(type=="AUC")
    {
      plotAUC(predictionDimensionValue, cfp, ctp)
    }
    else if(type=="LIFT")
    {
      plotLift(predictionDimensionValue, cfn, ctp, population, populationTotal)
    }
    else if(type=="GAIN")
    {
      plotGain(predictionDimensionValue, cfn, ctp, population, populationTotal)
    }
  },
  setImpressionEvent = function(dataset, catalog=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","missing","NULL"),
                       dataset=c("character"),
                       startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       endTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       partitions=c("character","missing","NULL"),
                       datastore=c("character","missing","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    
    if(is.null(startTime))
      startTime <- .global$startTime
    
    if(is.null(endTime))
      endTime <- .global$endTime
    
    if(!missing(startTime) && !is.null(startTime) && !missing(endTime) && !is.null(endTime))
    {
      if(endTime < startTime)
      {
        stop("endTime cannot be less than start time")
      }
    }
    #get catalog, dataset, partitions
    if(is.null(catalog))
    {
      if(!exists(".AIEnv") || is.null(.AIEnv$.catalog))
      {
        stop("catalog should be either passed as a parameter or set globally using setCatalog method")
      }
      catalog <- .AIEnv$.catalog
    }
    if(is.null(datastore))
    {
      datastore <- getDatastore()
    }
    if(is.null(partitions))
    {
      if(exists(".AIEnv") && !is.null(.AIEnv$.partitions))
      {
        partitions <- .AIEnv$.partitions
      }
    }
    config <- list()
    if(getOffer()$getImpression()$isSet())
    {
      config <- getOffer()$getImpression()$getConfig()
    }
    
    account <- .AIEnv$.ApigeeInsights
    dm <- DataManager$new(.account=account)
    c <- dm$getCatalog(catalog)
    d <- c$getDataset(dataset)
    if(!d$isEvent())
    {
      stop("Dataset should be an event dataset")
    }
    o <- Impression$new()
    if(!is.null(partitions))
    {
      p <- d$getPartitions(partitions, datastore)
      data <- Utils.getStEtFromPartitions(p)
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      for(parts in data)
      {
        pst <- parts$min
        pet <- parts$max
        pname <- parts$partition$getName()
        if(!is.null(pst) && !is.null(pet) && !is.null(startTime) && !is.null(endTime))
        {
          #if below is true, then it means the timestamp provided by user and the data does not overlap. So after transformation we will have empty data
          if(!((pst <= endTime)  &&  (pet >= startTime)))
          {
            warning("The time range provided does not overlap with the partition ",pname,". So the input data will be empty after filtering. The min and max time in the data are : ", st," & ",et)
          }
          
        }
      }
      o$setPartition(p)
    }
    else
    {
      #Remove this code for getting all partitions
      p <- getAllPartitions(dataset=d, datastore=datastore)
      data <- Utils.getStEtFromPartitions(p)
      if(!is.null(data))
        p <- Utils.getPartitionsGivenStEt(startTime,endTime,data)
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      o$setPartition(p)
    }
    #Process startTime and endTime
    if(!is.null(startTime))
    {    
      startTime <- as.character(startTime)
      config$startTime <- startTime
      st <- as.Date(startTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(st))
      {    
        stop("The start time must be of the format YYYY-MM-DD HH:MM:SS")
      }    
    } 
    else if(!is.null(.global$startTime))
    {
      startTime <- as.character(.global$startTime)
      config$startTime <- startTime
    }
    if(!is.null(endTime))
    {    
      endTime <- as.character(endTime)
      config$endTime <- endTime
      et <- as.Date(endTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(et))
      {    
        stop("The end time must be of the format YYYY-MM-DD HH:MM:SS")
      }
    }
    else if(!is.null(.global$endTime))
    {
      endTime <- as.character(.global$endTime)
      config$endTime <- endTime
    }
    if(Utils.isSet(config))
    {
      o$setConfig(config)
    }
    getOffer()$setImpression(o)
  },
  setTestingSplit = function(totalBucket, split=NULL)
  {
    if(is.null(split) || is.null(split) )
    {   
      stop("Split cannot be null or missing")
    }   
    if(Utils.is.sequential(split))
    {
      r <- paste(range(split),collapse="-")
      s <- paste(totalBucket,":",r,sep="")
    }
    else
    {
      s <- paste(totalBucket,":",paste(split,sep="",collapse=","),sep="")
    }
    config <- getConfig()
    config$splitConfig <- s
    setConfig(config)
  },
  setTestingPercent = function(split)
  {
    if(split >= 100 || split <= 0) 
    {    
      stop("Split percent should be between 0 and 100")
    }
    if(isRandom)
      setTestingSplit(100,sort(sample(0:99,split)))
    else
      setTestingSplit(100,0:(split-1))
  },
  setResponseEvent = function(dataset, predictionDimensions=NULL, catalog=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL, latest = F)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","missing","NULL"),
                       dataset=c("character"),
                       startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       endTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       partitions=c("character","missing","NULL"),
                       datastore=c("character","missing","NULL"),
                       predictionDimensions=c("character","missing","NULL"),
                       latest=c("logical"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(latest == TRUE)
    {
      Utils.info("Considering the latest partition...")
    }
    if(is.null(startTime))
      startTime <- .global$startTime
    
    if(is.null(endTime))
      endTime <- .global$endTime
    
    if(!missing(startTime) && !is.null(startTime) && !missing(endTime) && !is.null(endTime))
    {
      if(endTime < startTime)
      {
        stop("endTime cannot be less than start time")
      }
    }
    
    if(is.null(predictionDimensions))
    {
      predictionDimensions <- ""
    }
    else
    {
      predictionDimensions <- paste(predictionDimensions,sep=",",collapse=",")
    }
    
    #get catalog, dataset, partitions
    if(is.null(catalog))
    {
      if(!exists(".AIEnv") || is.null(.AIEnv$.catalog))
      {
        stop("catalog should be either passed as a parameter or set globally using setCatalog method")
      }
      catalog <- .AIEnv$.catalog
    }
    if(is.null(datastore))
    {
      datastore <- getDatastore()
    }
    if(is.null(partitions) && latest==FALSE)
    {
      if(exists(".AIEnv") && !is.null(.AIEnv$.partitions))
      {
        partitions <- .AIEnv$.partitions
      }
    }
    config <- list()
    if(getOffer()$getResponse()$isSet())
    {
      config <- getOffer()$getResponse()$getConfig()
    }
    
    account <- .AIEnv$.ApigeeInsights
    dm <- DataManager$new(.account=account)
    c <- dm$getCatalog(catalog)
    d <- c$getDataset(dataset)
    
    if(!d$isEvent())
    {
      stop("Dataset should be an event dataset")
    }
    
    if(latest == TRUE)
    {
      pl <-d$getPartitionList()
      partitions <- unlist(pl[nrow(pl),"name"])
    }
    o <- Response$new()
    if(!is.null(partitions))
    {
      p <- d$getPartitions(partitions, datastore)
      data <- Utils.getStEtFromPartitions(p)
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      for(parts in data)
      {
        pst <- parts$min
        pet <- parts$max
        pname <- parts$partition$getName()
        if(!is.null(pst) && !is.null(pet) && !is.null(startTime) && !is.null(endTime))
        {
          #if below is true, then it means the timestamp provided by user and the data does not overlap. So after transformation we will have empty data
          if(!((pst <= endTime)  &&  (pet >= startTime)))
          {
            warning("The time range provided does not overlap with the partition ",pname,". So the input data will be empty after filtering. The min and max time in the data are : ", st," & ",et)
          }
          
        }
      }
      o$setPartition(p)
    }
    else
    {
      #Remove this code for getting all partitions
      p <- getAllPartitions(dataset=d, datastore=datastore)
      data <- Utils.getStEtFromPartitions(p)
      if(!is.null(data))
        p <- Utils.getPartitionsGivenStEt(startTime,endTime,data)
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      o$setPartition(p)
    }
    #Process startTime and endTime
    if(!is.null(startTime))
    {    
      startTime <- as.character(startTime)
      config$startTime <- startTime
      st <- as.Date(startTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(st))
      {    
        stop("The start time must be of the format YYYY-MM-DD HH:MM:SS")
      }    
    } 
    else if(!is.null(.global$startTime))
    {
      startTime <- as.character(.global$startTime)
      config$startTime <- startTime
    }
    if(!is.null(endTime))
    {    
      endTime <- as.character(endTime)
      config$endTime <- endTime
      et <- as.Date(endTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(et))
      {    
        stop("The end time must be of the format YYYY-MM-DD HH:MM:SS")
      }
    }
    else if(!is.null(.global$endTime))
    {
      endTime <- as.character(.global$endTime)
      config$endTime <- endTime
    }
    
    if(nchar(predictionDimensions) > 0)
    {
      offerConfig <- getOffer()$getConfig()
      offerConfig$offerKey <- predictionDimensions
      getOffer()$setConfig(offerConfig)
    }
    
    if(Utils.isSet(config))
    {
      o$setConfig(config)
    }
    getOffer()$setResponse(o)
  }
  
)
