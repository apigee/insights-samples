#Copyright 2014 Apigee Corporation
Model$methods(
  initialize = function(project, name, description="", type="", .skipI=FALSE){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(project=c("character","Project"),
                       name=c("character"),
                       description=c("character"),
                       .skipI=c("logical"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    .global <<- list()
    setName(name)
    setDescription(description)
    account <- .AIEnv[[".ApigeeInsights"]]
    if(Utils.checkClass(project, "Project"))
    {
      if(!project$getSaved())
      {
        tryCatch({
          setProject(account$getProject(project$getName()))

        }, AIErr=function(err){
          if(err$code==21)
          {
            Utils.info(err$message)
            project$store()
            setProject(project)
          }
          else
          {
            stop(err)
          }
        })
      }
      else
      {
        setProject(project)
      }
    }
    else{
      tryCatch({
        setProject(account$getProject(project))
      },AIErr=function(x){
        Utils.info(x$message)
        setProject(Project$new(.account=account, .name=project))
        getProject()$store()
      }) 
    }
    if(.skipI)
    {
      Utils.info("Model created successfully")
      return()
    }
    tryCatch({
      modelNames <- getProject()$getModelList()$name
      Utils.info("Checking for model duplicity...")
      if(name %in% modelNames)
      {
        stop("Model - ",name," already available. Use getModel method to fetch the model or change the model name")
      }
    }, AIErr=function(err){
    })
    setSaved(FALSE)
    offerConfig <- list()
    offerConfig$joinWindow <- "DAILY"
    offerConfig$joinMode <- "IMPRESSION_RESPONDER_JOIN"
    getClickStream()$getOffer()$setConfig(offerConfig)
    Utils.info("Model created successfully")
  },
  openJobManager = function()
  {
    url <- getProject()$getAccount()$getConfig()$jobManager
    if(!is.null(url))
    {   
      mn <- curlEscape(getName())
      url <- paste(url,"#resource=/management/jobBrowser&objectType=Model&objectName=",mn,"&objectId=",getId(),"&token=",getProject()$getAccount()$getToken(),"&userName=",getProject()$getAccount()$getUser(),sep="")
    }   
    else
    {   
      stop("jobManager base url not available in the configuration")
    }   
    browseURL(url)
  },
  setProject = function(project){
    signatures <- c("Project")
    if(!Utils.validateSignature(project,signatures))
    {
      stop("Invalid signature : project should be of type ", paste(signatures,collapse=" or "))
    }
    .project <<- project
  },
  getProject = function(){return(.project)},
  setClickStream = function(clickStream){
    signatures <- c("ClickStream")
    if(!Utils.validateSignature(clickStream,signatures))
    {
      stop("Invalid signature : clickStream should be of type ", paste(signatures,collapse=" or "))
    }
    .clickStream <<- clickStream
  },
  getClickStream = function(){return(.clickStream)},
  setConfig = function(config){
    signatures <- c("list")
    if(!Utils.validateSignature(config,signatures))
    {
      stop("Invalid signature : config should be of type ", paste(signatures,collapse=" or "))
    }
    .config <<- c(config)
  },
  setImpRespConfig = function(joinWindow, joinMode)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(joinWindow=c("character"),
                       joinMode=c("character"))
    if(joinWindow != "DAILY" && joinWindow != "MONTHLY" && joinWindow != "YEARLY")
    {
      stop("joinWindow should be either DAILY, MONTHLY or YEARLY")
    }
    if(joinMode != "IMPRESSION_RESPONSE_JOIN" && joinMode != "IMPRESSION_RESPONDER_JOIN")
    {
      stop("joinMode should be either IMPRESSION_RESPONSE_JOIN or IMPRESSION_RESPONDER_JOIN")
    }
    offerConfig <- getClickStream()$getOffer()$getConfig()
    offerConfig$joinWindow <- joinWindow
    offerConfig$joinMode <- joinMode
    getClickStream()$getOffer()$setConfig(offerConfig)
    Utils.signatureValidation(params, signatures, globalSignatures)
  },
  getConfig = function(){return(.config)},
  setName = function(name){
    signatures <- c("character")
    if(!Utils.validateSignature(name,signatures))
    {
      stop("Invalid signature : name should be of type ", paste(signatures,collapse=" or "))
    }
    .name <<- name
  },
  getName = function(){return(.name)},
  setDescription = function(description){
    signatures <- c("character")
    if(!Utils.validateSignature(description,signatures))
    {
      stop("Invalid signature : description should be of type ", paste(signatures,collapse=" or "))
    }
    .description <<- description
  },
  getDescription = function(){return(.description)},
  setId = function(id){
    signatures <- c("numeric")
    if(!Utils.validateSignature(id,signatures))
    {
      stop("Invalid signature : id should be of type ", paste(signatures,collapse=" or "))
    }
    .id <<- id
  },
  getId = function(){return(.id)},
  setSaved = function(saved){
    signatures <- c("logical")
    if(!Utils.validateSignature(saved,signatures))
    {
      stop("Invalid signature : saved should be of type ", paste(signatures,collapse=" or "))
    }
    .saved <<- saved
  },
  getSaved = function(){return(.saved)},
  setTrainingSplit = function(totalBucket, split=NULL)
  {
      if(is.null(split) || is.null(split) )
      {   
        stop("Split cannot be null or missing")
      }
      if(Utils.is.sequential(split))
      {
        r <- paste(range(split),collapse="-")
        s <- paste(totalBucket,":",r,sep="") 
      }
      else
      {
        s <- paste(totalBucket,":",paste(split,sep="",collapse=","),sep="")
      }
      config <- getConfig()
      config$splitConfig <- s
      setConfig(config)
  },
  setTrainingPercent = function(split)
  {
    if(split >= 100 || split <= 0) 
    {    
      stop("Split percent should be between 0 and 100")
    }
    setTrainingSplit(100,0:(split-1))
  },
  addActivityEvent = function(dataset, dimensions, catalog=NULL, metric=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","missing","NULL"),
                       dataset=c("character"),
                       dimensions=c("character","Dimensions","list"),
                       metric=c("character","missing","NULL"),
                       startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       endTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       partitions=c("character","missing","NULL"),
                       datastore=c("character","missing","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(is.null(startTime))
    startTime <- .global$startTime
    
    if(is.null(endTime))
    endTime <- .global$endTime
    
    if(!missing(startTime) && !is.null(startTime) && !missing(endTime) && !is.null(endTime))
    {
      if(endTime < startTime)
      {
        stop("endTime cannot be less than start time")
      }
    }
    
    #get catalog, dataset, partitions
    if(is.null(catalog))
    {
      if(!exists(".AIEnv") || is.null(.AIEnv$.catalog))
      {
        stop("catalog should be either passed as a parameter or set globally using setCatalog method")
      }
      catalog <- .AIEnv$.catalog
    }
    if(is.null(datastore))
    {
      datastore <- getDatastore()
    }
    if(is.null(partitions))
    {
      if(exists(".AIEnv") && !is.null(.AIEnv$.partitions))
      {
        partitions <- .AIEnv$.partitions
      }
    }
    if(getClickStream()$getOffer()$getResponse()$isSet())
    {
      resp <- getClickStream()$getOffer()$getResponse()
      rc <- resp$getPartition()[[1]]$getDataset()$getCatalog()$getName()
      rd <- resp$getPartition()[[1]]$getDataset()$getName()
#      if(catalog == rc && dataset == rd)
#      {
#        stop("Cannot use the same dataset from response")
#      }
    }
    if(!is.null(getClickStream()$getCombineActivity()$findGivenDatasetCatalogActivity(catalog,dataset)))
    {
      warning("Dataset already added. Overwriting.")
    }
    config <- list()
      
    account <- .AIEnv$.ApigeeInsights
    dm <- DataManager$new(.account=account)
    c <- dm$getCatalog(catalog)
    d <- c$getDataset(dataset)
    if(!d$isEvent())
    {
      stop("Dataset should be an event dataset")
    }
    a <- Activity$new()
    if(!is.null(partitions))
    {
      p <- d$getPartitions(partitions, datastore)
      data <- Utils.getStEtFromPartitions(p)
      pWithoutStats <- Utils.partitionsWithoutStats(data)
      if((is.null(startTime) || is.null(endTime)) && !is.null(pWithoutStats))
      {
        stop("Partitions ",paste(pWithoutStats,collapse=","), " does not have stats and startTime or endTime is missing. Either generate stats or provide startTime and endTime")
      }
        
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }

      for(parts in data)
      {
        pst <- parts$min
        pet <- parts$max
        pname <- parts$partition$getName()
        if(!is.null(pst) && !is.null(pet) && !is.null(startTime) && !is.null(endTime))
        {
          #if below is true, then it means the timestamp provided by user and the data does not overlap. So after transformation we will have empty data
          if(!((pst <= endTime)  &&  (pet >= startTime)))
          {
            warning("The time range provided does not overlap with the partition ",pname,". So the input data will be empty after filtering. The min and max time in the data are : ", st," & ",et)
          }
          
        }
      }
      a$setPartition(p)
    }
    else
    {
      p <- getAllPartitions(dataset=d, datastore=datastore)
      data <- Utils.getStEtFromPartitions(p)
      if(!is.null(data))
        p <- Utils.getPartitionsGivenStEt(startTime,endTime,data)
      
      pWithoutStats <- Utils.partitionsWithoutStats(data)
      if((is.null(startTime) || is.null(endTime)) && !is.null(pWithoutStats))
      {
        stop("Partitions ",paste(pWithoutStats,collapse=","), " does not have stats and startTime or endTime is missing. Either generate stats or provide startTime and endTime")
      }
      
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      a$setPartition(p)
      #a$setDatastore(datastore)
      #a$setDataset(d)
    }
    
    #Process dimensions
    if(typeof(dimensions) == "character")
    {
      dim <- Dimensions$new()
      dim$addDimensions(dimensions)
    }
    else if(typeof(dimensions) == "list")
    {
      dim <- Dimensions$new()
      for(dimension in dimensions)
      {
        dn <- paste(d$getName(),"-",paste(dimension,sep="",collapse="."),sep="",collapse="")
        dim$addDimension(dn,dimension)
      }
    }
    else
    {
      dim <- dimensions
    }
    
    if(!(length(dimensions) == 1 && typeof(dimensions) == "character" && dimensions == "ANY_COLUMN_EVENT"))
    {
      dfSchema <- data.frame(do.call("rbind",d$getSchema()))
      Utils.expandDimensions(dim,dfSchema$fieldName,d$getName())
      isNodeListOk <- Utils.doesExistInSchema(unlist(dim$.dimensionList),dfSchema$fieldName)
      if(isNodeListOk == FALSE)
      {
        stop("Dimension list validation failed with dataset '",d$getName(),"' schema. Please select from these field names : ", paste(unlist(dfSchema$fieldName),collapse=","))
      }
      else
      {
        dim <- dim$convertToString()
      }
    }
    else
    {
      dim <- dimensions
    }
    if(nchar(dim) == 0){
      stop("Dimension List cannot be empty")
    }
    config$nodeList <- dim
    
    #Process startTime and endTime
    if(!is.null(startTime))
    {    
      startTime <- as.character(startTime)
      config$startTime <- startTime
      st <- as.Date(startTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(st))
      {    
        stop("The start time must be of the format YYYY-MM-DD HH:MM:SS")
      }    
    }
    else if(!is.null(.global$startTime))
    {
      startTime <- as.character(.global$startTime)
      config$startTime <- startTime
    }
    if(!is.null(endTime))
    {    
      endTime <- as.character(endTime)
      config$endTime <- endTime
      et <- as.Date(endTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(et))
      {    
        stop("The end time must be of the format YYYY-MM-DD HH:MM:SS")
      }
    }
    else if(!is.null(.global$endTime))
    {
      endTime <- as.character(.global$endTime)
      config$endTime <- endTime
    }
    
    if(!is.null(metric))
    {
      if(metric != "metrics_count")
      {
        isAvailable <- Utils.doesExistInSchema(metric,dfSchema$fieldName)
        if(isAvailable == FALSE)
        {
          stop("Metric ",metric," cannot be found in the schema")
        }
      }
    }
    else
    {
      metric <- "metrics_count"
    }
    config$intensityMetric <- metric
    if(Utils.isSet(config))
    {
      a$setConfig(config)
    }
    getClickStream()$getCombineActivity()$addActivity(a)
  },
  refreshPartitions = function()
  {
    objects <- getClickStream()$getCombineActivity()$getActivity()
    if(getClickStream()$getOffer()$getImpression()$isSet())
      objects <- c(objects, getClickStream()$getOffer()$getImpression())
    
    if(getClickStream()$getOffer()$getResponse()$isSet())
      objects <- c(objects, getClickStream()$getOffer()$getResponse())
    for(obj in objects)
    {
      startTime <- obj$getConfig()$startTime
      endTime <- obj$getConfig()$endTime
      d <- obj$getPartition()[[1]]$getDataset()
      datastore <- obj$getPartition()[[1]]$getDatastore()
      p <- getAllPartitions(dataset=d, datastore=datastore)
      data <- Utils.getStEtFromPartitions(p)
      if(!is.null(data))
        p <- Utils.getPartitionsGivenStEt(startTime,endTime,data)
      
      pWithoutStats <- Utils.partitionsWithoutStats(data)
      if((is.null(startTime) || is.null(endTime)) && !is.null(pWithoutStats))
      {
        stop("Partitions ",paste(pWithoutStats,collapse=","), " does not have stats and startTime or endTime is missing. Either generate stats or provide startTime and endTime")
      }
      
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      if(is.null(p) || length(p) == 0)
      {
        warning("Based on the time range, no data available for catalog=",d$getCatalog()$getName()," dataset=",d$getName())
      }
      else
        obj$setPartition(p)
      #a$setDatastore(datastore)
      #a$setDataset(d)
    }
  },
  setDateFilter = function(startTime=NULL, endTime=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(
                       startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       endTime=c("character","POSIXt","POSIXlt","missing","NULL")
                       )
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(is.null(startTime) && is.null(endTime))
    {
      stop("Both start time and end time cannot be missing")
    }
    if(!is.null(startTime))
    {    
      startTime <- as.character(startTime)
      st <- as.Date(startTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(st))
      {    
        stop("The start time must be of the format YYYY-MM-DD HH:MM:SS")
      }
      .global$startTime <<- startTime
    }    
    if(!is.null(endTime))
    {    
      endTime <- as.character(endTime)
      et <- as.Date(endTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(et))
      {    
        stop("The end time must be of the format YYYY-MM-DD HH:MM:SS")
      }
      .global$endTime <<- endTime
    }
    #response start and end time
    if(getClickStream()$getOffer()$getResponse()$isSet())
    {
      respConfig <- getClickStream()$getOffer()$getResponse()$getConfig()
      if(!is.null(startTime))
        respConfig$startTime <- startTime
      if(!is.null(endTime))
        respConfig$endTime <- endTime
      getClickStream()$getOffer()$getResponse()$setConfig(respConfig)
    }
    if(getClickStream()$getOffer()$getImpression()$isSet())
    {
      impConfig <- getClickStream()$getOffer()$getImpression()$getConfig()
      if(!is.null(startTime))
        impConfig$startTime <- startTime
      if(!is.null(endTime))
        impConfig$endTime <- endTime
      getClickStream()$getOffer()$getImpression()$setConfig(impConfig)
    }
    if(Utils.isSet(getClickStream()$getCombineActivity()$getActivity()))
    {
      aList <- getClickStream()$getCombineActivity()$getActivity()
      for(activity in aList)
      {
        aConfig <- activity$getConfig()
        if(!is.null(startTime))
          aConfig$startTime <- startTime
        if(!is.null(endTime))
          aConfig$endTime <- endTime
        activity$setConfig(aConfig)
        #getClickStream()$getCombineActivity()$addActivity(activity)
      }
    }
    refreshPartitions()
  },
  show = function()
  {
    cat("Account = ", getProject()$getAccount()$.account)
    cat("\nProject = ", getProject()$getName())
    cat("\nModel Object :\n\n")
    cat("Model Name =",getName(),"\n")
    cat("Model Description =",getDescription(),"\n")
    if(length(getConfig()) > 0)
    {   
      cat("********* Model Configs *********")
      pandoc.table(as.data.frame(getConfig()), split.cells=50, split.table=1220,style="grid")
    }   
    if(length(getClickStream()$getOffer()$getConfig()) > 0)
    {   
      cat("********* Offer Configs *********")
      pandoc.table(as.data.frame(getClickStream()$getOffer()$getConfig()), split.cells=50, split.table=1220,style="grid")
    }
    if(getClickStream()$getOffer()$getImpression()$isSet())
    {   
      cat("\n********* Impression Dataset *********")
      impression <- collapsePartitions(getClickStream()$getOffer()$getImpression()$toJsonStructure())
      if(impression$config$impressionMetric == "")
      {
        impression$config$impressionMetric <- "impression_count"
      }
      uli <- unlist(impression)
      pandoc.table(t(uli), split.cells=50, split.table=1220,style="grid")
    }   
    if(getClickStream()$getOffer()$getResponse()$isSet() > 0)
    {   
      cat("\n********* Response Dataset *********")
      response <- collapsePartitions(getClickStream()$getOffer()$getResponse()$toJsonStructure())
      if(response$config$responseMetric == "")
      {
        response$config$responseMetric <- "response_count"
      }
      ulr <- unlist(response)
      pandoc.table(t(ulr), split.cells=50, split.table=1220,style="grid")
    }
    ca <- getClickStream()$getCombineActivity()$toJsonStructure()
    if(length(ca$activity) > 0)
    {   
      cat("\n******************* Activity Dataset *******************")
      activity <- lapply(ca$activity,collapsePartitions)
      dfa <- Utils.convertToDataFrame(activity)
      pandoc.table(dfa, split.cells=50, split.table=1220,style="grid")
    }   
    if(length(ca$profile) > 0)
    {   
      cat("\n******************* Profile Dataset *******************")
      profile <- lapply(ca$profile,collapsePartitions)
      ulp <- sapply(profile,unlist)
      pandoc.table(t(ulp), split.cells=50, split.table=1220,style="grid")
    }
  },
  setConfiguration = function(key, value)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(key=c("character"),
                       value=c("character","numeric"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(!(key %in% c("numReducers","firstLevelThreshold","setThreshold","distanceIntervalStart","robotThreshold","corelationFreqThreshold","responseThreshold")))
    {
      stop(key," is not supported.")
    }
    if(class(value) == "numeric")
    {   
      value <- sprintf("%.f",value)
    }   
    key <- Utils.trim(key)
    config <- getConfig()
    config[[key]] <- value
    setConfig(config)
    if(key == "setThreshold")
    {
      setConfiguration("corelationFreqThreshold",value)
    }
  },
  setProfile = function(dataset, dimensions, catalog=NULL, partitions=NULL, datastore=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","missing","NULL"),
                       dataset=c("character"),
                       dimensions=c("character","Dimensions","list"),
                       partitions=c("character","missing","NULL"),
                       datastore=c("character","missing","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    
    #get catalog, dataset, partitions
    if(is.null(catalog))
    {
      if(!exists(".AIEnv") || is.null(.AIEnv$.catalog))
      {
        stop("catalog should be either passed as a parameter or set globally using setCatalog method")
      }
      catalog <- .AIEnv$.catalog
    }
    if(is.null(datastore))
    {
      datastore <- getDatastore()
    }
    if(is.null(partitions))
    {
      if(exists(".AIEnv") && !is.null(.AIEnv$.partitions))
      {
        partitions <- .AIEnv$.partitions
      }
    }
    config <- list()
    
    account <- .AIEnv$.ApigeeInsights
    dm <- DataManager$new(.account=account)
    c <- dm$getCatalog(catalog)
    d <- c$getDataset(dataset)
    if(!d$getDataType() == "userprofile")
    {
      stop("Dataset should be profile dataset")
    }
    o <- Profile$new()
    if(!is.null(partitions))
    {
      p <- d$getPartitions(partitions)
      o$setPartition(p)
    }
    else
    {
      #Remove this code for getting all partitions
      o$setPartition(getAllPartitions(dataset=d))
      #a$setDatastore(datastore)
      #a$setDataset(d)
    }
    
    #Process dimensions
    if(typeof(dimensions) == "character")
    {
      dim <- Dimensions$new()
      dim$addDimensions(dimensions)
    }
    else if(typeof(dimensions) == "list")
    {
      dim <- Dimensions$new()
      for(dimension in dimensions)
      {
        dn <- paste(d$getName(),"-",paste(dimension,sep="",collapse="."),sep="",collapse="")
        dim$addDimension(dn,dimension)
      }
    }
    else
    {
      dim <- dimensions
    }
    
    dfSchema <- data.frame(do.call("rbind",d$getSchema()))
    Utils.expandDimensions(dim,dfSchema$fieldName)
    isNodeListOk <- Utils.doesExistInSchema(unlist(dim$.dimensionList),dfSchema$fieldName)
    if(isNodeListOk == FALSE)
    {
      stop("Dimension list validation failed with dataset '",d$getName(),"' schema. Please select from these field names : ", paste(unlist(dfSchema$fieldName),collapse=","))
    }
    else
    {
      dim <- dim$convertToString()
    }
    if(nchar(dim) == 0){
      stop("Dimension List cannot be empty")
    }
    config$profileList <- dim
    
    if(Utils.isSet(config))
    {
      o$setConfig(config)
    }
    getClickStream()$getCombineActivity()$addProfile(o)
  },
  cloneObject = function(name, description="")
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(name=c("character"),
                       description = "character")
    Utils.signatureValidation(params, signatures, globalSignatures)
    clonedModel <- Model$new(getProject(),name,description)
    if(Utils.isSet(getConfig()))
      clonedModel$setConfig(getConfig())
    if(Utils.isSet(getClickStream()$getOffer()$getConfig()))
      clonedModel$getClickStream()$getOffer()$setConfig(getClickStream()$getOffer()$getConfig())
    
    clonedModel$getClickStream()$getOffer()$setImpression(getClickStream()$getOffer()$getImpression()$copy())
    clonedModel$getClickStream()$getOffer()$setResponse(getClickStream()$getOffer()$getResponse()$copy())
    objects <- getClickStream()$getCombineActivity()$getActivity()
    for(obj in objects)
    {
      newObj <- obj$copy()
      clonedModel$getClickStream()$getCombineActivity()$addActivity(newObj)
    }
    objects <- getClickStream()$getCombineActivity()$getProfile()
    for(obj in objects)
    {
      newObj <- obj$copy()
      clonedModel$getClickStream()$getCombineActivity()$addProfile(newObj)
    }
    #ms <- toJsonStructure()
    #ms$name <- name
    #ms$description <- description
    #clonedModel <- Utils.buildModelFromJson(getProject(),ms)
    clonedModel$.global <- .global
    clonedModel$setSaved(FALSE)
    return(clonedModel)
  },
  setResponseEvent = function(dataset, predictionDimensions=NULL, catalog=NULL, metric=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","missing","NULL"),
                       dataset=c("character"),
                       predictionDimensions=c("character","missing","NULL"),
                       metric=c("character","missing","NULL"),
                       startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       endTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       partitions=c("character","missing","NULL"),
                       datastore=c("character","missing","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(is.null(metric))
    {
      #metric <- "metrics_count"
      metric <- ""
    }
    imp <- getClickStream()$getOffer()$getImpression()
    if(imp$isSet())
    {
      if(!is.null(imp$getConfig()$impressionMetric) && imp$getConfig()$impressionMetric == metric)
      {
        if(imp$getConfig()$impressionMetric != "")
        stop("Impression metric and Response metric cannot be same.")
      }
    }
    if(is.null(startTime))
      startTime <- .global$startTime
    
    if(is.null(endTime))
      endTime <- .global$endTime
    
    if(!missing(startTime) && !is.null(startTime) && !missing(endTime) && !is.null(endTime))
    {
      if(endTime < startTime)
      {
        stop("endTime cannot be less than start time")
      }
    }
    if(is.null(predictionDimensions))
    {
      predictionDimensions <- ""
    }
    else
    {
      predictionDimensions <- paste(predictionDimensions,sep=",",collapse=",")
    }
    if((length(getClickStream()$getOffer()$getImpression()$getDataset()$getName()) == 1 || length(getClickStream()$getOffer()$getImpression()$getPartition()) == 1 ) && nchar(predictionDimensions) == 0){
      if(is.null(getClickStream()$getOffer()$getConfig()$offerKey))
      {
        stop("Prediction dimensions cannot be empty in impression and response")
      }
    }
    
    #get catalog, dataset, partitions
    if(is.null(catalog))
    {
      if(!exists(".AIEnv") || is.null(.AIEnv$.catalog))
      {
        stop("catalog should be either passed as a parameter or set globally using setCatalog method")
      }
      catalog <- .AIEnv$.catalog
    }
    if(is.null(datastore))
    {
      datastore <- getDatastore()
    }
    if(is.null(partitions))
    {
      if(exists(".AIEnv") && !is.null(.AIEnv$.partitions))
      {
        partitions <- .AIEnv$.partitions
      }
    }
#    if(!is.null(getClickStream()$getCombineActivity()$findGivenDatasetCatalogActivity(catalog,dataset)))
#    {
#      stop("Cannot use the same dataset from activity")
#    }
    config <- list()
    
    account <- .AIEnv$.ApigeeInsights
    dm <- DataManager$new(.account=account)
    c <- dm$getCatalog(catalog)
    d <- c$getDataset(dataset)
    
    if(!d$isEvent())
    {
      stop("Dataset should be an event dataset")
    }
    
    o <- Response$new()
    
    
    
    
    
    if(!is.null(partitions))
    {
      p <- d$getPartitions(partitions, datastore)
      data <- Utils.getStEtFromPartitions(p)
      pWithoutStats <- Utils.partitionsWithoutStats(data)
      if((is.null(startTime) || is.null(endTime)) && !is.null(pWithoutStats))
      {
        stop("Partitions ",paste(pWithoutStats,collapse=","), " does not have stats and startTime or endTime is missing. Either generate stats or provide startTime and endTime")
      }
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      for(parts in data)
      {
        pst <- parts$min
        pet <- parts$max
        pname <- parts$partition$getName()
        if(!is.null(pst) && !is.null(pet) && !is.null(startTime) && !is.null(endTime))
        {
          #if below is true, then it means the timestamp provided by user and the data does not overlap. So after transformation we will have empty data
          if(!((pst <= endTime)  &&  (pet >= startTime)))
          {
            warning("The time range provided does not overlap with the partition ",pname,". So the input data will be empty after filtering. The min and max time in the data are : ", st," & ",et)
          }
          
        }
      }
      o$setPartition(p)
    }
    else
    {
      #Remove this code for getting all partitions
      p <- getAllPartitions(dataset=d, datastore=datastore)
      data <- Utils.getStEtFromPartitions(p)
      if(!is.null(data))
        p <- Utils.getPartitionsGivenStEt(startTime,endTime,data)
      pWithoutStats <- Utils.partitionsWithoutStats(data)
      if((is.null(startTime) || is.null(endTime)) && !is.null(pWithoutStats))
      {
        stop("Partitions ",paste(pWithoutStats,collapse=","), " does not have stats and startTime or endTime is missing. Either generate stats or provide startTime and endTime")
      }
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      o$setPartition(p)
    }
    
    
    
    #Process predictionDimensions
    if(nchar(predictionDimensions) > 0)
    {
      offerConfig <- getClickStream()$getOffer()$getConfig()
      offerConfig$offerKey <- predictionDimensions
      getClickStream()$getOffer()$setConfig(offerConfig)
    }
    
    
    #Process startTime and endTime
    if(!is.null(startTime))
    {    
      startTime <- as.character(startTime)
      config$startTime <- startTime
      st <- as.Date(startTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(st))
      {    
        stop("The start time must be of the format YYYY-MM-DD HH:MM:SS")
      }    
    } 
    else if(!is.null(.global$startTime))
    {
      startTime <- as.character(.global$startTime)
      config$startTime <- startTime
    }
    if(!is.null(endTime))
    {    
      endTime <- as.character(endTime)
      config$endTime <- endTime
      et <- as.Date(endTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(et))
      {    
        stop("The end time must be of the format YYYY-MM-DD HH:MM:SS")
      }
    }
    else if(!is.null(.global$endTime))
    {
      endTime <- as.character(.global$endTime)
      config$endTime <- endTime
    }
    
    dfSchema <- data.frame(do.call("rbind",d$getSchema()))
    if(!getClickStream()$getOffer()$getImpression()$isSet())
    {
      joinKey <- NULL 
      uName <- unlist(dfSchema$fieldName[grep("user",unlist(dfSchema$fieldTag))])
      tName <- unlist(dfSchema$fieldName[grep("timestamp",unlist(dfSchema$fieldTag))])
      if(!is.null(uName))
      {    
        joinKey <- c(joinKey,uName)
      }    
      if(!is.null(tName))
      {    
        joinKey <- c(joinKey,tName)
      }
      fields <- paste(joinKey,collapse=",")
      fields <- gsub(",+",",",fields)
      joinKey <- fields
      fields <- unlist(strsplit(fields,",",fixed=TRUE))
      config$joinKey <- joinKey
    }
    
    if(!is.null(metric))
    {
      if(metric != "")
      {
        isAvailable <- Utils.doesExistInSchema(metric,dfSchema$fieldName)
        if(isAvailable == FALSE)
        {
          stop("Metric ",metric," cannot be found in the schema")
        }
      }
    }
    config$responseMetric <- metric
  
    rjk <- getClickStream()$getOffer()$getResponse()$getConfig()$joinKey
    if(!is.null(rjk))
    {
      config$joinKey <- rjk
    }
  
    if(Utils.isSet(config))
    {
      o$setConfig(config)
    }
    getClickStream()$getOffer()$setResponse(o)
  },
  setImpressionEvent = function(dataset, predictionDimensions=NULL, responseMerge, catalog=NULL, metric=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","missing","NULL"),
                       dataset=c("character"),
                       predictionDimensions=c("character","missing","NULL"),
                       responseMerge=c("list"),
                       metric=c("character","missing","NULL"),
                       startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       endTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       partitions=c("character","missing","NULL"),
                       datastore=c("character","missing","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    
    if(is.null(metric))
    {
      #metric <- "metrics_count"
      metric <- ""
    }
    resp <- getClickStream()$getOffer()$getResponse()
    if(resp$isSet())
    {
      if(!is.null(resp$getConfig()$responseMetric) && resp$getConfig()$responseMetric == metric)
      {
        if(resp$getConfig()$responseMetric != "")
        stop("Impression metric and Response metric cannot be same.")
      }
    }
    
    resVal <- Utils.validateCharacter(responseMerge$response)
    impVal <- Utils.validateCharacter(responseMerge$impression)
    if(is.null(startTime))
      startTime <- .global$startTime
    
    if(is.null(endTime))
      endTime <- .global$endTime
    
    if(!missing(startTime) && !is.null(startTime) && !missing(endTime) && !is.null(endTime))
    {
      if(endTime < startTime)
      {
        stop("endTime cannot be less than start time")
      }
    }
    if(resVal == 1 || impVal == 1)
    {    
      stop("Impression and Response merge keys should be of type character")
    }
    if(resVal == 2 || impVal == 2)
    {
      stop("Impression and Response merge keys cannot be empty")
    }
    if(is.null(predictionDimensions))
    {
      predictionDimensions <- ""
    }
    else
    {
      predictionDimensions <- paste(predictionDimensions,sep=",",collapse=",")
    }
    if((length(getClickStream()$getOffer()$getResponse()$getDataset()$getName()) == 1 || length(getClickStream()$getOffer()$getResponse()$getPartition()) == 1 ) && nchar(predictionDimensions) == 0){
      if(is.null(getClickStream()$getOffer()$getConfig()$offerKey))
      {
        stop("Prediction dimensions cannot be empty in impression and response")
      }
    }
    
    #get catalog, dataset, partitions
    if(is.null(catalog))
    {
      if(!exists(".AIEnv") || is.null(.AIEnv$.catalog))
      {
        stop("catalog should be either passed as a parameter or set globally using setCatalog method")
      }
      catalog <- .AIEnv$.catalog
    }
    if(is.null(datastore))
    {
      datastore <- getDatastore()
    }
    if(is.null(partitions))
    {
      if(exists(".AIEnv") && !is.null(.AIEnv$.partitions))
      {
        partitions <- .AIEnv$.partitions
      }
    }
    config <- list()
    
    account <- .AIEnv$.ApigeeInsights
    dm <- DataManager$new(.account=account)
    c <- dm$getCatalog(catalog)
    d <- c$getDataset(dataset)
    if(!d$isEvent())
    {
      stop("Dataset should be an event dataset")
    }
    o <- Impression$new()
    
    
    if(!is.null(partitions))
    {
      p <- d$getPartitions(partitions, datastore)
      data <- Utils.getStEtFromPartitions(p)
      pWithoutStats <- Utils.partitionsWithoutStats(data)
      if((is.null(startTime) || is.null(endTime)) && !is.null(pWithoutStats))
      {
        stop("Partitions ",paste(pWithoutStats,collapse=","), " does not have stats and startTime or endTime is missing. Either generate stats or provide startTime and endTime")
      }
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      for(parts in data)
      {
        pst <- parts$min
        pet <- parts$max
        pname <- parts$partition$getName()
        if(!is.null(pst) && !is.null(pet) && !is.null(startTime) && !is.null(endTime))
        {
          #if below is true, then it means the timestamp provided by user and the data does not overlap. So after transformation we will have empty data
          if(!((pst <= endTime)  &&  (pet >= startTime)))
          {
            warning("The time range provided does not overlap with the partition ",pname,". So the input data will be empty after filtering. The min and max time in the data are : ", st," & ",et)
          }
          
        }
      }
      o$setPartition(p)
    }
    else
    {
      #Remove this code for getting all partitions
      p <- getAllPartitions(dataset=d, datastore=datastore)
      data <- Utils.getStEtFromPartitions(p)
      if(!is.null(data))
        p <- Utils.getPartitionsGivenStEt(startTime,endTime,data)
      pWithoutStats <- Utils.partitionsWithoutStats(data)
      if((is.null(startTime) || is.null(endTime)) && !is.null(pWithoutStats))
      {
        stop("Partitions ",paste(pWithoutStats,collapse=","), " does not have stats and startTime or endTime is missing. Either generate stats or provide startTime and endTime")
      }
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      o$setPartition(p)
    }
    
    
    
    
    #Process predictionDimensions
    if(nchar(predictionDimensions) > 0)
    {
      offerConfig <- getClickStream()$getOffer()$getConfig()
      offerConfig$offerKey <- predictionDimensions
      getClickStream()$getOffer()$setConfig(offerConfig)
    }
    
    
    #Process startTime and endTime
    if(!is.null(startTime))
    {    
      startTime <- as.character(startTime)
      config$startTime <- startTime
      st <- as.Date(startTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(st))
      {    
        stop("The start time must be of the format YYYY-MM-DD HH:MM:SS")
      }    
    } 
    else if(!is.null(.global$startTime))
    {
      startTime <- as.character(.global$startTime)
      config$startTime <- startTime
    }
    if(!is.null(endTime))
    {    
      endTime <- as.character(endTime)
      config$endTime <- endTime
      et <- as.Date(endTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(et))
      {    
        stop("The end time must be of the format YYYY-MM-DD HH:MM:SS")
      }
    }
    else if(!is.null(.global$endTime))
    {
      endTime <- as.character(.global$endTime)
      config$endTime <- endTime
    }
    impJK <- responseMerge$impression
    dfSchema <- data.frame(do.call("rbind",d$getSchema()))
    isImpJKOk <- Utils.doesExistInSchema(impJK,dfSchema$fieldName)
    if(isImpJKOk == FALSE)
    {
      stop("Impression join key validation failed with dataset '",d$getName(),"' schema. Please select from these field names : ", paste(unlist(dfSchema$fieldName),collapse=","))
    }
    impJK <-paste(impJK,sep=",",collapse=",")
    respJK <- responseMerge$response
    if(getClickStream()$getOffer()$getResponse()$isSet())
    {
      rd <- getClickStream()$getOffer()$getResponse()$getPartition()[[1]]$getDataset()
      rdfSchema <- data.frame(do.call("rbind",rd$getSchema()))
      isRespJKOk <- Utils.doesExistInSchema(respJK,rdfSchema$fieldName)
      if(isRespJKOk == FALSE)
      {
        stop("Response join key validation failed with dataset '",rd$getName(),"' schema. Please select from these field names : ", paste(unlist(rdfSchema$fieldName),collapse=","))
      }
    }
    respJK <-paste(respJK,sep=",",collapse=",")
    config$joinKey <- impJK        
    if(!is.null(metric))
    {
      if(metric != "")
      {
        isAvailable <- Utils.doesExistInSchema(metric,dfSchema$fieldName)
        if(isAvailable == FALSE)
        {
          stop("Metric ",metric," cannot be found in the schema")
        }
      }
    }
    config$impressionMetric <- metric
    if(Utils.isSet(config))
    {
      o$setConfig(config)
    }
    rConfig <- getClickStream()$getOffer()$getResponse()$getConfig()
    rConfig$joinKey <- respJK
    getClickStream()$getOffer()$getResponse()$setConfig(rConfig)
    getClickStream()$getOffer()$setImpression(o)
  },
  toJsonStructure = function()
  {
    obj <- list()
    if(Utils.isSet(.name))  
    obj[["name"]] <- .name
    if(Utils.isSet(.description))
    obj[["description"]] <- .description
    if(Utils.isSet(.project))
    obj[["project"]] <- .project$getName()
    if(Utils.isSet(.config))
    obj[["config"]] <- .config
    obj[["clickStream"]] <- .clickStream$toJsonStructure()
    if(Utils.isSet(.id))
    {
      obj[["id"]] <- .id
    }
    if(!is.null(.global$visibility))
    {
      obj[["visibility"]] <- .global$visibility
    }
    return(obj)
  },
  setVisibility = function(flag="External")
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(
      flag=c("character")
    )
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(length(flag) == 1 && (flag == "External" || flag == "Internal"))
    {
      .global$visibility <<- flag
    }
  },
  generateCEndPoint = function(id="")
  {
    id <- curlEscape(id)
    host <- Utils.trim(getProject()$generateCEndPoint(getName()))
    if(id != "")
    {
      id <- paste("/",id,sep="")
    }
    return(paste(host,"/scores",id,sep=""))
  },
  generateEndPoint = function(id="")
  {
    return(getProject()$generateCEndPoint(id))
  },
  store = function()
  {
    if(getProject()$getSaved()== FALSE)
    {    
      stop("Save the project in order to continue")
    }    
    if(getSaved() == TRUE){
      return(update())
    }    
    name <- getName()
    url <- generateEndPoint()
    params = list(accountId=getProject()$getAccount()$getId(),token=getProject()$getAccount()$getToken(),entityIdType="name")
    #cat(params$accountId,params$token)
    if(!getClickStream()$getOffer()$getImpression()$isSet())
    {    
      if(!is.null(getClickStream()$getOffer()$getConfig()$offerKey))
      {    
        jKey <- getClickStream()$getOffer()$getResponse()$getConfig()$joinKey
        oKey <- getClickStream()$getOffer()$getConfig()$offerKey
        if(!grepl(paste("\\b",oKey,"\\b",sep=""),jKey) && oKey != "ANY_COLUMN_EVENT")
        {    
          rConfig <- getClickStream()$getOffer()$getResponse()$getConfig()
          rConfig$joinKey <- paste(jKey,oKey,sep=",")
          getClickStream()$getOffer()$getResponse()$setConfig(rConfig)
        }    
      } 
      else
      {
        stop("Prediction dimensions cannot be empty")
      }
    }
    jsonObj = toJsonStructure()
    JSON = toJSON(jsonObj)
    tryCatch({
      data <- sendRequest(url,"post",params,JSON)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {    
        stop(x)
      }    
      template <- paste(MESSAGES$ENTITY$MODEL,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<MODEL>"]] <- name 
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })   
    
    #Utils.debug("storeModel",data)
    setSaved(TRUE)
    setId(data$modelId)
  },
  update = function()
  {
    name <- getName()
    url <- generateEndPoint(name)
    params = list(accountId=getProject()$getAccount()$getId(),token=getProject()$getAccount()$getToken(),entityIdType="name",project=getProject()$getName())
    if(!getClickStream()$getOffer()$getImpression()$isSet())
    {    
      if(!is.null(getClickStream()$getOffer()$getConfig()$offerKey))
      {    
        jKey <- getClickStream()$getOffer()$getResponse()$getConfig()$joinKey
        oKey <- getClickStream()$getOffer()$getConfig()$offerKey
        if(!grepl(paste("\\b",oKey,"\\b",sep=""),jKey)  && oKey != "ANY_COLUMN_EVENT")
        {    
          rConfig <- getClickStream()$getOffer()$getResponse()$getConfig()
          rConfig$joinKey <- paste(jKey,oKey,sep=",")
          getClickStream()$getOffer()$getResponse()$setConfig(rConfig)
        }    
      } 
      else
      {
        stop("Prediction dimensions cannot be empty")
      }
    }
    jsonObj = toJsonStructure()
    JSON = toJSON(jsonObj)
    tryCatch({
      data <- sendRequest(url,"put",params,JSON)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {    
        stop(x)
      }    
      template <- paste(MESSAGES$ENTITY$MODEL,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<MODEL>"]] <- name 
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })   
    
    #Utils.debug("storeModel",data)
    setSaved(TRUE)
  },
  execute = function()
  {
    name <- getName()
    if(getStatus() == "Unsaved")
    {
      store()
    }
    url <- generateEndPoint(name)
    url <- paste(url,"/execute_op",sep="")
    params = list(accountId=getProject()$getAccount()$getId(),token=getProject()$getAccount()$getToken(),entityIdType="name",project=getProject()$getName())
    #cat(params$accountId,params$token)
    tryCatch({
      data <- sendRequest(url,"put",params,"{}")
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {
        stop(x)
      }
      template <- paste(MESSAGES$ENTITY$MODEL,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<MODEL>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })
    
  },
  getStatus = function()
  {
    name <- getName()
    if(getSaved() == FALSE)
    {   
      s <- "Unsaved"
      #Utils.verbose(paste("Status of model :",object@name,"-> ",s,sep=""))
      return(s)
    }   
    else
    {   
      url <- generateEndPoint(getName())
      url <- paste(url,"/getState_op",sep="")
      params = list(accountId=getProject()$getAccount()$getId(),token=getProject()$getAccount()$getToken(),entityIdType="name",project=getProject()$getName())
      tryCatch({
        data <- sendRequest(url,"get",params)
      },AIErr=function(x){
        if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
        {   
          stop(x)
        }   
        template <- paste(MESSAGES$ENTITY$MODEL,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
        tv <- .AIEnv[[".TEMPLATE_VALUES"]]
        tv[["<MODEL>"]] <- name
        msg <- replaceTemplate(template,tv)
        stop(createAIErr(x$code,msg))
      })  
      #Utils.verbose(paste("Status of model :",object@name,"->",data$state,sep=""))
      return(data$state)
    }
  },
  getScore = function(name){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    Utils.signatureValidation(params, globalSignatures=globalSignatures)
    url <- generateCEndPoint(name)
    pn <- getProject()$getName()
    params = list(accountId=getProject()$getAccount()$getId(),token=getProject()$getAccount()$getToken(),entityIdType="name",project=pn)
    Utils.info(paste("Fetching score - ",name,"...",sep="",collapse=""))
    tryCatch({
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES$ENTITY$SCORE,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<SCORE>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })  
    Utils.info("Fetching successful")
    score <- Utils.buildScoreFromJson(.self,data$score,.skipI=TRUE)
    score$setSaved(TRUE)
    return(score)
  },
  stream = function(topN=100,sep="\t")
  {
    acc<- .AIEnv$.ApigeeInsights
    dm <- acc$getDataManager()
    cn <- paste(getProject()$getName(),sep="")
    p <- dm$getPartition(catalog=cn, dataset="model", partition=getName())
    pdf <- p$stream(topN=topN, sep=sep)
    pdf$liftScaled <- NULL
    return(pdf)
  },
  getScoreList = function(){
    pn <- getProject()$getName()
    url <- generateCEndPoint()
    params = list(accountId=getProject()$getAccount()$getId(),token=getProject()$getAccount()$getToken(),entityIdType="name",project=pn)
    Utils.info("Fetching score list...")
    tryCatch({
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })  
    Utils.info("Fetching successful")
    ld <- data.frame(do.call("rbind",data$scores))
    return(ld)
  }
)
setGeneric("merge",
           function(by.response, by.impression) {
             standardGeneric("merge")
           })
#'@export
setMethod("merge", signature(by.response="character",by.impression="character"),
          function(by.response, by.impression) {
            responseMerge <- list(response=by.response, impression=by.impression)
            return(responseMerge)
          })
