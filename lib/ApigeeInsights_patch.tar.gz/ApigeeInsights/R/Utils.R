#Copyright 2014 Apigee Corporation
#'@export
Utils.debug <- function(msg, x=NULL){
  isDebugEnabled <- .AIEnv[[".isDebug"]]
  if(isDebugEnabled == 1)
  {
    #cat(paste("\n============== DEBUG START MSG:",msg,"==============\n"))
    cat(msg,"\n")
    cat(x)
    cat("\n")
    #cat(paste("============== DEBUG END MSG:",msg,"==============\n"))
  }
}
Utils.info <- function(msg, x=NULL){
  isInfoEnabled <- .AIEnv[[".isInfo"]]
  if(isInfoEnabled == 1)
  {
    cat("INFO : ")
    cat(msg,"\n")
    if(!is.null(x))
    {
      cat(x)
    }
  }
}
Utils.checkClass <- function(object, className)
{
    if(class(object)[[1]] != className)
    {
      return(FALSE)
    }
  return(TRUE)
}
Utils.signatureValidation <- function(params, signatures=list(), globalSignatures=NULL)
{
  for(pName in names(params))
  {
    pValue <- params[[pName]]
    pSig <- signatures[[pName]]
    if(is.null(pSig))
    {
      pSig <- globalSignatures
      if(is.null(pSig))
      {
        if(!missing(pValue))
          pSig <- class(pValue)[[1]]
        else
          pSig <- "missing"
      }
    }
    if(!Utils.validateSignature(pValue,pSig))
    {
      stop("Invalid signature : ", pName," should be of type ", paste(pSig,collapse=" or "))
    }
  }
}
Utils.validateSignature <- function(object,signatures)
{
  if(!Utils.checkClass(signatures,"character"))
  {
    return(FALSE)
  }
  if(missing(object)){
    if(length(grep(pattern="\\bmissing\\b",x=signatures)) < 1)
    {
      return(FALSE)
    }
    else
    {
      return(TRUE)
    }
  }
  
  for(sig in signatures)
  {
    class <- unlist(strsplit(sig,"-",T))
    if(length(class) == 2 && class[1] == "list" && Utils.validateList(object,class[2]))
    {
      return(TRUE) 
    }
    else if(length(class) == 1 && class[1] == "list" && Utils.validateList(object,NULL))
    {
      return(TRUE)
    }
    else if(class[1] != "list" && Utils.checkClass(object,class[1]))
    {
      return(TRUE)
    }
  }
  return(FALSE)
}
Utils.validateList <- function(object, type=NULL)
{
  if(class(object)[[1]] != "list")
  {
    return(FALSE)
  }
  else if(length(object) == 0)
  {
    return(FALSE)
  }
  if(!is.null(type))
  {
    for(item in object)
    {
      if(!Utils.checkClass(item,type))
      {
        return(FALSE)
      }
    }
  }
  return(TRUE)
}
Utils.isSet <- function(object)
{
  if(length(object) == 0L)
  {
    return(FALSE)
  }
  else
  {
    return(TRUE)
  }
}
#'@export
Utils.verbose <- function(msg){
  cat("\n",msg,"\n")
}
#'@export
Utils.trim.leading <- function (x)  sub("^\\s+", "", x)

#'@export
Utils.trim.trailing <- function (x) sub("\\s+$", "", x)

#'@export
Utils.trim <- function (x) gsub("^\\s+|\\s+$", "", x)

#'@export
Utils.removeWhitespace <- function (x) gsub("\\s+", "", x)

#'@export
Utils.dataframeToList <- function(df){
  rows <- apply(df, 1, function(x) (x) )
}
#' @export
Utils.doesExistInSchema <- function(needle, haystack)
{
  return(!(FALSE %in% (needle %in% haystack)))
}
Utils.getMultiValueField <- function(schema, filter=NULL)
{
  multi <- list()
  for(i in 1:nrow(schema))
  {
    row <- unlist(schema[i,c("fieldName","delimiter")])
    if(is.null(filter) || row[["fieldName"]] %in% filter)
    {
      if(!is.na((row[["delimiter"]])))
      {
        if(row[["delimiter"]] != "NA")
        {
          multi[[row[["fieldName"]]]] <- row[["delimiter"]]
        }
      }
    }
  }
  return(multi)
}
createAIErr <- function(code,message)
{
  errObj <- list(message=message,code=code)
  class <- c("AIErr","error", "condition")
  structure(errObj,
            class=class)
}
replaceTemplate <- function(template, tv=NULL)
{
  if(is.null(tv))
  {
    tv <- .AIEnv[[".TEMPLATE_VALUES"]]
  }
  for(i in names(tv)){
    template <- gsub(i,tv[[i]],template)
  }
  return(template)
}
AIError <- function(errObj, type=c("internal"),call=NULL)
{
  #type <- match.arg(type)
  class <- c(type,"error", "condition")
  structure(errObj,
            class=class)
}
Utils.isPercentage <- function(str){
  if(length(grep("%$",str))==0)
  {
    return(FALSE)
  }
  totalNum <- unlist(strsplit(str,"%"))
  if(length(totalNum) != 1)
  {
    return(FALSE)
  }
  if(!Utils.isNumber(totalNum[1]))
  {
    return(FALSE)
    
  }
  if(as.numeric(totalNum) > 100 || as.numeric(totalNum) <= 0)
  {
    return(FALSE)
  }
  return(TRUE)
  
}
Utils.isNumber <- function(str)
{
  if(suppressWarnings(is.na(as.numeric(str))))
  {
    return(FALSE)
    
  }
  else
  {
    return(TRUE)
  }
}
Utils.convertToDataFrame <- function(inputList=NULL) {
  if(is.null(inputList) || length(inputList) == 0)
  {
    return(data.frame())
  }
  dfs <- lapply(inputList, data.frame)
  combinedDF <- dfs[[1]]
  if(length(dfs) > 1){
    for(i in 1:(length(dfs)-1)){combinedDF <- Utils.combineDataFrame(combinedDF,dfs[[i+1]])}
  }
  return(combinedDF)
}
Utils.millisecondsToHumanFormat <- function(milliseconds){
  if(class(milliseconds) != "numeric")
  {
    stop("Milliseconds should be a number")
  }
  milliseconds <- as.integer(milliseconds)
  time <- as.POSIXlt(milliseconds, origin="1970-01-01",tz="UTC")
  return(format(time,'%A, %B %d, %Y %H:%M:%S'))
}
Utils.dfToHumanTime <- function(df, columnName){
  indexes <- grep("date ",unlist(as.list(df[columnName])))
  if(length(indexes) > 0)
  {
    for(i in indexes)
    {
      df[i,"min"] <- Utils.millisecondsToHumanFormat(as.numeric(df[i,"min"])/1000)
      df[i,"max"] <- Utils.millisecondsToHumanFormat(as.numeric(df[i,"max"])/1000)
    }
  }
  return(df)
}
Utils.combineDataFrame <- function(A,B) {
  a.names <- names(A)
  b.names <- names(B)
  all.names <- union(a.names,b.names)
  #print(paste("Number of columns:",length(all.names)))
  a.type <- NULL
  for (i in 1:ncol(A)) {
    a.type[i] <- typeof(A[,i])
  }
  b.type <- NULL
  for (i in 1:ncol(B)) {
    b.type[i] <- typeof(B[,i])
  }
  a_b.names <- names(A)[!names(A)%in%names(B)]
  b_a.names <- names(B)[!names(B)%in%names(A)]
  if (length(a_b.names)>0 | length(b_a.names)>0){
    #print("Columns in data frame A but not in data frame B:")
    #print(a_b.names)
    #print("Columns in data frame B but not in data frame A:")
    #print(b_a.names)
  } else if(length(a.names)==length(b.names)){
    A <- data.frame(lapply(A, as.character), stringsAsFactors=FALSE)
    B <- data.frame(lapply(B, as.character), stringsAsFactors=FALSE)
    C <- rbind(A,B)
    return(C)
  }
  C <- list()
  for(i in 1:length(all.names)) {
    l.a <- all.names[i]%in%a.names
    pos.a <- match(all.names[i],a.names)
    typ.a <- a.type[pos.a]
    l.b <- all.names[i]%in%b.names
    pos.b <- match(all.names[i],b.names)
    typ.b <- b.type[pos.b]
    if(l.a & l.b) {
      if(typ.a==typ.b) {
        vec <- c(as.character(A[,pos.a]),as.character(B[,pos.b]))
      } else {
        #warning(c("Type mismatch in variable named: ",all.names[i],"\n"))
        vec <- try(c(as.character(A[,pos.a]),as.character(B[,pos.b])))
      }
    } else if (l.a) {
      vec <- c(as.character(A[,pos.a]),as.character(rep(NA,nrow(B))))
    } else {
      vec <- c(as.character(rep(NA,nrow(A))),as.character(B[,pos.b]))
    }
    C[[i]] <- vec
  }
  names(C) <- all.names
  C <- data.frame(C,stringsAsFactors=FALSE)
  #C <- as.data.frame(C)
  return(C)
}
Utils.isDotSyntaxValid <- function(statement)
{
  ret = !grepl(".*(^\\.[^\\.]|[^\\.]\\.[^\\.]|[^\\.]\\.$|\\.\\.\\.+|\\.\\.$|^\\.\\.|^,|,$|,,+|,\\.|\\.,).*",statement)
  if(ret == TRUE)
  {
    splitByComma <- unlist(strsplit(x=statement,split=",",fixed=TRUE))
    for(str in splitByComma)
    {
      splitByDotDot <- unlist(strsplit(x=str,split="..",fixed=TRUE))
      if(length(splitByDotDot) != 1 && length(splitByDotDot) != 2)
      {
        ret <- FALSE
        break
      }
    }
  }
  return(ret)
}
Utils.getValuesGivenRange <- function(start, end, schemaFieldNames)
{
  s <- which(schemaFieldNames == start)
  e <- which(schemaFieldNames == end)
  if(length(s) == 0)
  {
    stop("Invalid Range : Cannot find ",start," in the schema ",paste(schemaFieldNames,sep=",",collapse=","))
  }
  if(length(e) == 0)
  {
    stop("Invalid Range : Cannot find ",end," in the schema ",paste(schemaFieldNames,sep=",",collapse=","))
  }
  if(s > e)
  {
    stop("Invalid Range : index of ",start,"(",s,")"," is greater than index of ",end,"(",e,") in the schema ",paste(schemaFieldNames,sep=",",collapse=","))
  }
  return(schemaFieldNames[s:e])
}
Utils.dotExpand <- function(statement, schemaFieldNames)
{
  result <- NULL
  isSyntaxValid <- Utils.isDotSyntaxValid(statement)
  if(!isSyntaxValid)
  {
    stop("Invalid Syntax in the statement : ",statement)
  }
  splitByComma <- unlist(strsplit(x=statement,split=",",fixed=TRUE))
  for(str in splitByComma)
  {
    splitByDotDot <- unlist(strsplit(x=str,split="..",fixed=TRUE))
    if(length(splitByDotDot) == 1)
    {   
      result <- c(result,Utils.getValuesGivenRange(splitByDotDot[1], splitByDotDot[1], schemaFieldNames))
    }   
    else
    {   
      result <- c(result,Utils.getValuesGivenRange(splitByDotDot[1], splitByDotDot[2], schemaFieldNames))
    }   
  }
  return(result)
}
Utils.expandDimensions <- function(dimensions, schema, prefix="")
{
  schema <- unlist(schema)
  statement <- paste(dimensions$.unexpandedDimensions,sep=",",collapse=",")
  if(nchar(statement) > 0)
  {
    expandedDimensions <- Utils.dotExpand(statement,schema)
    for(str in expandedDimensions)
    {
      if(prefix == "")
      {
        strn <- str
      }
      else
      {
        strn <- paste(prefix, "-", str, sep="", collapse="")
      }
      dimensions$addDimension(strn,str)
    }   
  }
}
Utils.getCatalogDatasetFromAIRP <- function(object)
{
  aDataset <- object$getDataset()$getName()
  aCatalog <- object$getDataset()$getCatalog()$getName()
  if(!Utils.isSet(aDataset))
  {
    aDataset <- object$getPartition()[[1]]$getDataset()$getName()
    aCatalog <- object$getPartition()[[1]]$getDataset()$getCatalog()$getName()
  }
  return(list(catalog=aCatalog,dataset=aDataset))
}
Utils.buildModelFromJson <- function(project, json, .skipI=TRUE)
{
  cs <- Utils.buildClickStreamFromJson(json$clickStream)
  config <- json$config
  desc <- json$description
  name <- json$name
  model <- Model$new(project=project, name=name, description=desc, .skipI=.skipI)
  if(!is.null(config))
  {
    model$setConfig(config)
  }
  if(Utils.isSet(json$id))
  {
    model$setId(json$id)
  }
  if(Utils.isSet(json$visibility))
  {
    model$.global$visibility <- json$visibility
  }
  model$setClickStream(cs)
  return(model)
}
Utils.buildScoreFromJson <- function(model, json, .skipI=TRUE)
{
  ca <- Utils.buildCombineActivityFromJson(json$combineActivity)
  config <- json$config
  tst <- config$targetScoreTime
  desc <- json$description
  name <- json$name
  score <- Score$new(model=model, name=name, description=desc, targetScoreTime=tst, .skipI=.skipI)
  if(!is.null(config))
  {
    score$setConfig(config)
  }
  if(Utils.isSet(json$id))
  {
    score$setId(json$id)
  }
  if(Utils.isSet(json$visibility))
  {
    score$.global$visibility <- json$visibility
  }
  if(Utils.isSet(json$scoreType))
  {
    score$.global$scoreType <- json$scoreType
  }
  score$setCombineActivity(ca)
  return(score)
}
Utils.buildReportFromJson <- function(score, json, .skipI=TRUE)
{
  o <- Utils.buildOfferFromJson(json$offer)
  config <- json$config
  desc <- json$description
  name <- json$name
  report <- Report$new(score=score, name=name, description=desc, .skipI=.skipI)
  if(!is.null(config))
  {
    report$setConfig(config)
  }
  if(Utils.isSet(json$id))
  {
    report$setId(json$id)
  }
  if(Utils.isSet(json$visibility))
  {
    report$.global$visibility <- json$visibility
  }
  report$setOffer(o)
  return(report)
}
Utils.buildCombinedReportFromJson <- function(score, json, .skipI=TRUE)
{
  o <- Utils.buildOfferFromJson(json$offer)
  config <- json$config
  desc <- json$description
  name <- json$name
  report <- CombinedReport$new(score, name=name, description=desc, .skipI=.skipI)
  if(!is.null(config))
  {
    report$setConfig(config)
  }
  if(Utils.isSet(json$id))
  {
    report$setId(json$id)
  }
  if(Utils.isSet(json$visibility))
  {
    report$.global$visibility <- json$visibility
  }
  report$setOffer(o)
  return(report)
}
Utils.buildClickStreamFromJson <- function(clickStream)
{
  offer <- Utils.buildOfferFromJson(clickStream$offer)
  combineActivity <- Utils.buildCombineActivityFromJson(clickStream$combineActivity)
  cs <- ClickStream$new()
  cs$setOffer(offer)
  cs$setCombineActivity(combineActivity)
  return(cs)
}
Utils.buildCombineActivityFromJson <- function(combineActivity)
{
  activity <- NULL
  profile <- NULL
  if(Utils.isSet(combineActivity$activity))
  {
    activity <- lapply(combineActivity$activity,function(x)
      {
        return(Utils.buildDSFromJson(x,"ACTIVITY"))
    })
  }
  if(Utils.isSet(combineActivity$profile))
  {
    profile <- lapply(combineActivity$profile,function(x)
    {
      return(Utils.buildDSFromJson(x,"PROFILE"))
    })
  }
  caObj <- CombineActivity$new()
  if(Utils.isSet(activity))
  {
    caObj$setActivity(activity)
  }
  if(Utils.isSet(profile))
  {
    caObj$setProfile(profile)
  }
  return(caObj)
}
Utils.buildOfferFromJson <- function(offer)
{
  config <- offer$config
  impression <- NULL
  response <- NULL
  if(Utils.isSet(offer$impression))
  {
    impression <- Utils.buildDSFromJson(offer$impression,"IMPRESSION")
  }
  if(Utils.isSet(offer$response))
  {
    response <- Utils.buildDSFromJson(offer$response,"RESPONSE")
  }
  offerObj <- Offer$new()
  if(Utils.isSet(config))
  {
    offerObj$setConfig(config)
  }
  if(Utils.isSet(impression))
  {
    offerObj$setImpression(impression)
  }
  if(Utils.isSet(response))
  {
    offerObj$setResponse(response)
  }
  return(offerObj)
}
Utils.buildDSFromJson <- function(obj, type)
{
  if(type == "IMPRESSION")
  {
    newObj <- Impression$new()
  }
  else if(type == "RESPONSE")
  {
    newObj <- Response$new()
  }
  else if(type == "ACTIVITY")
  {
    newObj <- Activity$new()
  }
  else if(type == "PROFILE")
  {
    newObj <- Profile$new()
  }
  if(!is.null(obj$datastore))
  {
    newObj$setDatastore(obj$datastore)
  }
  c <- Catalog$new()
  c$setName(obj$catalog)
  c$setDataManager(.AIEnv$.ApigeeInsights$getDataManager())
  ds <- c$getDataset(obj$dataset)
  
  #ds <- Dataset$new()
  #ds$setCatalog(c)
  #ds$setName(obj$dataset)
  setInfo(0)
  if(!is.null(obj$partitions))
  {
    partitions <- lapply(obj$partitions,
                         function(x)
                           {
                            p<- ds$getPartition(x, obj$datastore)
                           
                           
                           #p <- Partition$new()
                           #p$setDataset(ds)
                           #p$setName(x)
                           #if(!is.null(obj$datastore))
                           #p$setDatastore(obj$datastore)
                           return(p)
                         })
    setInfo(1)
    newObj$setPartition(partitions)
  }
  else
  {
    newObj$setDataset(ds)
  }
  if(!is.null(obj$config))
  {
    newObj$setConfig(obj$config)
  }
  return(newObj)
}
Utils.buildCatalogFromJson <- function(dm, json)
{
  name <- json$name
  description <- json$description
  catalog <- Catalog$new(.dm=dm,.name=name)
  if(Utils.isSet(description))
  {
    catalog$setDescription(description)
  }
  return(catalog)
}
Utils.buildDatasetFromJson <- function(catalog, json)
{
  name <- json$name
  dataset <- Dataset$new()
  dataset$setCatalog(catalog)
  dataset$setName(name)
  if(Utils.isSet(json$description))
  {
    dataset$setDescription(json$description)
  }
  if(Utils.isSet(json$dataType))
  {
    dataset$setDataType(json$dataType)
  }
  if(Utils.isSet(json$delimiter))
  {
    dataset$setDelimiter(Utils.delimiterMap(json$delimiter))
  }
  if(Utils.isSet(json$statistics))
  {
    dataset$setStatistics(json$statistics)
  }
  if(Utils.isSet(json$schema))
  {
    dataset$setSchema(json$schema)
  }
  return(dataset)
}
Utils.buildPartitionFromJson <- function(Dataset, json)
{
  name <- json$name
  Partition <- Partition$new()
  Partition$setDataset(Dataset)
  Partition$setName(name)
  if(Utils.isSet(json$datastore))
  {
    Partition$setDatastore(json$datastore)
  }
  if(Utils.isSet(json$description))
  {
    Partition$setDescription(json$description)
  }
  if(Utils.isSet(json$delimiter))
  {
    Partition$setDelimiter(Utils.delimiterMap(json$delimiter))
  }
  if(Utils.isSet(json$statistics))
  {
    Partition$setStatistics(json$statistics)
  }
  if(Utils.isSet(json$schema))
  {
    Partition$setSchema(json$schema)
  }
  return(Partition)
}
Utils.validateCharacter <- function(vector)
{
  if(missing(vector) || !is.character(vector))
  {
    return(1)
  }
  l <- sapply(vector,function(x){
    nchar(x) != 0
  }
  )
  if(FALSE %in% l)
  {
    return(2)
  }
  return(0)
}
Utils.is.sequential <- function(x){
  all(abs(diff(x)) == 1)
}
Utils.getStEtFromPartitions <- function(partitions)
{
  if(class(partitions)[[1]] == "Partitions")
  {
    partitions <- list(partitions)
  }
  d <- partitions[[1]]$getDataset()
  seq <- Utils.getFieldFromTag(d, "timestamp")
  final <- NULL
  for(p in partitions)
  {
    stEt <- tryCatch({
      stEt <- list()
      cStats <- p$getStatistics()$getColumnLevelStats()
      minMax <- cStats[cStats$columnName == seq,c("min","max")]
      stEt$min <- c(as.character(strptime(minMax$min,"%A, %B %d, %Y %H:%M:%S")-1))
      stEt$max <- c(as.character(strptime(minMax$max,"%A, %B %d, %Y %H:%M:%S")+1))
      stEt
    }, AIErr = function(x){
      stEt <- list()
      stEt$min <- NULL
      stEt$max <- NULL
      stEt
    })
    stEt$partition <- p
    final[[length(final)+1]] <- stEt
  }
  return(final)
}
Utils.getSt <- function(data)
{
  min <- NULL
  for(d in data)
  {
    min <- suppressWarnings(min(min,d$min))
  }
  if(min == Inf)
    min <- NULL
  return(min)
}
Utils.getEt <- function(data)
{
  max <- NULL
  for(d in data)
  {
    max <- suppressWarnings(max(max,d$max))
  }
  if(max == -Inf)
    max <- NULL
  return(max)
}
Utils.getPartitionsGivenStEt <- function(st=NULL,et=NULL,data)
{
  
  if(is.null(st))
  {
    st <- "0000-00-00 00:00:00"
  }
  if(is.null(et))
  {
    et <- "9999-00-00 00:00:00"
  }
  final <- list()
  for(d in data)
  {
    if(!is.null(d$max))
    {
      if(((d$min <= et)  &&  (d$max >= st)))
      {
        final[[length(final)+1]] <- d$partition
      }
    }
    else
    {
      final[[length(final)+1]] <- d$partition
    }
  }
  return(final)
}
Utils.getFieldFromTag <- function(d, tag)
{
  dfSchema <- data.frame(do.call("rbind",d$getSchema()))
  fNames <- unlist(dfSchema$fieldName[grep(tag,dfSchema$fieldTag)])
  return(fNames)
}
Utils.partitionsWithoutStats<- function(data)
{
  partitionsWithoutStats <- NULL
  for(d in data)
  {
    if(is.null(d$max))
    {
      partitionsWithoutStats <- c(partitionsWithoutStats, d$partition$getName())
    }
  }
  return(partitionsWithoutStats)
}
Utils.delimiterMap <- function(delimiter)
{
  delimList <- unlist(strsplit(delimiter,"\\|"))
  convertedDelim <- lapply(delimList,function(x){
    switch(x,
           "controlA" = "\01",
           "controlB" = "\02",
           "controlC" = "\03",
           "controlD" = "\04",
           "CTRL-A" = "\01",
           "CTRL-B" = "\02",
           "CTRL-C" = "\03",
           "CTRL-D" = "\04",
           "COMMA" = ",",
           "comma" = ",",
           "space" = " ",
           "tab" = "\t",
           "TAB" = "\t",
           x) }
  )
  return(paste(convertedDelim,collapse="|"))
}
Utils.buildCombinedScoreFromJson <- function(project, json, .skipI=TRUE)
{
  config <- json$config
  desc <- json$description
  name <- json$name
  algo <- json$algo
  cs <- CombinedScore$new(project=project, name=name, description=desc, .skipI=.skipI)
  if(!is.null(config))
  {
    cs$setConfig(config)
  }
  if(Utils.isSet(json$id))
  {
    cs$setId(json$id)
  }
  if(Utils.isSet(json$algo))
  {
    cs$setAlgo(json$algo)
  }
  if(Utils.isSet(json$visibility))
  {
    cs$.global$visibility <- json$visibility
  }
  cs$.scores <- json$scores
  return(cs)
}