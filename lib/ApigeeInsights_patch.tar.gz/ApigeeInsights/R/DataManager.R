#Copyright 2014 Apigee Corporation
DataManager$methods(
  setAccount = function(account){
    signatures <- c("ApigeeInsights")
    if(!Utils.validateSignature(account,signatures))
    {
      stop("Invalid signature : account should be of type ", paste(signatures,collapse=" or "))
    }
    .account <<- account
  },
  getAccount = function(){return(.account)},
  generateEndPoint = function(id="",resource=NULL) {
    id <- curlEscape(id)
    if(is.null(resource))
    {
      resource <- "catalogs"
    }
    host <- Utils.trim(getAccount()$getHost())
    if(id != "") 
    {   
      id <- paste("/",id,sep="")
    }   
    return(paste(host,"/datamanagement/",resource,id,sep=""))
  },
  getDatasetList = function(catalog = NULL){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    catalog <- getCatalog(catalog)
    return(catalog$getDatasetList())
  },
  getDataset = function(catalog=NULL, dataset){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    catalog <- getCatalog(catalog)
    return(catalog$getDataset(dataset))
  },
  getPartitionList = function(catalog=NULL, dataset){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    catalog <- getCatalog(catalog)
    dataset <- catalog$getDataset(dataset)
    return(dataset$getPartitionList())
  },
  getPartition = function(catalog=NULL, dataset, partition, datastore=NULL){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","NULL"),
                       datastore=c("character","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    catalog <- getCatalog(catalog)
    dataset <- catalog$getDataset(dataset)
    return(dataset$getPartition(partition, datastore))
  },
  getPartitions = function(catalog=NULL, dataset, partition, datastore=NULL){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","NULL"),
                       datastore=c("character","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    catalog <- getCatalog(catalog)
    dataset <- catalog$getDataset(dataset)
    return(dataset$getPartitions(partition, datastore))
  },
  getCatalogList = function(){
    url <- generateEndPoint()
    params = list(accountId=getAccount()$getId(),token=getAccount()$getToken(),entityIdType="name")
    tryCatch({
      Utils.info("Fetching catalog list...")
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })  
    Utils.info("Fetching successful")
    lc <- data.frame(do.call("rbind",data$catalogs))
    return(lc)
  },
  getCatalog = function(name=NULL){
    params <- c(as.list(environment()))
    globalSignatures <- c("character","missing","NULL")
    Utils.signatureValidation(params, globalSignatures=globalSignatures)
    if(is.null(name))
    {
      if(!exists(".AIEnv") || is.null(.AIEnv$.catalog))
      {
        stop("catalog should be either passed as a parameter or set globally using setCatalog method")
      }
      name <- .AIEnv$.catalog
    }
    url <- generateEndPoint(name)
    params = list(accountId=getAccount()$getId(),token=getAccount()$getToken(),entityIdType="name")
    tryCatch({
      Utils.info(paste("Fetching catalog - ",name,"...",sep="",collapse=""))
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {
        stop(x)
      }
      template <- paste(MESSAGES$ENTITY$CATALOG,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<CATALOG>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })
    #Utils.debug("getCatalogs",data)
    catalog <- Utils.buildCatalogFromJson(.self,data$catalog)
    Utils.info("Fetching successful")
    return(catalog)
  },
  getDatastoreList = function()
  {
    url <- generateEndPoint(resource="datastores")
    params = list(accountId=getAccount()$getId(),token=getAccount()$getToken(),entityIdType="name")
    tryCatch({
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })  
    data$datastores <- lapply(data$datastores, function(x)
    {   
      if(is.null(x$default))
      {   
        x$default <- FALSE
      }   
      return(x)
    }   
    )
    lds <- data.frame(do.call("rbind",data$datastores))
    return(lds)
  },
  getDefaultDatastore = function()
  {
    dsl <- getDatastoreList()
    if(nrow(dsl) == 0)
    {
      stop("Datastores not defined for the account")
    }
    ds <- unlist(subset(dsl, default == TRUE)[,"name"])
    if(is.null(ds))
    {
      stop("No persistent datastore available")
    }
    return(ds)
    
  }
  
)
