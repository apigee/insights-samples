#Copyright 2014 Apigee Corporation
library(utils)
#.IOEnv <- new.env()
.onLoad <- function(libname, pkgname){
  library(bitops)
  library(RJSONIO)
  library(RCurl)
  library(pander)
  library(utils)
  vrs <- packageDescription(pkgname, lib.loc = libname, fields = "Version",
                            drop = TRUE)
  packageStartupMessage("\nWelcome to the\nApigee Modeling Workbench!!")
  createEnv()
  # assign(".InsightsOne",NA, envir=.IOEnv)
  #  assign(".Project", NA, envir=.IOEnv)
  
}
