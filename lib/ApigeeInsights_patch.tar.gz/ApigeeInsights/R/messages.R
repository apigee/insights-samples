#Copyright 2014 Apigee Corporation
MESSAGES <- list(
  ENTITY=list(
    CATALOG="Catalog '<CATALOG>' :",
    DATASET="Dataset '<DATASET>' :",
    PARTITION="Partition '<PARTITION>' :",
    PROJECT="Project '<PROJECT>' :",
    MODEL="Model '<MODEL>' :",
    SCORE="Score '<SCORE>' :",
    COMBINED_SCORE="Score '<COMBINED_SCORE>' :",
    COMBINED_REPORT="Report '<COMBINED_REPORT>' :",
    REPORT="Report '<REPORT>' :",
    TRANSFORMATION="Transformation '<TRANSFORMATION>' :",
    PHRASE_BUILDER="PhraseBuilder '<PHRASE_BUILDER>' :",
    PHRASE_EXTRACTOR="PhraseExtractor '<PHRASE_EXTRACTOR>' :"
  ),
  NOT_FOUND="not available",
  DUPLICATE="duplicate entity",
  LOAD_FAILED="loading failed",
  NOT_CREATED="cannot created",
  NOT_UPDATED="cannot updated",
  NOT_DELETED="cannot deleted",
  NOT_ELIGIBLE_FOR_UPDATE="not eligible for update",
  NOT_UPDATE_EXECUTE="cannot be updated/executed. Already executed.",
  NOT_EXECUTED="not executed",
  USER_AUTHENTICATION_FAILED="User authentication failed for account <ACCOUNT> and user <USER>",
  ACCOUNT_NOT_FOUND="Account <ACCOUNT> not found",
  TOKEN_AUTHENTICATION_FAILED="Token autherization failed for account <ACCOUNT> and user <USER>",
  TOKEN_EXPIRED="Token expired for account <ACCOUNT> and user <USER>",
  ACCOUNT_AUTHENTICATION_FAILED="Account authentication failed for account <ACCOUNT> and user <USER>"
)


CODE_MSG_MAP <- list(
  "21"="NOT_FOUND",
  "22"="DUPLICATE",
  "23"="LOAD_FAILED",
  "26"="NOT_CREATED",
  "27"="NOT_UPDATED",
  "28"="NOT_DELETED",
  "29"="NOT_ELIGIBLE_FOR_UPDATE",
  "30"="NOT_UPDATE_EXECUTE",
  "11"="USER_AUTHENTICATION_FAILED",
  "12"="ACCOUNT_NOT_FOUND",
  "13"="TOKEN_AUTHENTICATION_FAILED",
  "14"="TOKEN_EXPIRED",
  "15"="ACCOUNT_AUTHENTICATION_FAILED"
  )
