#Copyright 2014 Apigee Corporation
BaseStatistics$methods(
  setDatastore = function(datastore){
    signatures <- c("character")
    if(!Utils.validateSignature(datastore,signatures))
    {
      stop("Invalid signature : datastore should be of type ", paste(signatures,collapse=" or "))
    }
    .datastore <<- datastore
  },
  getDatastore = function(){return(.datastore)},
  setDataset = function(dataset){
    signatures <- c("Dataset")
    if(!Utils.validateSignature(dataset,signatures))
    {
      stop("Invalid signature : dataset should be of type ", paste(signatures,collapse=" or "))
    }
    .dataset <<- dataset
  },
  getDataset = function(){return(.dataset)},
  setPartition = function(partition){
    signatures <- c("Partition")
    if(!Utils.validateSignature(partition,signatures))
    {
      stop("Invalid signature : partition should be of type ", paste(signatures,collapse=" or "))
    }
    .partition <<- partition
  },
  getPartition = function(){return(.partition)},
  setOverAllStats = function(overAllStats){
    signatures <- c("data.frame","list")
    if(!Utils.validateSignature(overAllStats,signatures))
    {
      stop("Invalid signature : overAllStats should be of type ", paste(signatures,collapse=" or "))
    }
    if(Utils.checkClass(overAllStats,"list"))
    {
      overAllStats <- data.frame(overAllStats)
    }
    .overAllStats <<- overAllStats
  },
  getOverAllStats = function(){return(.overAllStats)},
  setColumnLevelStats = function(columnLevelStats){
    signatures <- c("data.frame","list")
    if(!Utils.validateSignature(columnLevelStats,signatures))
    {
      stop("Invalid signature : columnLevelStats should be of type ", paste(signatures,collapse=" or "))
    }
    if(Utils.checkClass(columnLevelStats,"list"))
    {
      columnLevelStats <- Utils.convertToDataFrame(columnLevelStats)
      columnLevelStats <- Utils.dfToHumanTime(columnLevelStats,"columnType")
    }
    .columnLevelStats <<- columnLevelStats
  },
  getColumnLevelStats = function(){return(.columnLevelStats)},
  show = function()
  {
    if(Utils.isSet(getPartition()$getName())){
      cat("Datastore: ",getPartition()$getDatastore(),"\n")
      cat("Catalog: ",getPartition()$getDataset()$getCatalog()$getName(),"\n")
      cat("Dataset: ",getPartition()$getDataset()$getName(),"\n")
      cat("Partition: ",getPartition()$getName(),"\n")
    }
    else
    {
      if(Utils.isSet(getDatastore()))
        cat("Datastore: ",getDatastore(),"\n")
      cat("Catalog: ",getDataset()$getCatalog()$getName(),"\n")
      cat("Dataset: ",getDataset()$getName(),"\n")
    }
    showStats()
  },
  showStats = function()
  {
    if(length(getOverAllStats()) == 0)
    {   
      cat("Stats not available\n")
    }   
    else
    {   
      cat("\nOverAll Statistics:")
      pandoc.table(getOverAllStats(),split.cells=50, split.table=1220,style="grid")
      cat("\nColumnLevel Statistics:")
      pandoc.table(getColumnLevelStats(), split.cells=50, split.table=1220,style="grid")
    } 
  }
)
