con <- connect(org="burberry_test",user="insights_admin@apigee.com",password="Apigee2010",host="https://burberry-insights.apigee.com/api/")
acc <- connect(org="burberry_test",user="insights_admin@apigee.com",password="Apigee2010",host="https://burberry-insights.apigee.com/api/")

pp <- con$getProject("Periodic3nnTest")
pp$getModelList()
mm <- pp$getModel("3nn_20151005193733")
mm$getScoreList()
ss <- mm$getScore("PS_20151005200933")
ss$getReportList()
rr <- ss$getReport("InternalValidation")
rr$plot(type = "GAIN", predictionDimensionValue = "W_PRS_RAINWEAR")

pp <- con$getProject("Periodic2nnTest")
pp$getModelList()
mm <- pp$getModel("2nn_20151006153502")
mm$getScoreList()
ss <- mm$getScore("PS_20151006154402")
ss$getReportList()
rr <- ss$getReport("InternalValidation")
rr$plot(type = "GAIN", predictionDimensionValue = "W_PRS_RAINWEAR")


pp <- con$getProject("Production1_Model1")
pp$getModelList()
mm <- pp$getModel("M1_20151006235918")
mm$getScoreList()
ss <- mm$getScore("S_20151007140003")
ss$getReportList()
rr <- ss$getReport("InternalValidation")
rr$plot(type = "AUC", predictionDimensionValue = "CHILDRENS")

pp <- con$getProject("Production1_Model3")
pp$getModelList()
mm <- pp$getModel("M3_20151006235918")
mm$getScoreList()
ss <- mm$getScore("S_20151010140002")
ss$getReportList()
rr3 <- ss$getReport("new_report_test")
rr <- Report$new(ss,name="RepTest")
rr$setResponseEvent(catalog = "ProductionCatalog1", dataset = "apigee_transactions_net", latest = T, startTime = "2015-10-11 00:00:01", endTime = "2015-11-04 00:0:01")
rr$execute()

rr3new = rr3$cloneObject(name = "new_report_test")
rr3new$execute()

pp <- con$getProject("Production1_Model2")
pp$getModelList()
mm <- pp$getModel("M2_20151006235918")
mm$getScoreList()
ss <- mm$getScore("S_20151010140002")
ss$getReportList()
rr2 <- ss$getReport("M2_RepTest")
rr <- Report$new(ss,name="M2_RepTest")
rr$setResponseEvent(catalog = "ProductionCatalog1", dataset = "apigee_transactions_net", latest = T, startTime = "2015-10-11 00:00:01", endTime = "2015-11-04 00:0:01")
rr$execute()


pp <- con$getProject("Production1_Model1")
pp$getModelList()
mm <- pp$getModel("M1_20151006235918")
mm$getScoreList()
ss <- mm$getScore("S_20151010140002")
ss$getReportList()
rr1 <- ss$getReport("M1_RepTest")
ss$getReportList()
rr1 <- Report$new(ss,name="M1_RepTest3")
rr1$setResponseEvent(catalog = "ProductionCatalog1", predictionDimensions = "product_group",dataset = "apigee_transactions_net", latest = T, startTime = "2015-10-11 00:00:01", endTime = "2015-11-04 00:0:01")
rr1$execute()

3684
2523 + 737 + 99

rr <- ss$getReport("RepTest")
rr$plot(type = "AUC", predictionDimensionValue = "CHILDRENS")


pp <- con$getProject("Production1_All")
pp$getCombinedScoreList()
cs <- pp$getCombinedScore("CS_20151010140002")
cs <- cs$cloneObject("CS_Single")
cs$setConfiguration("numReducers", "128")
cs$execute()
cr <- CombinedReport$new(cs,name="CR_test3")
cr$setResponseEvent(catalog = "ProductionCatalog1", dataset = "apigee_transactions_net", predictionDimensions = "product_group", latest = T, startTime = "2015-10-11 00:00:01", endTime = "2015-11-02 00:0:01")
#cr$setConfiguration("numReducers", "128")
cr$execute()


festive <- con$getProject("Festive2015_131015")$getModel("FestiveCloneModel")

status <- rr$getStatus()
time <- Sys.time()
op <- toJSON(rr$toJsonStructure(),pretty = T)
op <- paste(capture.output(show(festive)),collapse = "\n")
prepareEmail <- function(obj)
{
  bobject<-obj$getName()
  bstatus <- obj$getStatus()
  if(class(obj)[[1]] == "Report")
  {
    bscore <- obj$getScore()$getName()
    bmodel<-obj$getScore()$getModel()$getName()
    bproject <- obj$getScore()$getModel()$getProject()$getName()
    bacc <- obj$getScore()$getModel()$getProject()$getAccount()$.account
    bstatus <- obj$getStatus()
    body <- paste("Status - ",bstatus,"\n","Report Name - ", bobject,"\n","Score Name - ",bscore, "\n", "Model Name - ", bmodel, "\n", "Project Name - ",bproject,"\n","Account Name - ",bacc ,"\n",op)
  }
  else if(class(rr)[[1]] == "Score")
  {
    bmodel<-objgetModel()$getName()
    bproject <- obj$getModel()$getProject()$getName()
    bacc <- obj$getModel()$getProject()$getAccount()$.account
    bstatus <- obj$getStatus()
    body <- paste("Status - ",bstatus,"\n","Score Name - ",bobj, "\n", "Model Name - ", bmodel, "\n", "Project Name - ",bproject,"\n","Account Name - ",bacc ,"\n",op)
  }
  else if(class(rr)[[1]] == "Model")
  {
    
    bproject <- obj$getProject()$getName()
    bacc <- obj$getProject()$getAccount()$.account
    body <- paste("Status - ",bstatus,"\n", "Model Name - ", bobj, "\n", "Project Name - ",bproject,"\n","Account Name - ",bacc ,"\n",op)
  }
  else if(class(rr)[[1]] == "CombinedScore")
  {
    
    bproject <- obj$getProject()$getName()
    bacc <- obj$getProject()$getAccount()$.account
    body <- paste("Status - ",bstatus,"\n", "CombinedScore Name - ", bobj, "\n", "Project Name - ",bproject,"\n","Account Name - ",bacc ,"\n",op)
  }
  else
  {
    body <- paste("Status - ",bstatus,"\n", "Object Name - ", bobj, "\n", "Object Type - ",class(rr)[[1]])
  }
  subject <- paste("Burberry Alert - ",Sys.time(),"; ",bobject," - ", bstatus)
  ret <- list(body=body, subject=subject, status=status)
}

to <- paste("amalavalli@apigee.com",sep = ",")
retval <- prepareEmail(rr) 
wait <- 1
obj <- rr
while(wait)
{
  status <- obj$getStatus()
  retval <- prepareEmail(obj)
  if(status != "Completed" && status != "Failed")
  {
    cmd <- paste("curl -s --user 'api:key-032425107025c2d268a7f848bf6ba143' https://api.mailgun.net/v3/sandbox0e831f7bfaa44520bfa9fa4a95933330.mailgun.org/messages -F from='Akhilesh <mailgun@sandbox0e831f7bfaa44520bfa9fa4a95933330.mailgun.org>' -F to=",to," -F subject='",retval$subject,"' -F text='" ,retval$body, "' ",sep="")
    system(cmd)
    wait <- 0
  }
  else
  {
    Sys.sleep(5000)
  }
}

newr <- rr$cloneObject("newr")
newr$execute()


p <- acc$getProject("Production1_Model1")
m <- p$getModel("M1_20151006235918")
s <- m$getScore("S_20151007140003")
r <- s$getReport("R_20151007170002")
r$plot()
