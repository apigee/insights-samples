library(ApigeeInsights)

myID <- "v21"
censusProjectName <- paste("censusProject", myID, sep="-")
censusModelName <- paste("censusModel", myID, sep="-")
censusScoreName <- paste("censusScore", myID, sep="-")
censusReportName <- paste("censusReport", myID, sep="-")

model <- Model$new(project=censusProjectName, name=censusModelName)
model$setProfile(catalog="profileOnly",dataset="census",dimensions=c("age","workclass","edunum","mstatus",
                                                                     "occupation","relationship","race","sex","capgain",
                                                                     "caploss","hoursweek","ncountry","continent"),dimCombn = 2, 
                 responseDimension="labelHighIncome", filterColumn = "sex",filterValues = c("Female","Male"))
model$setTrainingPercent(80)
model$execute()
model$getStatus()



score <- Score$new(model, name=censusScoreName, 
                   description="Output score from applying the model to the scoring dataset")
score$setScoreType(value="propensity")
score$execute()
score$getStatus()

report <- Report$new(score=score, name=censusReportName)
report$execute()

cModel <- acc$getProject("censusProject-v20")$getModel("censusModel-v20")
cScore <- cModel$getScore("censusScore-v20")
cReport <- cScore$getReport("censusReport-v20")

cReport$plot(type = "AUC",predictionDimensionValue = "1")

#################################################### Combine Score #####################################################
m1 <- acc$getProject("censusProject-v11")$getModel("censusModel-v11")
s1 <- m1$getScore("censusScore-v11")

m2 <- acc$getProject("censusProject-v12")$getModel("censusModel-v12")
s2 <- m2$getScore("censusScore-v12")


cs <- CombinedScore$new(project="testProject",name="cs-v2")
cs$setAlgo("COMBINE_WEIGHTED_LINEAR")
cs$addScore(s1,0.6)
cs$addScore(s2,0.4)
cs$execute()

combinedScore <- acc$getProject("combinedScoreProject")$getCombinedScore("combinedScore-v11-12")

