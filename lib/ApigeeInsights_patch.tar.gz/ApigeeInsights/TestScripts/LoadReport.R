#Remove hash symbol from the first line of the report
library(ApigeeInsights)
acc <- connect(org="qauser",user="qauser",password="Test12345",host="http://10.224.16.104:8080/api")
mm1 <- acc$getProject("RecommendationsTutorial")$getModel("RecommendationsModel")
ss1 <- mm1$getScore("RecommendationsModelScore")
rr1 <- ss1$getReport("RecommendationsModelAccuracyReport")
ddf <- read.csv("~/Downloads/combinedreport.csv",header = T,sep="\t")
nn1 <- names(ddf[,1:4])
nn2 <- names(ddf[,c("active_users","responders")])
ddf1 <- ddf[,c(nn1,nn2)]
rr1$.global$fullReport <- ddf1
rr1$plot(predictionDimensionValue = "CHILDRENS", type="AUC")

rddf <- ddf1[ddf1$node %in% c("CHILDRENS"),]
im <- "active_users"
rm <- "responders"
cols <- paste("\\b",im,"\\b|\\b",rm,"\\b",sep="",collapse="")
part_rdf <- rddf[,grep(cols,names(rddf))]
pxx <- as.numeric(rddf[,im])
cpxx <- cumsum(pxx)

oldReport <- rScore$getReport("RecommendationsModelAccuracyReport")
oldReport$plot(type = "AUC",predictionDimensionValue = "10632300")
