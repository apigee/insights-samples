# This script simply retrieves information from an existing score and report
# on the Insights server, printing the information in table and chart formats.

# Load the Insights R package.
library(ApigeeInsights)


account <- connect(org = "qauser", user="qauser",password="Test12345", host="https://insights.apigee.net/api")
account <- connect(org = "amalavalli2", user="amalavalli2",password="Aaaa1234", host="http://10.123.123.103:8080/api")

# Declare which report and score to get information about.
cModel <- getProject(name = "RecommendationsTutorial")$getModel(name = "RecommendationsModel")
cScore <- cModel$getScore(name = "RecommendationsModelScore")
cReport <- cScore$getReport(name = "RecommendationsModelAccuracyReport")
rep <- cReport$cloneObject(name = "tr")
rep$execute()

nModel <- cModel$cloneObject(name = "TestModelv14")
nModel$execute()

# Print out the score and report objects in tabular form. These lines print 
# (to the console) what the top 10 items in the score and report actually 
# contain.
print(cModel$stream(10))
print(cScore$stream(10))
print(cReport$stream(10))

## Plot the report data in charts.

# Plot the gain, lift, and AUC charts.
cReport$plot("good",type="AUC")
cReport$plot("SkipHopZooBackpack", type="GAIN")
cReport$plot("SkipHopZooBackpack", type="LIFT")
cReport$plot("SkipHopZooBackpack", type="AUC")












dimCombn <- 3
dimensions <- c("aa","bb","cc")
if(dimCombn > 1 && (typeof(dimensions) == "character" || typeof(dimensions) == "list"))
{
  flatDimensions <- unique(unlist(dimensions))
  newDims <- as.list(flatDimensions)
  if(dimCombn > length(flatDimensions))
  {
    stop("dimCombn cannot be greater than the number of unique dimensions. By default dimCombn is set to 2.")
  }
  if(dimCombn > 1)
  {
    for(i in 2:dimCombn)
    {
      combi <- combn(flatDimensions, i)
      for(col in 1:ncol(combi)) {
        for(row in 1:nrow(combi))
          a <- combi[, col]
        newDims[[length(newDims) + 1]] <- a
      }
    }
  }
  dimensions <- newDims
}
show(dimensions)




write(format(Sys.time(), "%Y-%m-%d"), "~/test.txt")
aa <- scan("~/test.txt",what = "character")
aa == format(Sys.time(), "%Y-%m-%d")

