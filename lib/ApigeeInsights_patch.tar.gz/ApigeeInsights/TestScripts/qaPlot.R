# This script simply retrieves information from an existing score and report
# on the Insights server, printing the information in table and chart formats.

# Load the Insights R package.
library(ApigeeInsights)


account <- connect(org = "qauser", user="qauser",password="Test12345", host="http://10.224.16.104:8080/api")

# Declare which report and score to get information about.
cModel <- getProject(name = "RecommendationsTutorial")$getModel(name = "RecommendationsModel")
cScore <- cModel$getScore(name = "RecommendationsModelScore")
cReport <- cScore$getReport(name = "RecommendationsModelAccuracyReport")
rep <- cReport$cloneObject(name = "tr")
rep$execute()

nModel <- cModel$cloneObject(name = "TestModelv14")
nModel$execute()

# Print out the score and report objects in tabular form. These lines print 
# (to the console) what the top 10 items in the score and report actually 
# contain.
print(cModel$stream(10))
print(cScore$stream(10))
print(cReport$stream(10))

## Plot the report data in charts.

# Plot the gain, lift, and AUC charts.
cReport$plot("good",type="AUC")
cReport$plot("SkipHopZooBackpack", type="GAIN")
cReport$plot("SkipHopZooBackpack", type="LIFT")
cReport$plot("SkipHopZooBackpack", type="AUC")