library(ApigeeInsights)
acc <- connect(org="qauser",user="qauser",password="Test12345",host="http://10.224.16.104:8080/api")
myID <- "v104"
projectName <- paste("akhiProject", myID, sep="-")
setCatalog("cars_data")
modelName <- paste("akhiModelCars", myID, sep="-")
model <- Model$new(project=projectName, name=modelName, 
                   description="Cars model")
model$setProfile(dataset="cars",dimensions=c("maint","buying","doors","persons","lugboot","safety"), responseDimension="resp")
model$store()
model$setTrainingPercent(split = 50)
model$execute()
model$getStatus()


scoreName <- paste("akhiScoreCars", myID, sep="-")
score <- Score$new(model, name=scoreName, 
                   description="Output score from applying the model to the scoring dataset", 
                   targetScoreTime="1971-01-03")

score <- Score$new(model, name=scoreName, 
                   description="Output score from applying the model to the scoring dataset")

score$execute()
score$getStatus()

reportName <- paste("akhiReportCar", myID, sep="-")
report <- Report$new(score=score, name=reportName)
#report$setResponseEvent(dataset="Purchase")

# Execute the reporting process on the server.
report$execute()
report$getStatus()


##### Step 7: Get the accuracy report and plot it into a chart.

# Plot the gain, lift, and AUC charts.
report$plot("SkipHopZooBackpack", type="GAIN")
report$plot("SkipHopZooBackpack", type="LIFT")
report$plot("SkipHopZooBackpack", type="AUC")


plotType <- c("AUC","GAIN","LIFT")
predDimValues <- c("unacc","acc","good","vgood")
predDimValues <- c("1","0")
for(pt in plotType)
{
  for(pd in predDimValues)
  {
    fName <- paste("~/census_80_20_",pt,"_",pd,".png",sep="")
    png(fName, width=4, height=4, units="in", res=300)
    par(mar=c(4,4,1,1))
    report$plot(type = pt, predictionDimensionValue = pd)
    dev.off()
  }
}

model <- acc$getProject("akhiProject-v1")$getModel("akhiModelCars-v1")
score <- model$getScore("akhiScoreCars-v1")
report <- score$getReport("akhiReportCar-v1")

nModel <-  model$cloneObject(name = "profileModel-v2",description = "Test")
nModel$setTrainingPercent(60,isRandom = T)
nModel$execute()
nScore <- Score$new(nModel, name="profileScore-v1")
nScore$execute()

nReport <- Report$new(score=nScore, name="profileReport-v1")
nReport$execute()

rModel <- acc$getProject("RecommendationsTutorial")$getModel("RecommendationsModel")
rScore <- rModel$getScore("RecommendationsModelScore")
rReport <- rScore$getReport("RecommendationsModelAccuracyReport")

model1 <- acc$getProject("RecommendationsTutorial")$getModel("RecCloneModel-v1")
score1 <- model1$getScore("RecCloneScore-v1")
report1 <- score1$getReport("RecCloneReport-v1")

model2 <- acc$getProject("joyDataProject")$getModel("joyDataModel-v1")
score2 <- model2$getScore("joyDataScore-v1")
report2 <- score2$getReport("joyDataReport-v1")
model2$cloneObject("jdm")$execute()
score2$cloneObject("jds")$execute()
report2$cloneObject("jdr")$execute()


nrModel <- rModel$cloneObject(name = "RecCloneModel-v1",description = "Test")
nrModel$execute()

nrScore <- Score$new(nrModel, name="RecCloneScore-v1",targetScoreTime="2013-08-20")
nrScore$execute()

nrReport <- Report$new(nrScore, name="RecCloneReport-v1")
nrReport$execute()








model <- Model$new(project="joyDataProject", name="joyDataModel-v1")
model$setProfile(catalog="joy_catalog",dataset="d1",dimensions=c("age","workclass","edunum","mstatus",
                                                                 "occupation","relationship","race","sex","capgain",
                                                                 "caploss","hoursweek","ncountry","continent"), 
                                                              responseDimension="labelHighIncome")
model$setTrainingPercent(80)
model$execute()
model$getStatus()


score <- Score$new(model, name="joyDataScore-v1", 
                   description="Output score from applying the model to the scoring dataset")

score$execute()
score$getStatus()

report <- Report$new(score=score, name="joyDataReport-v1")
report$execute()



cs <- CombinedScore$new(project="testProject",name="ccs-v4")
cs$setAlgo("COMBINE_WEIGHTED_LINEAR_EQUAL")
cs$addScore(rScore,0.6)
cs$addScore(rScore,0.9)
cs$setConfiguration("numReducers",32)
cat(toJSON(cs$toJsonStructure(),pretty = T))
cs$store()
cs$execute()
cs$getStatus()

cr <- CombinedReport$new(csname="ccr-v3")
cs$store()
cs$execute()
cs$getStatus()



aaa <- acc$getProject("testProject")$getCombinedScore("dadsadasd2")
bbb <- aaa$cloneObject(("pickupdataCS1"))
bbb$execute()


#Remove hash symbol from the first line of the report
library(ApigeeInsights)
acc <- connect(org="qauser",user="qauser",password="Test12345",host="http://10.224.16.104:8080/api")
rModel <- acc$getProject("RecommendationsTutorial")$getModel("RecommendationsModel")
rScore <- rModel$getScore("RecommendationsModelScore")
rReport <- rScore$getReport("RecommendationsModelAccuracyReport")
ddf <- read.csv("~/laprep.txt",header = T,sep="\t")
nn1 <- names(ddf[,1:4])
nn2 <- names(ddf[,c("active_users","responders")])
ddf1 <- ddf[,c(nn1,nn2)]
rReport$.global$fullReport <- ddf1
rReport$plotLift


