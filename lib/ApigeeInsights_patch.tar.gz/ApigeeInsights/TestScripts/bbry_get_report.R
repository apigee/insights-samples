library(ApigeeInsights)
repObjs <- NULL
acc <- connect(org="burberry_test",user="insights_admin@apigee.com",password="Apigee2010",host="https://burberry-insights.apigee.com/api/")
con <- connect(org="burberry_test",user="insights_admin@apigee.com",password="Apigee2010",host="https://burberry-insights.apigee.com/api/")
p <- acc$getProject("Production1_Model3")
m <- p$getModel("M3_20151101173001")
s <- m$getScore("S_20151118140002")
r <- s$getReport("R_20151118170002")

m <- p$getModel("M3_20151006235918")
s <- m$getScore("S_20151007140003")
r <- s$getReport("R_20151007170002")
r$plot(predictionDimensionValue = "MISC")
repObjs <- c(repObjs,r)

p <- acc$getProject("Production1_Model2")
m <- p$getModel("M2_20151006235918")
s <- m$getScore("S_20151007140003")
r <- s$getReport("R_20151007170002")
repObjs <- c(repObjs,r)

p <- acc$getProject("Production1_Model1")
m <- p$getModel("M1_20151006235918")
s <- m$getScore("S_20151007140003")
r <- s$getReport("R_20151007170002")
repObjs <- c(repObjs,r)


p <- acc$getProject("Production1_Model2")
m <- p$getModel("M2_20151006235918")
s <- m$getScore("S_20151009140002")
r <- s$getReport("R_20151009170002")
repObjs <- c(repObjs,r)

p <- acc$getProject("Production2_Model2")
p$getModelList()
m <- p$getModel("M2_20151201173002")
s <- m$getScore("S_20151202140002")
r <- s$getReport("InternalValidationPropensity")

s <- m$getScore("LS_20151202140002")
r <- s$getReport("InternalValidationLift")

#r$plot()
#ss <- r$getReportStatsAllDimensions()
#ss1 <- r$getReportStatsAllDimensions()


nba <- read.csv("http://datasets.flowingdata.com/ppg2008.csv", sep=",")
nba <- read.csv("~/aucs.csv", sep=",",header = T)
row.names(nba) <- nba$Date
nba <- nba[,2:ncol(nba)]
nba <- data.frame()
aa <- suppressWarnings(tryCatch({read.csv("~/aucs.csv", sep=",",header = T)}, error=function(e){}))
#rep <- r
for(rep in repObjs)
{
  while(rep$getStatus() != "Completed" && rep$getStatus() != "Failed")
  {
    Sys.sleep(300)
  }
  stats <- rep$getReportStatsAllDimensions()
  for(dim in stats)
  {
    repName <- rep$getName()
    sName <- rep$getScore()$getName()
    mName <- rep$getScore()$getModel()$getName()
    pName <- rep$getScore()$getModel()$getProject()$getName()
    key <- paste(pName,mName,sName,repName,sep = "|")
    nba[key,dim$value] <- dim$stats$auc
  }
}


rep1 <- list(list(model=r$getScore()$getModel()$getName(),project=r$getScore()$getModel()$getProject()$getName(),report=r$getName(), score = r$getScore()$getName(), predictionDimensions=ss))
rep2 <- list(list(model=r$getScore()$getModel()$getName(),project=r$getScore()$getModel()$getProject()$getName(),report=r$getName(), score = r$getScore()$getName(), predictionDimensions=ss1))
reports <- NULL
reports <- c(reports, rep1)
reports <- c(reports, rep2)
cat(toJSON(list(reports=reports),pretty = T, digits = 10))
cat(toJSON(list(reports=reports),pretty = T, digits = 10),file = "~/testRes.json")
cat(toJSON(list(pred=ss),pretty = T, digits = 10),file = "~/testRes.json")

sta <- list(aa=c(1,2,3,4,5),bb=c(0.1,0.2,0.3,0.456,0.44343),auc=0.731435412412412)
item1 <- list(list(val = "cat1",stats=sta))
item2 <- list(list(val = "cat2",stats=sta))
full <- NULL
full <- c(item1)
full <- c(full, item2)

rep1 <- list(list(model=r$getScore()$getModel()$getName(),project=r$getScore()$getModel()$getProject()$getName(),report=r$getName(), score = r$getScore()$getName(), predictionDimensions=full))
rep2 <- list(list(model=r$getScore()$getModel()$getName(),project=r$getScore()$getModel()$getProject()$getName(),report=r$getName(), score = r$getScore()$getName(), predictionDimensions=full))


reports <- NULL
reports <- c(reports, rep1)
reports <- c(reports, rep2)
final <- list(reports=reports)
cat(toJSON(final,pretty = T, digits = 10))
finalJson <- toJSON(final,pretty = T, digits = 10)
finalObject <- fromJSON(finalJson,simplify = F)
cat(toJSON(list(pred=full),pretty = T, digits = 10))
cat(toJSON(finalObject,pretty = T, digits = 10))
finalObject$reports <- c(reports, rep2)







allstat <- r$getReportStatsAllDimensions()
aucs <- data.frame(predictionDimensionValue=unlist(lapply(allstat,function(x) {x$value})),
                   auc=unlist(lapply(allstat,function(x) {x$stats$auc})),
                   total_responses = unlist(lapply(allstat,function(x) {x$stats$responses})),
                   total_unique_responses = unlist(lapply(allstat,function(x) {x$stats$ctp[length(x$stats$ctp)]})),
                   total_population_in_report = unlist(lapply(allstat,function(x) {x$stats$populationTotal})))



caInfo <- system.file("resources","cacert.pem", package="ApigeeInsights")
url <- RCurl::getURL(url = "https://burberry-insights.apigee.com/jobLog/logs/getLog.cgi?handle=rib000ea:/tmp/final_aucs_internal.csv",.opts= list(httpheader=c("User-Agent"="rclient"), cainfo = caInfo))
kk <- read.csv(textConnection(url),header = T)



p <- acc$getProject("Production2_Model2")
m <- p$getModel("M2_20151201173002")
s <- m$getScore("S_20151202140002")
r <- s$getReport("R_20151202210023")

c <- con$getDataManager()$getCatalog("ProductionCatalog2")
dataset_names <- c("apigee_transactions","apigee_profiles")
for(d_name in dataset_names)
{
  d <- c$getDataset(d_name)
  pl <- d$getPartitionList()
  show(pl)
}  

pp<- acc$getProject("Production1_All")
pp$getCombinedScoreList()


p <- acc$getProject("Production2_Model2")
m <- p$getModel("M2_20160103212741")
s <- m$getScore("S_20160201183530")



project_name <- "Production1_All"
dateTime <- ifelse(is.na(args[1]), as.character(Sys.time()), args[1])
cs_name=paste("PS_",strftime(as.POSIXlt(dateTime),format = "%Y%m%d%H%M%S"),sep="")
combScore <- CombinedScore$new(project=project_name, name=cs_name)
combScore$setAlgo("MAX")
combScore$addScore(s)
combScore$store()
combScore$execute()
combScore$getStatus()

score_list <- m$getScoreList()
unlist(score_list[nrow(score_list)-1,"name"])





objectToMonitor <- ifelse(is.na(args[1]), "score,report,combined_score", args[1])
objectToMonitor <- unlist(strsplit(objectToMonitor,","))
Reduce(`|`,objectToMonitor=="combined_score")



