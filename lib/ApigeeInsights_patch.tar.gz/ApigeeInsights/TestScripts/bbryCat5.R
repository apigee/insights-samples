library(ApigeeInsights)

acc <- connect(org="burberry_test",user="insights_admin@apigee.com",password="Apigee2010",host="https://burberry-insights.apigee.com/api/")


project_name <- "Zynab_Test" # user specified this name 

setCatalog("MariaCatalog5") # catalog name as created during oozie flow

#account$getDataManager()$getCatalog("MariaCatalog1")$getDataset("maria_apigee_transactions") #to read dataset from R

model <- Model$new(project=project_name,name="model_cat5-v2",description="Transaction Model") #user specifies any name and description

model$setDateFilter(endTime="2014-08-30 23:59:59") #date used for training 

model$addActivityEvent(dataset="maria_apigee_transactions_new", dimensions=list("product_group","spend_bucket","colour_group","dotflag"))

#model$addActivityEvent(dataset="Return",

#dimensions=list("productGroup","spendBin","colourGroup","dotflag"))

model$setProfile(dataset="maria_apigee_customer_attributes",dimensions=list("parent_gender"), dimCombn = 1)

model$setResponseEvent(dataset="maria_apigee_transactions_new",predictionDimensions="product_group")

model$setConfiguration("distanceIntervalStart","MONTH")

model$setConfiguration("firstLevelThreshold","50")

model$setConfiguration("responseThreshold","5")

model

model$execute()

model$getStatus()

score <- Score$new(model,name="score_cat5",description="Transaction Score",targetScoreTime="2015-02-22") #this is the scoring part 

score$setConfiguration("maxCorelationPerSplit","180000")

score$setScoreType(value="propensity") # set propensity or lift

score

score$execute()

score$getStatus()

report <- Report$new(score=score,name="report_cat5", description="Transaction Report")

#report$setDateFilter(endTime="2015-01-01 23:59:59")

report

report$execute()

report$getStatus()

#Run the plot once report job is completed

report$plot(type="AUC")

#Run the plot once model/score/report jobs are completed

cReport <- account$getProject("Zynab_Test")$getModel("test_model")$getScore("test_score")$

getReport("test_report")

cReport$plot(type="GAIN")

View(score$stream())