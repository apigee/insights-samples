#Remove hash symbol from the first line of the report
library(ApigeeInsights)
acc <- connect(org="qauser",user="qauser",password="Test12345",host="http://10.224.16.104:8080/api")
rModel <- acc$getProject("RecommendationsTutorial")$getModel("RecommendationsModel")
rScore <- rModel$getScore("RecommendationsModelScore")
rReport <- rScore$getReport("RecommendationsModelAccuracyReport")

oldScore <- rModel$getScore("oldScore-v1")

oldReport <- oldScore$getReport("oldReport-v3")
oldReport$plot()


cs <- CombinedScore$new(project="combinedScoreProject",name="newcs-v1")
cs$addScore(score = rScore,1)
cs$execute()

cs <- CombinedScore$new(project="combinedScoreProject",name="newcs-v3-o")
cs$addScore(score = oldScore,1)
cs$execute()

cat(toJSON(oldReport$toJsonStructure(),pretty = T))

cs <- acc$getProject("combinedScoreProject")$getCombinedScore("newcs-v2-o")
cr <- CombinedReport$new(cs,name="newcrrrrr-v3-o","dsadsadasds")

cr$setResponseEvent(catalog = "RetailDatasets",dataset = "Purchase",predictionDimensions = "ProductName", startTime = "2013-08-20 00:00:01")
cr$execute()

cr1 <- cs$getCombinedReport("newcrrrrr-v4-o")
cr1$plot()
