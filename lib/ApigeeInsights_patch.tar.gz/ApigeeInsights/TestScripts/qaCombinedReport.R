#Remove hash symbol from the first line of the report
library(ApigeeInsights)
acc <- connect(org="qauser",user="qauser",password="Test12345",host="http://10.224.16.104:8080/api")
rModel <- acc$getProject("RecommendationsTutorial")$getModel("RecommendationsModel")
rScore <- rModel$getScore("RecommendationsModelScore")
rReport <- rScore$getReport("RecommendationsModelAccuracyReport")


rModel <- acc$getProject("RecTutorial-v3")$getModel("RecoModel-v3")
rScore <- rModel$getScore("RecModelScore-v3")
rReport <- rScore$getReport("RecModelReport-v3")



oldScore <- rModel$getScore("oldScore-v1")

oldReport <- oldScore$getReport("oldReport-v3")
oldReport$plot()


cs <- CombinedScore$new(project="combinedScoreProject",name="newcs-v2")
cs$addScore(score = rScore,1)
cs$execute()

cs <- CombinedScore$new(project="combinedScoreProject",name="newcs-v3-o")
cs$addScore(score = oldScore,1)
cs$execute()


cat(toJSON(oldReport$toJsonStructure(),pretty = T))

cs <- acc$getProject("combinedScoreProject")$getCombinedScore("newcs-v2-o")
cr <- CombinedReport$new(cs,name="newcreport-v_lap4")

cr$setResponseEvent(catalog = "RetailDatasets",dataset = "Purchase",predictionDimensions = "ProductName", startTime = "2013-08-20 00:00:01")
cr$execute()
cr$plot(predictionDimensionValue = "SkipHopZooBackpack")

cr4 <- cs$getCombinedReport("newcreport-v4")
cs <- acc$getProject("combinedScoreProject")$getCombinedScore("newcs-v1")
throwaway <- cs$getCombinedReport("newcreport-v6")

cr1 <- cs$getCombinedReport("newcreport-v6")
cr1$plot(predictionDimensionValue = "SkipHopZooBackpack")
