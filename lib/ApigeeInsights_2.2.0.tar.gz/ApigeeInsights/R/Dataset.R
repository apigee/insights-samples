#Copyright 2014 Apigee Corporation
Dataset$methods(
  setCatalog = function(catalog){
    signatures <- c("Catalog")
    if(!Utils.validateSignature(catalog,signatures))
    {
      stop("Invalid signature : catalog should be of type ", paste(signatures,collapse=" or "))
    }
    .catalog <<- catalog
  },
  getCatalog = function(){return(.catalog)},
  setName = function(name){
    signatures <- c("character")
    if(!Utils.validateSignature(name,signatures))
    {
      stop("Invalid signature : name should be of type ", paste(signatures,collapse=" or "))
    }
    .name <<- name
  },
  getName = function(){return(.name)},
  setDescription = function(description){
    signatures <- c("character")
    if(!Utils.validateSignature(description,signatures))
    {
      stop("Invalid signature : description should be of type ", paste(signatures,collapse=" or "))
    }
    .description <<- description
  },
  getDescription = function(){return(.description)},
  setSchema = function(schema){
    signatures <- c("list")
    if(!Utils.validateSignature(schema,signatures))
    {
      stop("Invalid signature : schema should be of type ", paste(signatures,collapse=" or "))
    }
    .schema <<- c(schema)
  },
  getSchema = function(){return(.schema)},
  setDataType = function(dataType){
    signatures <- c("character")
    if(!Utils.validateSignature(dataType,signatures))
    {
      stop("Invalid signature : dataType should be of type ", paste(signatures,collapse=" or "))
    }
    .dataType <<- dataType
  },
  getDataType = function(){return(.dataType)},
  setDelimiter = function(delimiter){
    signatures <- c("character")
    if(!Utils.validateSignature(delimiter,signatures))
    {
      stop("Invalid signature : delimiter should be of type ", paste(signatures,collapse=" or "))
    }
    .delimiter <<- delimiter
  },
  getDelimiter = function(){return(.delimiter)},
  setStatistics = function(statistics){
    signatures <- c("list")
    if(!Utils.validateSignature(statistics,signatures))
    {
      stop("Invalid signature : statistics should be of type ", paste(signatures,collapse=" or "))
    }
    .statistics <<- c(statistics)
  },
  addStatistics = function(statistics){
    signatures <- c("list")
    if(!Utils.validateSignature(statistics,signatures))
    {
      stop("Invalid signature : statistics should be of type ", paste(signatures,collapse=" or "))
    }
    .statistics <<- c(.statistics,statistics)
  },
  generateEndPoint = function(id="") {
    return(getCatalog()$generateEndPoint(id))
  },
  generateCEndPoint = function(id="") {
    id <- curlEscape(id)
    host <- Utils.trim(getCatalog()$generateEndPoint(getName()))
    if(id != "") 
    {   
      id <- paste("/",id,sep="")
    }   
    return(paste(host,"/partitions",id,sep=""))
  },
  getPartitionList = function(name, datastore){
      url <- generateCEndPoint()
      params = list(accountId=getCatalog()$getDataManager()$getAccount()$getId(),token=getCatalog()$getDataManager()$getAccount()$getToken(),entityIdType="name");
      tryCatch({
        Utils.info("Fetching partition list...")
        data <- sendRequest(url,"get",params)
      },AIErr=function(x){
        if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
        {   
          stop(x)
        }   
        template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
        msg <- replaceTemplate(template)
        stop(createAIErr(x$code,msg))
      })  
      #Utils.debug("listPartitions",data)
      lp <- data.frame(do.call("rbind",data$partitions))
      return(lp)
  },
  getPartition = function(name, datastore=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(names=c("character"),
                       datastore=c("character","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    
    if(is.null(datastore))
    {
      datastore <- getDatastore()
    }
    url <- generateCEndPoint(name)
    params = list(accountId=getCatalog()$getDataManager()$getAccount()$getId(),token=getCatalog()$getDataManager()$getAccount()$getToken(),entityIdType="name",datastore=datastore)
    tryCatch({
      Utils.info(paste("Fetching partition - ",name,"...",sep="",collapse=""))
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES$ENTITY$PARTITION,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<PARTITION>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })  
    partition <- Utils.buildPartitionFromJson(.self,data$partition)
    Utils.info("Fetching successful")
    return(partition)
  },
  show = function()
  {
    cat("Dataset Object:\n\n")
    cat("name =",getName(),"\n\n")
    cat("description =",getDescription(),"\n\n")
    cat("dataset type =",getDataType(),"\n\n")
    showSchema()
    getStatistics()$showStats()
    
  },
  getPartitions = function(names=NULL, datastore=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(names=c("character"),
                       datastore=c("character","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(is.null(names))
    {
      if(!exists(".AIEnv") || is.null(.AIEnv$.partitions))
      {
        stop("partitions should be either passed as a parameter or set globally using setPartition method")
      }
      names <- .AIEnv$.partitions
    }
    partitions = lapply(names,
                        function(name)
                          {
                            return(getPartition(name, datastore))
                        })
    return(partitions)
  },
  showSchema = function()
  {
    if(!Utils.isSet(getSchema()))
    {   
      cat("Schema is empty\n")
    }   
    else
    {   
      sdf <- data.frame(do.call("rbind",getSchema()))
      cat("\nSchema for Catalog '",getCatalog()$getName(),"' and Dataset '",getName(),"'", sep="")
      return(pandoc.table(sdf,split.cells=50, split.table=120,style="grid"))
    }  
  },
  generateStatistics = function()
  {
    url <- generateEndPoint(getName())
    params = list(accountId=getCatalog()$getDataManager()$getAccount()$getId(),token=getCatalog()$getDataManager()$getAccount()$getToken(),entityIdType="name")
    url <- paste(url,"/generateStatistics_op",sep="")
    tryCatch({
      data <- sendRequest(url,"put",params,"{}")
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })  
  },
  getStatistics = function()
  {
    url <- generateEndPoint(getName())
    params = list(accountId=getCatalog()$getDataManager()$getAccount()$getId(),token=getCatalog()$getDataManager()$getAccount()$getToken(),entityIdType="name")
    url <- paste(url,"/getStatistics_op",sep="")
    tryCatch({
      data <- sendRequest(url,"get",params)
      cStats <- data$statistics$DatasetReport$columns
      data$statistics$DatasetReport$columns <- NULL
      oStats <- data$statistics$DatasetReport
      dSet <- .self
      statsObj <- BaseStatistics$new()
      statsObj$setDataset(dSet)
      statsObj$setOverAllStats(oStats)
      statsObj$setColumnLevelStats(cStats)
      return(statsObj)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })
  },
  getType = function()
  {
    if(!Utils.isSet(getDataType()))
    {
      dfSchema <- data.frame(do.call("rbind",getSchema()))
      u <- unlist(dfSchema$fieldName[grep("user",unlist(dfSchema$fieldTag))])
      t <- unlist(dfSchema$fieldName[grep("timestamp",unlist(dfSchema$fieldTag))])
      if(is.null(u))
      {
        setDataType("dimension")
      }
      else if(!is.null(u) && is.null(t))
      {
        setDataType("userprofile")
      }
      else if(!is.null(u) && !is.null(t))
      {
        setDataType("event")
      }
    }
    return(getDataType())
  },
  isEvent = function()
  {
    if(Utils.isSet(getDataType()))
    {
      return(getDataType() == "event")
    }
    else
    {
      dfSchema <- data.frame(do.call("rbind",getSchema()))
      u <- unlist(dfSchema$fieldName[grep("user",unlist(dfSchema$fieldTag))])
      t <- unlist(dfSchema$fieldName[grep("timestamp",unlist(dfSchema$fieldTag))])
      if(is.null(u))
      {
        setDataType("dimension")
      }
      else if(!is.null(u) && is.null(t))
      {
        setDataType("userprofile")
      }
      else if(!is.null(u) && !is.null(t))
      {
        setDataType("event")
      }
    }
    return(getDataType() == "event")
  }
)
