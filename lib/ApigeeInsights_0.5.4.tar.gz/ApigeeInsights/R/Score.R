#Copyright 2014 Apigee Corporation
Score$methods(
  initialize = function(model, name, description="", targetScoreTime, .skipI=FALSE){
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(model=c("Model"),
                       name=c("character"),
                       description=c("character"),
                       targetScoreTime=c("character","POSIXt","POSIXlt"),
                       .skipI=c("logical"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    d <- as.Date(targetScoreTime,format='%Y-%m-%d')
    if(is.na(d))
    {
      stop("The target score time must be of the format YYYY-MM-DD")
    }
    else
    {
      targetScoreTime <- as.character(d)
    }
    .global <<- list(targetScoreTime=targetScoreTime)
    setName(name)
    setDescription(description)
    setConfiguration("targetScoreTime",targetScoreTime)
    setModel(model)
    if(.skipI)
    {
      Utils.info("Score created successfully")
      return()
    }
    account <- .AIEnv[[".ApigeeInsights"]]
    if(!model$getSaved())
    {
      warning("Model is not saved. Use store method to save the model before saving the score object")
    }
    tryCatch({
      scoreNames <- getModel()$getScoreList()$name
      Utils.info("Checking for score duplicity...")
      if(name %in% scoreNames)
      {
        stop("Score - ",name," already available. Use getScore method to fetch the score or change the score name")
      }
    }, AIErr=function(err){
    })
    setSaved(FALSE)
    #mCombineActivity <- getModel()$getClickStream()$getCombineActivity()$copy()
    Utils.info("Inheriting activities and profile from model")
    #setCombineActivity(mCombineActivity)
    #acts <- getCombineActivity()$getActivity()
    acts <- getModel()$getClickStream()$getCombineActivity()$getActivity()
    prof <- getModel()$getClickStream()$getCombineActivity()$getProfile()
    endTime <- as.POSIXlt(targetScoreTime)-1
    isInfoSet <- 1
    if(.AIEnv[[".isInfo"]] == 0)
    {
      isInfoSet <- 0
    }
    Utils.info("Validating configuration...")
    setInfo(0)
    first <- TRUE
    for(act in acts)
    {
      newAct <- act$copy()
      c <- newAct$getConfig()
      st <- c$startTime
      et <- c$endTime
      if(!is.null(st) && !is.null(et))
      {
        st <- as.POSIXlt(st)
        et <- as.POSIXlt(et)
        diff <- et - st
        c$startTime <- as.character(endTime-diff)
        newAct$setConfig(c)
        #p <- getAllPartitions(dataset=newAct$getPartition()[[1]]$getDataset(),datastore=newAct$getPartition()[[1]]$getDatastore())
        #data <- Utils.getStEtFromPartitions(p)
        #fp <- NULL
        #if(!is.null(data))
        #{
        #  fp <- Utils.getPartitionsGivenStEt(c$startTime,as.character(endTime),data)
        #  if(length(fp) != 0)
        #  {
        #    newAct$setPartition(fp)
        #  }
        #  else
        #  {
        #    warning("Cannot find data for the given time range for the dataset ", p[[1]]$getDataset()$getName())
        #    newAct$setPartition(p)
        #  }
            
        #}
        #else
        #{
          #newAct$setPartition(p)
        #}
      }
      getCombineActivity()$addActivity(newAct)
    }
    for(pr in prof)
    {
      obj <- pr$copy()
      c <- pr$getConfig()
      obj$setConfig(c)
      getCombineActivity()$addProfile(obj)
    }
    if(isInfoSet == 1)
      setInfo(1)
    endTime <- as.character(endTime)
    Utils.info(paste("Setting (targetScoreTime - 1 second) i.e. ", endTime," as the end date for activities",sep="",collapse=""))
    setDateFilter(endTime=endTime)
    Utils.info("Validation done")
    derivedConfig <- c("distanceIntervalStart")
    mConfig <- getModel()$getConfig()
    sConfig <- getConfig()
    if(Utils.isSet(mConfig))
    {
      for(c in derivedConfig)
      {
        if(Utils.isSet(mConfig[[c]]))
        {
          Utils.info(paste("Inheriting config '",c,"' from model",sep="",collapse=""))
          sConfig[[c]] <- mConfig[[c]]
        }
      }
    }
    ms <- mConfig$splitConfig
    if(Utils.isSet(sConfig))
    {
      setConfig(sConfig)
    }
    if(!is.null(ms))
    {
      split <- unlist(strsplit(ms,":"))[2]
      r <- unlist(strsplit(split,"-"))
      if(length(r) == 2)
      {
        r <- as.numeric(r)
        ss <- setdiff(0:99,seq(r[1],r[2]))
      }
      else
        ss <- setdiff(0:99,as.numeric(unlist(strsplit(split,","))))
      setScoringSplit(100,ss)
    }
    Utils.info("Score created successfully")
  },
  cloneObject = function(name, description="", targetScoreTime=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(name=c("character"),
                       targetScoreTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       description = "character")
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(!is.null(targetScoreTime)){
      d <- as.Date(targetScoreTime,format='%Y-%m-%d')
      if(is.na(d))
      {
        stop("The target score time must be of the format %Y-%m-%d")
      }
      else
      {
        targetScoreTime <- as.character(d)
      }
    }
    else
    {
      targetScoreTime <- getConfig()$targetScoreTime
    }
    
    if(is.null(targetScoreTime))
    {
      targetScoreTime <- getConfig()$targetScoreTime
    }
    clonedScore <- Score$new(getModel(),name,description,targetScoreTime=targetScoreTime)
    if(Utils.isSet(getConfig()))
    {
      c <- getConfig()
      c$targetScoreTime <- targetScoreTime
      clonedScore$setConfig(c)
    }
    #objects <- getCombineActivity()$getActivity()
    #for(obj in objects)
    #{
    #  newObj <- obj$copy()
    #  clonedScore$getCombineActivity()$addActivity(newObj)
    #}
    #objects <- clonedScore$getCombineActivity()$getProfile()
    #for(obj in objects)
    #{
    #  newObj <- obj$copy()
    #  clonedScore$getCombineActivity()$addProfile(newObj)
    #}
    clonedScore$.global$startTime <- .global$startTime
    clonedScore$setSaved(FALSE)
    return(clonedScore)
  },
  refreshPartitions = function()
  {
    objects <- getCombineActivity()$getActivity()
    for(obj in objects)
    {
      startTime <- obj$getConfig()$startTime
      endTime <- obj$getConfig()$endTime
      d <- obj$getPartition()[[1]]$getDataset()
      datastore <- obj$getPartition()[[1]]$getDatastore()
      p <- getAllPartitions(dataset=d, datastore=datastore)
      data <- Utils.getStEtFromPartitions(p)
      if(!is.null(data))
        p <- Utils.getPartitionsGivenStEt(startTime,endTime,data)
      
      
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      if(is.null(p) || length(p) == 0)
      {
        warning("Based on the time range, no data available for catalog=",d$getCatalog()$getName()," dataset=",d$getName())
      }
      else
        obj$setPartition(p)
      #a$setDatastore(datastore)
      #a$setDataset(d)
    }
  },
  setScoringSplit = function(totalBucket, split=NULL)
  {
    if(is.null(split) || is.null(split) )
    {   
      stop("Split cannot be null or missing")
    }   
    if(Utils.is.sequential(split))
    {
      r <- paste(range(split),collapse="-")
      s <- paste(totalBucket,":",r,sep="")
    }
    else
    {
      s <- paste(totalBucket,":",paste(split,sep="",collapse=","),sep="")
    }
    config <- getConfig()
    config$splitConfig <- s
    setConfig(config)
  },
  setScoringPercent = function(split)
  {
    if(split >= 100 || split <= 0) 
    {    
      stop("Split percent should be between 0 and 100")
    }
    setScoringSplit(100,0:(split-1))
  },
  stream = function(topN=100,sep=",")
  {
    acc<- .AIEnv$.ApigeeInsights
    dm <- acc$getDataManager()
    cn <- paste(getModel()$getProject()$getName(),".",getModel()$getName(),sep="")
    p <- dm$getPartition(catalog=cn, dataset="score", partition=getName())
    return(p$stream(topN=topN, sep=sep))
  },
  toJsonStructure = function()
  {
    obj <- list()
    if(Utils.isSet(.name))  
      obj[["name"]] <- getName()
    if(Utils.isSet(.description))
      obj[["description"]] <- getDescription()
    if(Utils.isSet(.config))
      obj[["config"]] <- .config
    obj[["combineActivity"]] <- .combineActivity$toJsonStructure()
    if(Utils.isSet(.id))
    {
      obj[["id"]] <- .id
    }
    if(!is.null(.global$visibility))
    {
      obj[["visibility"]] <- .global$visibility
    }
    return(obj)
  },
  setConfiguration = function(key, value)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(key=c("character"),
                       value=c("character","numeric"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(!(key %in% c("numReducers","maxNumOfScorePartition","minScorePartitionWidth","scoreTrendThreshold","scoreDelimiter","distanceIntervalStart","robotThreshold","targetScoreTime","freqMetrics","maxCorelationPerSplit")))
    {
      stop(key," is not supported.")
    }
    if(class(value) == "numeric")
    {   
      value <- sprintf("%.f",value)
    }   
    key <- Utils.trim(key)
    config <- getConfig()
    config[[key]] <- value
    setConfig(config)
  },
  openJobManager = function()
  {
    url <- getModel()$getProject()$getAccount()$getConfig()$jobManager
    if(!is.null(url))
    {   
      mn <- curlEscape(getName())
      url <- paste(url,"#resource=/management/jobBrowser&objectType=Score&objectName=",mn,"&objectId=",getId(),"&token=",getModel()$getProject()$getAccount()$getToken(),"&userName=",getModel()$getProject()$getAccount()$getUser(),sep="")
    }   
    else
    {   
      stop("jobManager base url not available in the configuration")
    }   
    browseURL(url)
  },
  addActivityEvent = function(dataset, catalog=NULL, startTime=NULL, endTime=NULL, partitions=NULL, datastore=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(catalog=c("character","missing","NULL"),
                       dataset=c("character"),
                       startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       endTime=c("character","POSIXt","POSIXlt","missing","NULL"),
                       partitions=c("character","missing","NULL"),
                       datastore=c("character","missing","NULL"))
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(is.null(startTime))
      startTime <- .global$startTime
    
    if(is.null(endTime))
      endTime <- .global$endTime
    
    if(!missing(startTime) && !is.null(startTime) && !missing(endTime) && !is.null(endTime))
    {
      if(endTime < startTime)
      {
        stop("endTime cannot be less than start time")
      }
    }
    #get catalog, dataset, partitions
    if(is.null(catalog))
    {
      if(!exists(".AIEnv") || is.null(.AIEnv$.catalog))
      {
        stop("catalog should be either passed as a parameter or set globally using setCatalog method")
      }
      catalog <- .AIEnv$.catalog
    }
    if(is.null(datastore))
    {
      datastore <- getDatastore()
    }
    if(is.null(partitions))
    {
      if(exists(".AIEnv") && !is.null(.AIEnv$.partitions))
      {
        partitions <- .AIEnv$.partitions
      }
    }
    config <- list()
    activities <- getCombineActivity()$findGivenDatasetCatalogActivity(catalog, dataset) 
    if(Utils.isSet(activities))
    {
      config <- activities[[1]]$getConfig()
    }
    
    account <- .AIEnv$.ApigeeInsights
    dm <- DataManager$new(.account=account)
    c <- dm$getCatalog(catalog)
    d <- c$getDataset(dataset)
    if(!d$isEvent())
    {
      stop("Dataset should be an event dataset")
    }
    a <- Activity$new()
    if(!is.null(partitions))
    {
      p <- d$getPartitions(partitions, datastore)
      data <- Utils.getStEtFromPartitions(p)
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      for(parts in data)
      {
        pst <- parts$min
        pet <- parts$max
        pname <- parts$partition$getName()
        if(!is.null(pst) && !is.null(pet) && !is.null(startTime) && !is.null(endTime))
        {
          #if below is true, then it means the timestamp provided by user and the data does not overlap. So after transformation we will have empty data
          if(!((pst <= endTime)  &&  (pet >= startTime)))
          {
            warning("The time range provided does not overlap with the partition ",pname,". So the input data will be empty after filtering. The min and max time in the data are : ", st," & ",et)
          }
          
        }
      }
      a$setPartition(p)
    }
    else
    {
      #Remove this code for getting all partitions
      p <- getAllPartitions(dataset=d, datastore=datastore)
      data <- Utils.getStEtFromPartitions(p)
      if(!is.null(data))
        p <- Utils.getPartitionsGivenStEt(startTime,endTime,data)
      st <- Utils.getSt(data)
      if(is.null(startTime) && !is.null(st))
      {
        Utils.info(paste("Since startTime is missing, setting startTime to ",st," based on the data.",sep=""))
        startTime <- st
      }
      et <- Utils.getEt(data)
      if(is.null(endTime) && !is.null(et))
      {
        Utils.info(paste("Since endTime is missing, setting endTime to ",et," based on the data.",sep=""))
        endTime <- et
      }
      a$setPartition(p)
      #a$setDatastore(datastore)
      #a$setDataset(d)
    }
    
    
    #Process startTime and endTime
    if(!is.null(startTime))
    {
      startTime <- as.character(startTime)
      config$startTime <- startTime
      st <- as.Date(startTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(st))
      {    
        stop("The start time must be of the format YYYY-MM-DD HH:MM:SS")
      }    
    }
    else if(!is.null(.global$startTime))
    {
      startTime <- as.character(.global$startTime)
      config$startTime <- startTime
    }
    if(!is.null(endTime))
    {    
      endTime <- as.character(endTime)
      config$endTime <- endTime
      et <- as.Date(endTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(et))
      {    
        stop("The end time must be of the format YYYY-MM-DD HH:MM:SS")
      }
    }
    else if(!is.null(.global$endTime))
    {
      endTime <- as.character(.global$endTime)
      config$endTime <- endTime
    }
    if(Utils.isSet(config))
    {
      a$setConfig(config)
    }
    getCombineActivity()$addActivity(a)
  },
  setVisibility = function(flag="External")
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(
      flag=c("character")
    )
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(length(flag) == 1 && (flag == "External" || flag == "Internal"))
    {
      .global$visibility <<- flag
    }
  },
  setDateFilter = function(startTime=NULL, endTime=NULL)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    signatures <- list(
      startTime=c("character","POSIXt","POSIXlt","missing","NULL"),
      endTime=c("character","POSIXt","POSIXlt","missing","NULL")
    )
    Utils.signatureValidation(params, signatures, globalSignatures)
    if(is.null(startTime) && is.null(endTime))
    {
      stop("Both start time and end time cannot be missing")
    }
    if(!is.null(startTime))
    {    
      startTime <- as.character(startTime)
      st <- as.Date(startTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(st))
      {    
        stop("The start time must be of the format YYYY-MM-DD HH:MM:SS")
      }
      .global$startTime <<- startTime
    }    
    if(!is.null(endTime))
    {    
      endTime <- as.character(endTime)
      et <- as.Date(endTime,format='%Y-%m-%d %H:%M:%S')
      if(is.na(et))
      {    
        stop("The end time must be of the format YYYY-MM-DD HH:MM:SS")
      }
      .global$endTime <<- endTime
      
    }
    #activity start and end time
    if(Utils.isSet(getCombineActivity()$getActivity()))
    {
      aList <- getCombineActivity()$getActivity()
      for(activity in aList)
      {
        aConfig <- activity$getConfig()
        if(!is.null(startTime))
          aConfig$startTime <- startTime
        if(!is.null(endTime))
          aConfig$endTime <- endTime
        activity$setConfig(aConfig)
      }
    }
    if(!is.null(.global$targetScoreTime) && !is.null(.global$endTime))
    {
      if(as.Date(.global$targetScoreTime) < as.Date(.global$endTime))
      {
        warning("It is not advisable to have end time past the target score time")
      }
    }
    refreshPartitions()
  },
  show = function()
  {
    cat("Account = ", getModel()$getProject()$getAccount()$.account)
    cat("\nProject = ", getModel()$getProject()$getName())
    cat("\nModel = ", getModel()$getName())
    cat("\nScore Object :\n\n")
    cat("Score Name =",getName(),"\n")
    cat("Score Description =",getDescription(),"\n")
    if(length(getConfig()) > 0)
    {   
      cat("********* Score Configs *********")
      pandoc.table(as.data.frame(getConfig()), split.cells=50, split.table=1220,style="grid")
    }   
    ca <- getCombineActivity()$toJsonStructure()
    if(length(ca$activity) > 0)
    {   
      cat("\n******************* Activity Dataset *******************")
      activity <- lapply(ca$activity,collapsePartitions)
      dfa <- Utils.convertToDataFrame(activity)
      pandoc.table(dfa, split.cells=50, split.table=1220,style="grid")
    }   
    if(length(ca$profile) > 0)
    {   
      cat("\n******************* Profile Dataset *******************")
      profile <- lapply(ca$profile,collapsePartitions)
      ulp <- sapply(profile,unlist)
      pandoc.table(t(ulp), split.cells=50, split.table=1220,style="grid")
    }
  },
  getReport = function(name)
  {
    params <- c(as.list(environment()))
    globalSignatures <- "character"
    Utils.signatureValidation(params, globalSignatures=globalSignatures)
    url <- generateCEndPoint(name)
    pn <- getModel()$getProject()$getName()
    params = list(accountId=getModel()$getProject()$getAccount()$getId(),token=getModel()$getProject()$getAccount()$getToken(),entityIdType="name",project=pn)
    Utils.info(paste("Fetching report - ",name,"...",sep="",collapse=""))
    tryCatch({
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES$ENTITY$REPORT,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<REPORT>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })  
    Utils.info("Fetching successful")
    report <- Utils.buildReportFromJson(.self,data$report,.skipI=TRUE)
    report$setSaved(TRUE)
    return(report)
  },
  getReportList = function(){
    pn <- getModel()$getProject()$getName()
    url <- generateCEndPoint()
    params = list(accountId=getModel()$getProject()$getAccount()$getId(),token=getModel()$getProject()$getAccount()$getToken(),entityIdType="name",project=pn)
    Utils.info("Fetching score list...")
    tryCatch({
      data <- sendRequest(url,"get",params)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {   
        stop(x)
      }   
      template <- paste(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      msg <- replaceTemplate(template)
      stop(createAIErr(x$code,msg))
    })  
    Utils.info("Fetching successful")
    ld <- data.frame(do.call("rbind",data$reports))
    return(ld)
  },
  setModel = function(model){
    signatures <- c("Model")
    if(!Utils.validateSignature(model,signatures))
    {
      stop("Invalid signature : model should be of type ", paste(signatures,collapse=" or "))
    }
    .model <<- c(model)
  },
  execute = function()
  {
    name <- getName()
    if(getStatus() == "Unsaved")
    {
      store()
    }
    url <- generateEndPoint(name)
    url <- paste(url,"/execute_op",sep="")
    params = list(accountId=getModel()$getProject()$getAccount()$getId(),token=getModel()$getProject()$getAccount()$getToken(),entityIdType="name",project=getModel()$getProject()$getName())
    tryCatch({
      data <- sendRequest(url,"put",params,"{}")
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {
        stop(x)
      }
      template <- paste(MESSAGES$ENTITY$SCORE,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<SCORE>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })
    
  },
  getStatus = function()
  {
    name <- getName()
    if(getSaved() == FALSE)
    {   
      s <- "Unsaved"
      return(s)
    }   
    else
    {   
      url <- generateEndPoint(getName())
      url <- paste(url,"/getState_op",sep="")
      params = list(accountId=getModel()$getProject()$getAccount()$getId(),token=getModel()$getProject()$getAccount()$getToken(),entityIdType="name",project=getModel()$getProject()$getName())
      tryCatch({
        data <- sendRequest(url,"get",params)
      },AIErr=function(x){
        if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
        {   
          stop(x)
        }   
        template <- paste(MESSAGES$ENTITY$SCORE,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
        tv <- .AIEnv[[".TEMPLATE_VALUES"]]
        tv[["<SCORE>"]] <- name
        msg <- replaceTemplate(template,tv)
        stop(createAIErr(x$code,msg))
      })  
      return(data$state)
    }
  },
  getModel = function(){return(.model[[1]])},
  setCombineActivity = function(combineActivity){
    signatures <- c("CombineActivity")
    if(!Utils.validateSignature(combineActivity,signatures))
    {
      stop("Invalid signature : combineActivity should be of type ", paste(signatures,collapse=" or "))
    }
    .combineActivity <<- combineActivity
  },
  getCombineActivity = function(){return(.combineActivity)},
  setConfig = function(config){
    signatures <- c("list")
    if(!Utils.validateSignature(config,signatures))
    {
      stop("Invalid signature : config should be of type ", paste(signatures,collapse=" or "))
    }
    .config <<- c(config)
  },
  getConfig = function(){return(.config)},
  setName = function(name){
    signatures <- c("character")
    if(!Utils.validateSignature(name,signatures))
    {
      stop("Invalid signature : name should be of type ", paste(signatures,collapse=" or "))
    }
    .name <<- name
  },
  getName = function(){return(.name)},
  setDescription = function(description){
    signatures <- c("character")
    if(!Utils.validateSignature(description,signatures))
    {
      stop("Invalid signature : description should be of type ", paste(signatures,collapse=" or "))
    }
    .description <<- description
  },
  getDescription = function(){return(.description)},
  setId = function(id){
    signatures <- c("numeric")
    if(!Utils.validateSignature(id,signatures))
    {
      stop("Invalid signature : id should be of type ", paste(signatures,collapse=" or "))
    }
    .id <<- id
  },
  getId = function(){return(.id)},
  setSaved = function(saved){
    signatures <- c("logical")
    if(!Utils.validateSignature(saved,signatures))
    {
      stop("Invalid signature : saved should be of type ", paste(signatures,collapse=" or "))
    }
    .saved <<- saved
  },
  getSaved = function(){return(.saved)},
  generateCEndPoint = function(id="")
  {
    id <- curlEscape(id)
    host <- Utils.trim(getModel()$generateCEndPoint(getName()))
    if(id != "")
    {
      id <- paste("/",id,sep="")
    }
    return(paste(host,"/reports",id,sep=""))
  },
  generateEndPoint = function(id="")
  {
    return(getModel()$generateCEndPoint(id))
  },
  store = function()
  {
    name <- getName()
    if(getModel()$getSaved() == FALSE)
    {   
      stop("Save the model in order to continue")
    }   
    if(getSaved() == TRUE){
      return(update())
    }   
    url <- generateEndPoint()
    params = list(accountId=getModel()$getProject()$getAccount()$getId(),token=getModel()$getProject()$getAccount()$getToken(),entityIdType="name",project=getModel()$getProject()$getName())
    jsonObj = toJsonStructure()
    JSON = toJSON(jsonObj)
    tryCatch({
      data <- sendRequest(url,"post",params,JSON)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {
        stop(x)
      }
      template <- paste(MESSAGES$ENTITY$SCORE,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<SCORE>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })
    setSaved(TRUE)
    setId(data$scoreId)
  },
  update = function()
  {
    name <- getName()
    url <- generateEndPoint(name)
    params = list(accountId=getModel()$getProject()$getAccount()$getId(),token=getModel()$getProject()$getAccount()$getToken(),entityIdType="name",project=getModel()$getProject()$getName())
    jsonObj = toJsonStructure()
    JSON = toJSON(jsonObj)
    tryCatch({
      data <- sendRequest(url,"put",params,JSON)
    },AIErr=function(x){
      if(is.null(x$code) || is.null(CODE_MSG_MAP[[as.character(x$code)]]) || is.null(MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]]))
      {
        stop(x)
      }
      template <- paste(MESSAGES$ENTITY$SCORE,MESSAGES[[CODE_MSG_MAP[[as.character(x$code)]]]])
      tv <- .AIEnv[[".TEMPLATE_VALUES"]]
      tv[["<SCORE>"]] <- name
      msg <- replaceTemplate(template,tv)
      stop(createAIErr(x$code,msg))
    })
    setSaved(TRUE)
  }
)
